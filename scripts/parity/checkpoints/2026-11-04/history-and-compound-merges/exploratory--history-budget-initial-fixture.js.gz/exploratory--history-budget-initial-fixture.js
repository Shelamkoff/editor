export const historyBudgetCases=['count','undefined-bytes','tiny','wide'].flatMap(budget=>['insert','typing','branch'].map(kind=>({id:budget+'/'+kind,budget,kind})))
export async function runHistoryBudgetCase({sourceBase='../../',legacy=false,spec,nativeInput}){
 const base=new URL(sourceBase,import.meta.url),[core,paragraph]=await Promise.all(['core/index.js','plugins/paragraph/index.js'].map(p=>import(new URL(p,base)))),copy=structuredClone,pause=()=>new Promise(r=>setTimeout(r,70)),tiny=spec.budget==='tiny',byteLimit=tiny?1:spec.budget==='wide'?1048576:undefined
 const data={version:legacy?'1.0.5':'2.0.0',blocks:[{id:'seed',type:'paragraph',...(!legacy?{dataVersion:2}:{}),data:{text:'Alpha'}}]},original=copy(data),holder=document.createElement('section');holder.style.cssText='width:850px;margin:150px auto';document.body.append(holder)
 const options=legacy?{tuning:{undo:{maxStack:2}}}:{historyMaxStack:2,...(spec.budget==='count'?{}:{historyMaxBytes:byteLimit})},diagnostics=[],transactions=[],nativeEvents=[],observations=[],unsupported=legacy?[{property:'currentObservers',reason:'Legacy transaction diagnostics are absent; empty arrays are not measured zero events.'},...(tiny?[{property:'historyMaxBytes',reason:'The immutable legacy UndoManager tuning exposes maxStack/debounceMs and no byte-budget option.'}]:[])]:[],planned=['load','author','undo','redo','dispose'],completedPhases=[]
 const editor=core.createEditor({holder,plugins:[legacy?new paragraph.Paragraph():paragraph.createParagraphPlugin()],inlinePlugins:[],inlineTools:[],injectStyles:true,data,...options,onDiagnostic:v=>diagnostics.push(v)});if(!legacy)editor.on('transaction:committed',e=>transactions.push({action:e.action,origin:e.origin,name:e.name,history:e.history}))
 let phase='load',error=null;const ids=new Map([['seed','seed']]),state=()=>editor.save().blocks,canonical=()=>state().map(b=>({...b,id:ids.get(b.id)??'unknown:'+b.id})),flags=()=>[editor.canUndo,editor.canRedo],record=(id,text)=>({id,type:'paragraph',...(!legacy?{dataVersion:2}:{}),data:{text}}),wanted=labels=>[record('seed','Alpha'),...labels.map(l=>record(l,l))],check=(property,actual,expected)=>observations.push({phase,property,actual:copy(actual),expected:copy(expected),status:JSON.stringify(actual)===JSON.stringify(expected)?'PASS':'FAIL'}),snap=(labels,history)=>{check('canonical',canonical(),wanted(labels));check('history',flags(),history)}
 const key=async(modifiers,role)=>{holder.querySelector('.oe-editor').focus();document.addEventListener('keydown',e=>nativeEvents.push({role,type:'keydown',key:e.key,trusted:e.isTrusted,modifiers:(e.ctrlKey?2:0)|(e.shiftKey?8:0)}),{capture:true,once:true});for(const type of['rawKeyDown','keyUp'])await nativeInput('Input.dispatchKeyEvent',{type,key:'z',code:'KeyZ',windowsVirtualKeyCode:90,nativeVirtualKeyCode:90,modifiers});await pause()}
 const insert=async(label,index)=>{if(legacy)editor.blocks.insert('paragraph',{text:label},index);else editor.blocks.insert({type:'paragraph',data:{text:label}},index);await pause();const added=state()[index];check('newIdentity',!!added&&typeof added.id==='string'&&!ids.has(added.id),true);if(added)ids.set(added.id,label)}
 try{
  await nativeInput('Input.dispatchMouseEvent',{type:'mouseMoved',x:5,y:5});await pause();snap([],[false,false]);completedPhases.push(phase)
  phase='author'
  if(spec.kind==='typing'){
   const field=holder.querySelector('.oe-paragraph');field.focus();const range=document.createRange();range.selectNodeContents(field);range.collapse(false);getSelection().removeAllRanges();getSelection().addRange(range)
   for(const text of['X','Y']){field.addEventListener('input',e=>nativeEvents.push({role:'type-'+text,type:'input',trusted:e.isTrusted,inputType:e.inputType}),{once:true});await nativeInput('Input.insertText',{text});await pause()}
   check('canonical',canonical(),[record('seed','AlphaXY')]);check('history',flags(),[true,false])
  }else{
   for(const[label,index]of[['A',1],['B',2],['C',3]])await insert(label,index);snap(['A','B','C'],[true,false])
   if(spec.kind==='branch'){
    await key(2,'branch-undo');snap(['A','B'],[!tiny,true]);if(legacy)editor.blocks.move(0,0);else editor.blocks.move('seed',0);await pause();snap(['A','B'],[!tiny,true]);await insert('D',3);snap(['A','B','D'],[true,false])
   }
  }completedPhases.push(phase)
  phase='undo'
  if(spec.kind==='typing'){await key(2,'undo-1');snap([],[false,true])}
  else for(let n=1;n<=3;n++){await key(2,'undo-'+n);snap(tiny?['A','B']:n===1?['A','B']:['A'],[!tiny&&n===1,true])}
  completedPhases.push(phase)
  phase='redo';const last=spec.kind==='branch'?'D':'C'
  if(spec.kind==='typing'){await key(10,'redo-1');check('canonical',canonical(),[record('seed','AlphaXY')]);check('history',flags(),[true,false])}
  else for(let n=1;n<=3;n++){await key(10,'redo-'+n);snap(tiny||n>=2?['A','B',last]:['A','B'],[true,!tiny&&n===1])}
  check('caller',data,original);check('diagnostics',diagnostics,[]);completedPhases.push(phase)
  phase='dispose';editor.destroy();check('rootRemoved',!holder.querySelector('.oe-editor'),true);completedPhases.push(phase)
 }catch(e){error=String(e.stack??e)}finally{editor.destroy();holder.remove()}
 return{id:spec.id,spec,observations,nativeEvents,transactions,diagnostics,unsupported,planned,completedPhases,error,identities:[...ids]}
}
