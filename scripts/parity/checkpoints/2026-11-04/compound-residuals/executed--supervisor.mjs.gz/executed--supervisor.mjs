import assert from 'node:assert/strict'
import{execFileSync,spawnSync}from'node:child_process'
import{readFileSync,writeFileSync}from'node:fs'
import{join}from'node:path'
const temp='test-results/audit-closeout-2026-11-01/',root='scripts/parity/checkpoints/2026-11-04/compound-residuals',mode=process.argv[2],source=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),env={...process.env},groups=['compound-residual-cut','warning-merge','warning-conversion']
const run=(command,args,extra={})=>spawnSync(command,args,{encoding:'utf8',windowsHide:true,maxBuffer:128*1024*1024,env:{...env,...extra}}),report=r=>{process.stdout.write(r.stdout??'');process.stderr.write(r.stderr??'');if(r.status!==0)process.exitCode=r.status??1}
if(mode==='proof'){
 for(const group of groups){const r=run(process.execPath,['scripts/parity/'+group+'.mjs']);assert.equal(r.error,undefined);const path=join(env.EDITOR_RESULTS_DIR,group+'.json');writeFileSync(path,r.stdout);writeFileSync(path+'.stderr',r.stderr);assert.equal(r.status,0,r.stderr);assert.equal(r.stderr,'');assert.equal(JSON.parse(r.stdout).candidatePass,true);const check=run(process.execPath,[root+'/review.mjs',path,source,join(env.EDITOR_RESULTS_DIR,group+'-review.json')]);report(check);if(check.status!==0)break}
}else if(mode==='controls'){
 for(const group of groups){const r=run(process.execPath,[root+'/controls.mjs',root+'/review.mjs',join(env.EDITOR_RESULTS_DIR,group+'.json'),source,join(env.EDITOR_RESULTS_DIR,group+'-controls')]);report(r);if(r.status!==0)break}
}else if(mode?.startsWith('native-')){
 const pages=mode==='native-controls'?['native-clipboard.html','native-conversion.html','native-conversion-preservation.html','native-plugin-field-clipboard.html']:['native-compound-residuals'+(mode==='native-trusted'?'-trusted':'')+'.html']
 for(const page of pages){const r=run(process.execPath,['tests/browser/physical-history.mjs'],{EDITOR_NATIVE_PAGE:page});report(r);if(r.status!==0)break}
}else{
 const gates=['proof','controls','build','node','typecheck','types','browser','native-residuals','native-trusted','native-controls','package','bundle','heap','docs','site'],directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init',...gates],{encoding:'utf8'}).trim();writeFileSync(temp+'compound-run-path.txt',directory);env.EDITOR_RESULTS_DIR=directory
 for(const gate of gates){const command=['build','node','typecheck','types','package','docs','site'].includes(gate)?['cmd.exe','/d','/s','/c','npm run '+({build:'build',node:'test',typecheck:'typecheck',types:'test:types',package:'test:package',docs:'test:docs',site:'docs:check'})[gate]]:gate==='browser'?[process.execPath,'tests/browser/run.mjs']:gate==='bundle'?[process.execPath,'benchmarks/bundle-budget.mjs','--enforce']:gate==='heap'?[process.execPath,'tests/browser/heap-gate.mjs']:[process.execPath,temp+'run-compound-gates.mjs',gate],r=run(process.execPath,['scripts/verification-results.mjs','run',gate,...(gate==='controls'?['--require','proof']:[]),'--',...command]);console.log(gate+': '+r.status+' '+(r.stdout??'').slice(-1600));if(r.status!==0)console.error((r.stderr??'').slice(-2200))}
 const r=run(process.execPath,['scripts/verification-results.mjs','finish']);console.log(r.stdout??'');process.stderr.write(r.stderr??'');process.exitCode=r.status??1
}
