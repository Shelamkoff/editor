import { isRichTextEmpty } from '../../shared/richTextEmpty.js'
// @ts-check
import { definitionStyles } from '../shared/definitionStyles.js'
import { setSanitizedHtml } from '../../plugin-kit/index.js'
import { setTrustedHtml } from '../../shared/sanitize/sanitizeHtml.js'
import { retainControlFocus } from '../shared/retainControlFocus.js'
import { columnsDataSchema } from '../../shared/blockSchemas/columns.js'
import { acceptsTextPayload, richTextFromPayload } from '../shared/textConversion.js'
import { createTextSelectionSlice } from '../shared/textSelectionSlice.js'
import { mergeRichText } from '../shared/mergeRichText.js'
import {
  COLUMNS_ICON,
  COLUMNS_STYLES,
  COLUMN_LAYOUT_ICONS,
  COLUMN_LAYOUT_KEYS,
  COLUMN_LAYOUTS,
} from './metadata.js'

function fitColumns(columns,size,context){
  const kept=columns.slice(0,size).map(column=>({...column}))
  while(kept.length<size){
    kept.push({id:context.createId('column'),content:''})
  }
  const last=kept[size-1]
  for(const column of columns.slice(size)){
    if(context.ownerDocument||globalThis.document){
      last.content=mergeRichText(last.content,column.content,context)
    }else if(column.content.trim()){
      // Direct data operations retain the literal join outside a DOM.
      last.content=last.content?last.content+'<br>'+column.content:column.content
    }
  }
  return kept
}

function changeLayout(data,layout,context){
  if(!Object.hasOwn(COLUMN_LAYOUTS,layout))throw new RangeError(`Unknown columns layout: ${layout}`)
  return {layout,columns:fitColumns(data.columns,COLUMN_LAYOUTS[layout].cols,context)}
}

/**
 * Create the immutable Columns v2 definition with stable column identities.
 * @param {{injectStyles?: boolean, css?: string}} [config]
 * @returns {import('../../plugin-kit/types').BlockPluginDefinition<{layout:string,columns:Array<{id:string,content:string}>}>}
 */
export function createColumnsPlugin(config = {}) {
  /** @type {import('../../plugin-kit/types').BlockCapabilities<{layout:string,columns:Array<{id:string,content:string}>}>} */
  const capabilities=Object.freeze({
    selectionSlice:createTextSelectionSlice(columnsDataSchema),
    formatting:Object.freeze({inlineTools:true}),
    empty:Object.freeze({isEmpty:(data,context)=>data.columns.every(column=>isRichTextEmpty(column.content,context))}),
    shortcuts:Object.freeze(/** @type {import('../../plugin-kit/types').ShortcutCapability<any>} */ ({
      handle(input){
        if(input.fieldKey.startsWith('column:')&&['Enter','Backspace','Delete'].includes(input.key))return {kind:'native'}
        return null
      },
    })),
    conversion:Object.freeze({
      selectionMode:'single',
      export(data){
        return {kind:'rich-text',data:{text:data.columns.map(column=>column.content).filter(Boolean).join('<br>')}}
      },
      canImport(payload){
        return acceptsTextPayload(payload)
      },
      import(payload){
        return {
          layout:'1-1',
          columns:[
            {id:'column-0',content:richTextFromPayload(payload)},
            {id:'column-1',content:''},
          ],
        }
      },
    }),
    clipboard:Object.freeze({
      slice(data,context){
        let any=false
        const selected=data.columns.map(column=>{
          const field=context.field(`column:${column.id}`)
          if(field)any=true
          return {...column,content:field?.selected??''}
        })
        if(!any)throw new Error('Columns clipboard selection is empty')
        const remaining=data.columns.map(column=>{
          const field=context.field(`column:${column.id}`)
          return field?{...column,content:field.before+field.after}:{...column}
        })
        return {
          parts:[{kind:/** @type {'local-block'} */ ('local-block'),data:{layout:data.layout,columns:selected}}],
          remaining:{layout:data.layout,columns:remaining},
          focus:null,
        }
      },
    }),
    settings:Object.freeze({
      kind:/** @type {'actions'} */('actions'),
      actions(data){
        return COLUMN_LAYOUT_KEYS.map(key=>Object.freeze({
          id:key,
          label:Object.freeze({key:`layout.${key}`,fallback:COLUMN_LAYOUTS[key].label}),
          icon:COLUMN_LAYOUT_ICONS[key],
          active:data.layout===key,
        }))
      },
      apply:changeLayout,
    }),
  })

  return Object.freeze({
    type:'columns',
    label:Object.freeze({key:'title',fallback:'Columns'}),
    icon:COLUMNS_ICON,
    styles: definitionStyles(config, COLUMNS_STYLES),
    schema:columnsDataSchema,
    capabilities,
    setup(runtimeContext){
      let destroyed=false
      return {
        create(initial,context){
          if(destroyed)throw new Error('Columns runtime is destroyed')
          const document=context.ownerDocument
          const wrapper=document.createElement('div')
          wrapper.className='oe-columns'
          wrapper.contentEditable='false'
          wrapper.tabIndex=-1
          const grid=document.createElement('div')
          grid.className='oe-columns__grid'
          const actions=document.createElement('div')
          actions.className='oe-columns__actions'
          actions.setAttribute('role','group')
          actions.setAttribute('aria-label',runtimeContext.t('layout','Layout'))
          wrapper.append(grid,actions)

          let data={layout:initial.layout,columns:initial.columns.map(column=>({...column}))}
          let readOnly=context.isReadOnly()
          let instanceDestroyed=false
          const nodes=new Map()
          const layoutButtons=new Map()
          for(const key of COLUMN_LAYOUT_KEYS){
            const button=document.createElement('button')
            button.type='button'
            button.className='oe-columns__layout-btn'
            button.dataset.layout=key
            button.title=`${runtimeContext.t('layout','Layout')} ${COLUMN_LAYOUTS[key].label}`
            button.setAttribute('aria-label',button.title)
            setTrustedHtml(button,COLUMN_LAYOUT_ICONS[key])
            button.addEventListener('click',()=>{
              if(instanceDestroyed||readOnly||data.layout===key)return
              retainControlFocus(wrapper,()=>context.updateData(current=>changeLayout(current,key,context)))
            },{signal:context.signal})
            layoutButtons.set(key,button)
            actions.appendChild(button)
          }

          const createColumn=column=>{
            const element=document.createElement('div')
            element.className='oe-columns__col'
            element.dataset.columnId=column.id
            element.contentEditable=readOnly?'false':'true'
            if(column.content)setSanitizedHtml(element,column.content)
            nodes.set(column.id,element)
            return element
          }

          const reconcile=(next,previousCanonical)=>{
            const previousContent=new Map((previousCanonical?.columns??[]).map(column=>[column.id,column.content]))
            const layout=COLUMN_LAYOUTS[next.layout]??COLUMN_LAYOUTS['1-1']
            grid.style.gridTemplateColumns=layout.grid
            const live=new Set()
            next.columns.forEach((column,index)=>{
              live.add(column.id)
              const element=nodes.get(column.id)??createColumn(column)
              element.contentEditable=readOnly?'false':'true'
              element.dataset.placeholder=`${runtimeContext.t('colPlaceholder','Column')} ${index+1}`
              // A completed rich field contains live widgets rather than its
              // serialized tokens. Preserve untouched authored fields through
              // sibling edits and let core keep their exact inline ownership.
              if(previousContent.get(column.id)!==column.content&&element.innerHTML!==column.content){
                if(column.content)setSanitizedHtml(element,column.content)
                else element.textContent=''
              }
              // Moving an unchanged contenteditable collapses the browser's
              // native selection. Reposition only when the order changed.
              if(grid.children[index]!==element)grid.insertBefore(element,grid.children[index]??null)
            })
            for(const [id,node] of nodes){
              if(live.has(id))continue
              node.remove()
              nodes.delete(id)
            }
            data={layout:next.layout,columns:next.columns.map(column=>({...column}))}
            actions.hidden=readOnly
            for(const [key,button] of layoutButtons){
              const active=key===data.layout
              button.classList.toggle('oe-columns__layout-btn--active',active)
              button.setAttribute('aria-pressed',String(active))
            }
          }

          reconcile(data)

          return {
            element:wrapper,
            read:()=>({
              layout:data.layout,
              columns:data.columns.map(column=>({
                id:column.id,
                content:nodes.get(column.id)?.innerHTML.trim()??column.content,
              })),
            }),
            update(next,previousCanonical){if(!instanceDestroyed)reconcile(next,previousCanonical)},
            editableFields:()=>Object.freeze(data.columns.flatMap(column=>{
              const element=nodes.get(column.id)
              return element?[Object.freeze({
                key:`column:${column.id}`,
                element,
                mode:/** @type {'rich-text'} */('rich-text'),
              })]:[]
            })),
            setReadOnly(value){
              readOnly=value
              actions.hidden=value
              for(const node of nodes.values())node.contentEditable=value?'false':'true'
            },
            focus(target){
              if(instanceDestroyed||readOnly)return
              const key=target?.fieldKey
              const id=key?.startsWith('column:')?key.slice(7):data.columns[0]?.id
              nodes.get(id)?.focus()
            },
            destroy(){instanceDestroyed=true;nodes.clear();layoutButtons.clear()},
          }
        },
        destroy(){destroyed=true},
      }
    },
  })
}
