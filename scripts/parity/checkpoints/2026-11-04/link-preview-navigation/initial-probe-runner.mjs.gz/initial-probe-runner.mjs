// Public toolbar action differential. Production bytes are served from exact
// Git objects; one fixed fixture and trusted input bridge serve every source.
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { readFile } from 'node:fs/promises'
import { createServer } from 'node:http'
import { extname, join, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const repo = process.cwd()
const digest = bytes => createHash('sha256').update(bytes).digest('hex')
const git = (...args) => execFileSync('git', args, { cwd: repo, maxBuffer: 64 * 1024 * 1024 })
const headBefore = git('rev-parse', 'HEAD').toString().trim()
const startedAt = new Date().toISOString()
const group = 'link-preview-templates'
const runnerBytes = await readFile(fileURLToPath(import.meta.url))


const fixture=Buffer.from(''),requests=[]
const dependencyRoot = resolve(process.env.EDITOR_DEPENDENCIES_ROOT ?? join(repo, 'node_modules'))
const { chromium } = await import(process.env.EDITOR_PLAYWRIGHT_PATH
  ? pathToFileURL(resolve(process.env.EDITOR_PLAYWRIGHT_PATH)).href : 'playwright')
const sources = [
  { label: 'v1', sha: '5e5c7f8d2d9e9a6cf2f95cfb7fd67aba227fa340', legacy: true, loaded: {} },
  { label: 'spec-baseline', sha: 'e981ff308000c1d92d7e820df95113c1e19bcee8', legacy: false, loaded: {} },
  { label: 'candidate', sha: headBefore, legacy: false, loaded: {} },
].map(source => ({ ...source, tree: git('rev-parse', `${source.sha}^{tree}`).toString().trim() }))
const imports = { dompurify: '/dependencies/dompurify/dist/purify.es.mjs' }
const dependencyVersions = { dompurify: JSON.parse(await readFile(join(dependencyRoot, 'dompurify/package.json'), 'utf8')).version }
const manifest = JSON.parse(await readFile(join(repo, 'package.json'), 'utf8'))
const pending = Object.keys(manifest.dependencies).filter(name => name.startsWith('@shelamkoff/'))
const packages = new Set()
while (pending.length) {
  const name = pending.shift()
  if (packages.has(name)) continue
  packages.add(name)
  const dependency = JSON.parse(await readFile(join(dependencyRoot, name, 'package.json'), 'utf8'))
  const entry = dependency.exports?.['.']
  const imported = typeof entry === 'string' ? entry : entry?.import
  assert.equal(typeof imported, 'string', `No public ESM entry for ${name}`)
  imports[name] = `/dependencies/${name}/${imported.replace(/^\.\//, '')}`
  dependencyVersions[name] = dependency.version
  pending.push(...Object.keys(dependency.dependencies ?? {}).filter(id => id.startsWith('@shelamkoff/')))
}

const cache = new Map(), dependencyFiles = {}, serverErrors = []
const server = createServer(async (request, response) => {
  try {
    const pathname = new URL(request.url, 'http://localhost').pathname
    if(pathname==='/destination'){requests.push({url:request.url,referer:request.headers.referer??''});response.setHeader('content-type','text/html');response.end('<!doctype html><title>Destination</title>Destination');return}
    if (pathname === '/favicon.ico') { response.statusCode = 204; response.end(); return }
    if (pathname === '/') {
      response.setHeader('content-type', 'text/html')
      response.end('<!doctype html><meta charset="utf-8"><title>Tool action comparison</title>'
        + '<script type="importmap">' + JSON.stringify({ imports }) + '</script><body></body>')
      return
    }
    response.setHeader('content-type', extname(pathname) === '.css' ? 'text/css' : 'text/javascript')
    if (pathname === '/fixture.js') { response.end(fixture); return }
    if (!cache.has(pathname)) {
      const source = sources.find(value => pathname.startsWith(`/${value.label}/`))
      assert(source || pathname.startsWith('/dependencies/'), `Unexpected source URL: ${pathname}`)
      const relative = pathname.slice(source ? source.label.length + 2 : '/dependencies/'.length)
      assert(relative && !relative.split('/').includes('..'), 'Invalid source path')
      const bytes = source ? git('show', `${source.sha}:${relative}`) : await readFile(join(dependencyRoot, relative))
      if (source) source.loaded[relative] = digest(bytes)
      else dependencyFiles[relative] = digest(bytes)
      cache.set(pathname, bytes)
    }
    response.end(cache.get(pathname))
  } catch (error) {
    serverErrors.push(String(error)); response.statusCode = 500; response.end(String(error))
  }
})
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))

const browser=await chromium.launch({executablePath:process.env.EDITOR_CHROME_PATH,headless:true}),context=await browser.newContext(),page=await context.newPage(),origin='http://127.0.0.1:'+server.address().port,errors=[]
page.on('pageerror',e=>errors.push(String(e)))
try{
 await page.goto(origin+'/');await page.evaluate(async()=>{const [{createEditor},{createLinkPreviewPlugin}]=await Promise.all([import('/candidate/core/index.js'),import('/candidate/plugins/link-preview/index.js')]);const holder=document.createElement('section');document.body.append(holder);window.probe=createEditor({holder,plugins:[createLinkPreviewPlugin()],inlineTools:[],data:{version:'2.0.0',blocks:[{id:'link',type:'linkPreview',dataVersion:1,data:{url:location.origin+'/destination?case=editable',title:'Navigation title',description:'Description',image:'',favicon:'',domain:'display.example',template:'horizontal'}}]}});window.activations=[];holder.addEventListener('click',event=>queueMicrotask(()=>window.activations.push({trusted:event.isTrusted,prevented:event.defaultPrevented,target:event.target.closest('a')?.className})))})
 const before=await page.evaluate(()=>window.probe.save()),card=page.locator('.oe-lp__card');await card.click();await page.waitForTimeout(500)
 const actual={pages:await Promise.all(context.pages().map(async p=>({url:p.url().replace(origin,''),openerIsNull:await p.evaluate(()=>opener===null)}))),requests,activations:await page.evaluate(()=>window.activations),canonical:await page.evaluate(()=>window.probe.save()),before,errors}
 console.log(JSON.stringify({head:headBefore,runnerSha256:digest(runnerBytes),actual},null,2))
}finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
