import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {readFileSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
const temp='test-results/audit-closeout-2026-11-01',initial=readFileSync(join(temp,'i18n-contexts-run-path.txt'),'utf8').trim(),m=JSON.parse(readFileSync(join(initial,'manifest.json')));assert.equal(m.outcome,'failed');assert.equal(m.sourceUnchanged,true);assert.equal(Object.keys(m.gates).length,18)
for(const[name,g]of Object.entries(m.gates))assert.equal(g.outcome,['native-i18n','native-i18n-trusted'].includes(name)?'failed':'passed')
const directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init','native-i18n','native-i18n-trusted'],{encoding:'utf8'}).trim(),env={...process.env,EDITOR_RESULTS_DIR:directory};writeFileSync(join(temp,'i18n-contexts-native-followup-path.txt'),directory)
for(const gate of ['native-i18n','native-i18n-trusted']){const r=spawnSync(process.execPath,['scripts/verification-results.mjs','run',gate,'--',process.execPath,join(temp,'run-i18n-contexts-gates.mjs'),gate],{env,encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});console.log(gate+': '+r.status+' '+(r.stdout??'').slice(-2000));process.stderr.write(r.stderr??'')}
const r=spawnSync(process.execPath,['scripts/verification-results.mjs','finish'],{env,encoding:'utf8',windowsHide:true});console.log(r.stdout??'');process.stderr.write(r.stderr??'');process.exitCode=r.status??1
