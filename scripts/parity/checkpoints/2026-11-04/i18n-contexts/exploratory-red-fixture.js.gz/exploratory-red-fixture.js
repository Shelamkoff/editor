export const i18nEchoCases=[{id:'literal-key/public-runtime-contexts'}]
export async function runI18nEchoCase({sourceBase,spec}){
 const base=new URL(sourceBase,import.meta.url),[core,paragraph,color]=await Promise.all(['core/index.js','plugins/paragraph/index.js','inline-plugins/color.js'].map(p=>import(new URL(p,base))))
 const holder=document.createElement('section');document.body.append(holder)
 const observations=[],planned=['create','dispose'],completedPhases=[],diagnostics=[]
 const check=(phase,property,actual,expected)=>observations.push({phase,property,actual,expected,status:JSON.stringify(actual)===JSON.stringify(expected)?'PASS':'FAIL'})
 const locale={__lang:'en'},definitions=[]
 for(const[namespace,definition]of [['plugin.paragraph',paragraph.createParagraphPlugin()],['inlinePlugin.color',color.createColorSwatchPlugin()]]){
  Object.assign(locale,{[namespace+'.echo']:namespace+'.echo',[namespace+'.empty']:'',[namespace+'.params']:'Hello {name}; {next}',[namespace+'.forms']:{one:'One {count}',other:'Other {count}'}})
  definitions.push({...definition,setup(context){for(const[key,fallback,params,expected]of [['echo','Fallback',undefined,namespace+'.echo'],['missing','Fallback',undefined,'Fallback'],['empty','Fallback',undefined,''],['params','Fallback',{name:'A $& {next}',next:'B'},'Hello A $& {next}; B'],['forms','Fallback',{count:21},'Other 21']])check('create',namespace+'/'+key,context.t(key,fallback,params),expected);return definition.setup(context)}})
 }
 let editor,error=null
 try{editor=core.createEditor({holder,locale,plugins:[definitions[0]],inlinePlugins:[definitions[1]],data:{version:'2.0.0',blocks:[{id:'a',type:'paragraph',dataVersion:2,data:{text:'Alpha {{swatch}} tail'},inline:{swatch:{type:'color',dataVersion:1,data:{value:'#aBcDef'}}}}]},onDiagnostic:d=>diagnostics.push(d)});completedPhases.push('create');check('create','history',[editor.canUndo,editor.canRedo],[false,false]);check('create','diagnostics',diagnostics,[]);editor.destroy();check('dispose','rootRemoved',!holder.querySelector('.oe-editor'),true);completedPhases.push('dispose')}catch(e){error=String(e.stack??e)}finally{editor?.destroy();holder.remove()}
 return{id:spec.id,spec,observations,planned,completedPhases,unsupported:[],error}
}
