import {execFileSync,spawnSync} from 'node:child_process'
import {readFileSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
import assert from 'node:assert/strict'
const temp='test-results/audit-closeout-2026-11-01',root='scripts/parity/checkpoints/2026-11-04/i18n-contexts',red=join(temp,'i18n-contexts-red.json'),mode=process.argv[2],source=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),env={...process.env,PYTHONIOENCODING:'utf-8',PYTHONDONTWRITEBYTECODE:'1'}
const run=(command,args,extra={})=>spawnSync(command,args,{encoding:'utf8',windowsHide:true,maxBuffer:128*1024*1024,env:{...env,...extra}})
const report=r=>{process.stdout.write(r.stdout??'');process.stderr.write(r.stderr??'');if(r.status!==0)process.exitCode=r.status??1}
if(mode==='proof'){
 const r=run(process.execPath,['scripts/parity/i18n-contexts.mjs']);assert.equal(r.error,undefined);writeFileSync(join(env.EDITOR_RESULTS_DIR,'comparison.json'),r.stdout);writeFileSync(join(env.EDITOR_RESULTS_DIR,'comparison.stderr'),r.stderr);assert.equal(r.status,1,r.stderr);assert.equal(r.stderr,'');assert.equal(JSON.parse(r.stdout).candidatePass,true)
 report(run(env.EDITOR_PYTHON_PATH,[root+'/review.py','--raw',join(env.EDITOR_RESULTS_DIR,'comparison.json'),'--red',red,'--candidate',source,'--output',join(env.EDITOR_RESULTS_DIR,'review.json')]))
}else if(mode==='controls')report(run(process.execPath,[root+'/controls.mjs',join(env.EDITOR_RESULTS_DIR,'comparison.json'),red,source,join(env.EDITOR_RESULTS_DIR,'controls')]))
else if(mode==='locale-unit')report(run(process.execPath,['--test','core/I18n.interpolation.test.js','core/I18n.plural.test.js','core/I18n.prototype.test.js','shared/localeParity.test.js']))
else if(mode?.startsWith('native-')){
 const names=mode==='native-controls'?['native-block-menus.html','native-library-boundaries.html','native-retained-tools.html']:[mode==='native-i18n'?'native-i18n-contexts.html':mode==='native-i18n-trusted'?'native-i18n-contexts-trusted.html':mode==='native-link'?'native-link-tool.html':'native-link-tool-trusted.html']
 for(const page of names){const r=run(process.execPath,['tests/browser/physical-history.mjs'],{EDITOR_NATIVE_PAGE:page});report(r);if(r.status!==0)break}
}else{
 const gates=['proof','controls','build','node','typecheck','types','locale-unit','browser','native-i18n','native-i18n-trusted','native-link','native-link-trusted','native-controls','package','bundle','heap','docs','site'],directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init',...gates],{encoding:'utf8'}).trim();writeFileSync(join(temp,'i18n-contexts-run-path.txt'),directory);env.EDITOR_RESULTS_DIR=directory
 for(const gate of gates){const command=['build','node','typecheck','types','package','docs','site'].includes(gate)?['cmd.exe','/d','/s','/c','npm run '+({build:'build',node:'test',typecheck:'typecheck',types:'test:types',package:'test:package',docs:'test:docs',site:'docs:check'})[gate]]:gate==='browser'?[process.execPath,'tests/browser/run.mjs']:gate==='bundle'?[process.execPath,'benchmarks/bundle-budget.mjs','--enforce']:gate==='heap'?[process.execPath,'tests/browser/heap-gate.mjs']:[process.execPath,join(temp,'run-i18n-contexts-gates.mjs'),gate],r=run(process.execPath,['scripts/verification-results.mjs','run',gate,...(gate==='controls'?['--require','proof']:[]),'--',...command]);console.log(gate+': '+r.status+' '+(r.stdout??'').slice(-1800));if(r.status!==0)console.error((r.stderr??'').slice(-2400))}
 const r=run(process.execPath,['scripts/verification-results.mjs','finish']);console.log(r.stdout??'');process.stderr.write(r.stderr??'');process.exitCode=r.status??1
}
