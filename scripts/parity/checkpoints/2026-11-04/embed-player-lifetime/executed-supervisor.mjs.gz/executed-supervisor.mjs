import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {writeFileSync} from 'node:fs'
const root='test-results/audit-closeout-2026-11-01',env={...process.env,PYTHONDONTWRITEBYTECODE:'1'},npm=s=>['cmd.exe','/d','/s','/c','npm run '+s]
for(const key of ['EDITOR_BROWSER_PAGE','EDITOR_BROWSER_ROOT','EDITOR_NATIVE_PAGE','EDITOR_NATIVE_FILTER','EDITOR_EMBED_PLAYER_LIFETIME_FILTER'])delete env[key]
const plans=[['types',npm('test:types')],['proof',[process.execPath,root+'/run-embed-player-lifetime-proof.mjs']],['controls',[process.execPath,root+'/run-embed-player-lifetime-controls.mjs'],'proof'],['docs',npm('test:docs')]]
const directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init',...plans.map(p=>p[0])],{env,encoding:'utf8'}).trim();env.EDITOR_RESULTS_DIR=directory;writeFileSync(root+'/embed-player-lifetime-run-path.txt',directory)
for(const[name,command,require]of plans){const r=spawnSync(process.execPath,['scripts/verification-results.mjs','run',name,...(require?['--require',require]:[]),'--',...command],{env,stdio:'inherit',windowsHide:true});assert.equal(r.error,undefined);console.log(JSON.stringify({gate:name,exitCode:r.status}))}
const r=spawnSync(process.execPath,['scripts/verification-results.mjs','finish'],{env,stdio:'inherit',windowsHide:true});assert.equal(r.status,0)
