import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {readFileSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
const temp='test-results/audit-closeout-2026-11-01',initial=readFileSync(join(temp,'link-tool-run-path.txt'),'utf8').trim(),old=JSON.parse(readFileSync(join(initial,'manifest.json')))
assert.equal(old.finishedAt!==null,true);assert.equal(old.outcome,'failed');assert.equal(old.sourceUnchanged,true)
const directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init','proof','controls'],{encoding:'utf8'}).trim(),env={...process.env,EDITOR_RESULTS_DIR:directory}
writeFileSync(join(temp,'link-tool-review-followup-path.txt'),directory)
for(const gate of ['proof','controls']){
 const args=gate==='proof'?['--input-type=module','-e',`import {execFileSync} from 'node:child_process';for(const mode of ['comparison','proof'])execFileSync(process.execPath,['${temp}/run-link-tool-gates.mjs',mode],{stdio:'inherit',windowsHide:true})`]:[join(temp,'run-link-tool-gates.mjs'),'controls']
 const r=spawnSync(process.execPath,['scripts/verification-results.mjs','run',gate,...(gate==='controls'?['--require','proof']:[]),'--',process.execPath,...args],{env,encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});console.log(gate+': '+r.status+' '+(r.stdout??'').slice(-1800));process.stderr.write(r.stderr??'')
}
const r=spawnSync(process.execPath,['scripts/verification-results.mjs','finish'],{env,encoding:'utf8',windowsHide:true});console.log(r.stdout??'');process.stderr.write(r.stderr??'');process.exitCode=r.status??1
