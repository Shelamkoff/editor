import {execFileSync,spawnSync} from 'node:child_process'
import {readFileSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
import assert from 'node:assert/strict'
const base='test-results/audit-closeout-2026-11-01',root='scripts/parity/checkpoints/2026-11-04/link-tool'
const mode=process.argv[2],env={...process.env,PYTHONIOENCODING:'utf-8',PYTHONDONTWRITEBYTECODE:'1'},source=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim()
const run=(command,args,extra={})=>spawnSync(command,args,{encoding:'utf8',windowsHide:true,maxBuffer:128*1024*1024,env:{...env,...extra}})
if(mode==='comparison'){
 const result=run(process.execPath,['scripts/parity/link-tool.mjs']);writeFileSync(join(env.EDITOR_RESULTS_DIR,'comparison.json'),result.stdout??'');writeFileSync(join(env.EDITOR_RESULTS_DIR,'comparison.stderr'),result.stderr??'');assert.equal(result.status,1,result.stderr);const d=JSON.parse(result.stdout);assert.equal(d.candidatePass,true);console.log(JSON.stringify({exitCode:result.status,candidatePass:d.candidatePass,rows:d.results.map(r=>({source:r.source,trustedPolicy:r.trustedPolicy,cases:r.cases.length,observations:r.cases.reduce((n,c)=>n+c.observations.length,0),differences:r.cases.reduce((n,c)=>n+c.observations.filter(o=>o.status==='FAIL').length,0),incomplete:r.cases.filter(c=>c.error).length,pageErrors:r.pageErrors.length}))}))
}else if(mode==='proof'){
 const r=run(env.EDITOR_PYTHON_PATH,[root+'/review.py','--raw',join(env.EDITOR_RESULTS_DIR,'comparison.json'),'--candidate',source,'--output',join(env.EDITOR_RESULTS_DIR,'review.json')]);process.stdout.write(r.stdout??'');process.stderr.write(r.stderr??'');process.exitCode=r.status??1
}else if(mode==='controls'){
 const r=run(process.execPath,[root+'/controls.mjs',join(env.EDITOR_RESULTS_DIR,'comparison.json'),source,join(env.EDITOR_RESULTS_DIR,'controls')]);process.stdout.write(r.stdout??'');process.stderr.write(r.stderr??'');process.exitCode=r.status??1
}else if(mode==='native'||mode==='native-trusted'){
 const r=run(process.execPath,['tests/browser/physical-history.mjs'],{EDITOR_NATIVE_PAGE:'native-link-tool'+(mode==='native-trusted'?'-trusted':'')+'.html'});process.stdout.write(r.stdout??'');process.stderr.write(r.stderr??'');process.exitCode=r.status??1
}else{
 const gates=['comparison','proof','controls','native','native-trusted','types','docs','site'],directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init',...gates],{encoding:'utf8'}).trim();writeFileSync(join(base,'link-tool-run-path.txt'),directory);env.EDITOR_RESULTS_DIR=directory
 for(const gate of gates){const command=['types','docs','site'].includes(gate)?['cmd.exe','/d','/s','/c','npm run '+({types:'test:types',docs:'test:docs',site:'docs:check'})[gate]]:[process.execPath,join(base,'run-link-tool-gates.mjs'),gate],r=run(process.execPath,['scripts/verification-results.mjs','run',gate,...(gate==='proof'?['--require','comparison']:gate==='controls'?['--require','proof']:[]),'--',...command]);console.log(gate+': '+r.status+' '+(r.stdout??'').slice(-1600));if(r.status!==0)console.error((r.stderr??'').slice(-3000))}
 const r=run(process.execPath,['scripts/verification-results.mjs','finish']);console.log(r.stdout??'');process.stderr.write(r.stderr??'');process.exitCode=r.status??1
}
