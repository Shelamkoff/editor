// @ts-check
import { EventBus } from '@shelamkoff/event-bus'
import { cloneEditorData } from '../shared/cloneEditorData.js'
import { snapshotContentStyles } from '../shared/contentStyles.js'
import { acquireStyleUrls, acquireContentStyles } from '../shared/styleRegistry.js'
import { createContentStyleScope, CONTENT_STYLE_OWNER } from '../shared/contentClassStyles.js'
import { invokeObserver } from '../shared/invokeObserver.js'
import { uid } from '../shared/uid.js'
import en from './locale/en.js'
import { I18n } from './I18n.js'
import { Diagnostics } from './Diagnostics.js'
import { LifecycleScope } from './LifecycleScope.js'
import { claimEditorHolder } from './EditorHolderOwnership.js'
import { ExtensionRegistry } from './ExtensionRegistry.js'
import { InlinePopupHost } from './InlinePopupHost.js'
import { InlineProjectionRuntime } from './InlineProjectionRuntime.js'
import { BlockReconciler } from './BlockReconciler.js'
import { DocumentRuntime } from './DocumentRuntime.js'
import { NativeInputController } from './NativeInputController.js'
import { KeyboardRouter } from './KeyboardRouter.js'
import { LogicalSelection } from './LogicalSelection.js'
import { SelectionController } from './SelectionController.js'
import { InteractionState } from './InteractionState.js'
import { EditorViewModel } from './EditorViewModel.js'
import { InlineCommandController } from './InlineCommandController.js'
import { InlineTriggerController } from './InlineTriggerController.js'
import { InlineWidgetInputController } from './InlineWidgetInputController.js'
import { SlashCommandController } from './SlashCommandController.js'
import { EditorBlocksApi, EditorHandle } from './PublicEditorApi.js'
import { ChangeNotifier } from './ChangeNotifier.js'
import { BlockToolbar } from './BlockToolbar.js'
import { ClipboardController } from './ClipboardController.js'
import { DragController } from './DragController.js'
import { InlineToolbar } from './InlineToolbar.js'

const CORE_STYLE_URLS=Object.freeze([
  new URL('./themes/variables.css',import.meta.url).href,
  new URL('./themes/light.css',import.meta.url).href,
  new URL('./themes/dark.css',import.meta.url).href,
])

function initI18n(config){
  const locale=config.locale??en
  const configuredLang=locale?.__lang
  const lang=typeof configuredLang==='string'?configuredLang:'en'
  return new I18n(locale,locale===en?undefined:en,lang)
}

function applyReadOnly(root,value){
  root.classList.toggle('oe-editor--read-only',value)
  if(value)root.setAttribute('aria-readonly','true')
  else root.removeAttribute('aria-readonly')
}

function immutableEventPayload(payload){
  if(payload===undefined)return undefined
  const owned=cloneEditorData(payload)
  const freeze=value=>{
    if(!value||typeof value!=='object'||Object.isFrozen(value))return value
    for(const item of Array.isArray(value)?value:Object.values(value))freeze(item)
    return Object.freeze(value)
  }
  return freeze(owned)
}

function emitSafe(events,type,payload,onError){
  try{events.emit(type,payload)}catch(error){
    if(typeof onError==='function')onError(error)
    else console.warn('[Editor] event observer failed',error)
  }
}

function snapshotDenseArray(value,label,{required=false}={}){
  if(value===undefined){
    if(required)throw new TypeError(`createEditor() requires a ${label} array`)
    return undefined
  }
  if(!Array.isArray(value))throw new TypeError(`createEditor() ${label} must be an array`)
  const snapshot=[]
  for(let index=0;index<value.length;index++){
    if(!Object.hasOwn(value,index))throw new TypeError(`createEditor() ${label} must be a dense array`)
    snapshot.push(value[index])
  }
  return snapshot
}

function snapshotEditorConfig(input){
  if(!input||typeof input!=='object'||Array.isArray(input))throw new TypeError('createEditor() requires a configuration object')
  const config={...input}
  config.plugins=snapshotDenseArray(config.plugins,'plugins',{required:true})
  config.inlinePlugins=snapshotDenseArray(config.inlinePlugins,'inlinePlugins')
  config.inlineTools=snapshotDenseArray(config.inlineTools,'inlineTools')
  config.contentStyles=snapshotContentStyles(config.contentStyles,'createEditor() contentStyles')
  for(const removed of ['validationMode','documentVersionPolicy','migrations']){
    if(Object.hasOwn(config,removed))throw new TypeError(`createEditor() ${removed} is no longer supported`)
  }

  if(config.plugins.length===0)throw new TypeError('createEditor() requires a non-empty plugins array')
  if(config.inlineTools){
    const types=new Set()
    for(const tool of config.inlineTools){
      if(!tool||typeof tool!=='object'||typeof tool.type!=='string'||!tool.type)throw new TypeError('createEditor() inline tool must have a non-empty string type')
      if(typeof tool.icon!=='string'||typeof tool.isActive!=='function'||typeof tool.toggle!=='function')throw new TypeError(`createEditor() inline tool "${tool.type}" is invalid`)
      if(types.has(tool.type))throw new Error(`Duplicate inline tool type: ${tool.type}`)
      types.add(tool.type)
    }
  }
  for(const field of ['readOnly','injectStyles','autofocus']){
    if(config[field]!==undefined&&typeof config[field]!=='boolean')throw new TypeError(`createEditor() ${field} must be a boolean`)
  }
  if(config.placeholder!==undefined&&typeof config.placeholder!=='string')throw new TypeError('createEditor() placeholder must be a string')
  if(config.defaultBlock!==undefined&&(typeof config.defaultBlock!=='string'||config.defaultBlock.length===0)){
    throw new TypeError('createEditor() defaultBlock must be a non-empty string')
  }
  if(config.locale!==undefined&&(config.locale===null||typeof config.locale!=='object'||Array.isArray(config.locale))){
    throw new TypeError('createEditor() locale must be an object')
  }
  for(const field of ['onReady','onChange','onValidationError','onDiagnostic']){
    if(config[field]!==undefined&&typeof config[field]!=='function')throw new TypeError(`createEditor() ${field} must be a function`)
  }
  if(config.diagnosticThresholds!==undefined&&(config.diagnosticThresholds===null||typeof config.diagnosticThresholds!=='object'||Array.isArray(config.diagnosticThresholds))){
    throw new TypeError('createEditor() diagnosticThresholds must be an object')
  }
  if(config.theme!==undefined&&(typeof config.theme!=='string'||config.theme.length===0)){
    throw new TypeError('createEditor() theme must be a non-empty string')
  }
  if(config.minHeight!==undefined&&(!Number.isFinite(config.minHeight)||config.minHeight<0)){
    throw new RangeError('createEditor() minHeight must be a finite number greater than or equal to 0')
  }
  for(const field of [
    'changeDebounceMs','historyCoalesceMs','dragThreshold','mobileBreakpoint',
    'blockInsertAnimationMs','blockMoveAnimationMs','blockRemoveAnimationMs',
  ]){
    if(config[field]!==undefined&&(!Number.isFinite(config[field])||config[field]<0)){
      throw new RangeError(`createEditor() ${field} must be a finite number greater than or equal to 0`)
    }
  }
  if(config.historyMaxStack!==undefined&&(!Number.isSafeInteger(config.historyMaxStack)||config.historyMaxStack<1)){
    throw new RangeError('createEditor() historyMaxStack must be a positive safe integer')
  }
  if(config.historyMaxBytes!==undefined&&(!Number.isSafeInteger(config.historyMaxBytes)||config.historyMaxBytes<1)){
    throw new RangeError('createEditor() historyMaxBytes must be a positive safe integer')
  }
  if(config.toolboxFilterThreshold!==undefined&&(!Number.isSafeInteger(config.toolboxFilterThreshold)||config.toolboxFilterThreshold<0)){
    throw new RangeError('createEditor() toolboxFilterThreshold must be a non-negative safe integer')
  }
  return config
}

/**
 * Editor composition root for the canonical document runtime.
 *
 * @param {{
 *   holder: HTMLElement,
 *   plugins: import('../plugin-kit/types').BlockPluginDefinition[],
 *   inlinePlugins?: import('../plugin-kit/types').InlinePluginDefinition[],
 *   inlineTools?: import('../inline-tools/types').InlineTool[],
 *   data?: unknown,
 *   defaultBlock?: string,
 *   placeholder?: string,
 *   readOnly?: boolean,
 *   autofocus?: boolean,
 *   injectStyles?: boolean,
 *   contentStyles?: readonly string[],
 *   theme?: string,
 *   minHeight?: number,
 *   locale?: Record<string, any>,
 *   onReady?: (editor:any)=>void|Promise<void>,
 *   onChange?: (document:any)=>void|Promise<void>,
 *   onValidationError?: (issue:any)=>void,
 *   onDiagnostic?: (diagnostic:import('./publicTypes').EditorDiagnostic)=>void|Promise<void>,
 *   diagnosticThresholds?: Partial<import('./publicTypes').DiagnosticThresholds>,
 *   changeDebounceMs?: number,
 *   historyMaxStack?: number,
 *   historyMaxBytes?: number,
 *   historyCoalesceMs?: number,
 *   dragThreshold?: number,
 *   toolboxFilterThreshold?: number,
 *   mobileBreakpoint?: number,
 *   blockInsertAnimationMs?: number,
 *   blockMoveAnimationMs?: number,
 *   blockRemoveAnimationMs?: number,
 * }} input
 */
export function createEditorRuntime(input){
  const config=snapshotEditorConfig(input)
  const diagnostics=config.onDiagnostic?new Diagnostics(config.onDiagnostic,config.diagnosticThresholds):null
  const reportDiagnostic=(code,operation,error)=>diagnostics?.emit(code,{
    operation,
    errorName:diagnostics.errorName(error),
  })
  const holder=config.holder
  const HTMLElementCtor=holder?.ownerDocument?.defaultView?.HTMLElement??globalThis.HTMLElement
  if(!HTMLElementCtor||!(holder instanceof HTMLElementCtor)){
    const error=new TypeError('createEditor() requires an HTMLElement holder')
    reportDiagnostic('editor.create.failed','createEditor',error)
    throw error
  }

  const originalHolderChildren=[...holder.childNodes]

  let lease
  try{
    lease=claimEditorHolder(holder)
  }catch(error){
    reportDiagnostic('editor.create.failed','createEditor',error)
    throw error
  }
  const lifecycle=new LifecycleScope(error=>reportDiagnostic('cleanup.failed','lifecycle.destroy',error))
  lifecycle.register(lease)
  try{
  const document=holder.ownerDocument
  const root=document.createElement('div')
  lifecycle.register({destroy(){root.remove()}})
  root.className='oe-editor oe-theme-'+(config.theme??'dark')
  const contentStyleScope=config.contentStyles.length?createContentStyleScope():null
  if(contentStyleScope)root.setAttribute(CONTENT_STYLE_OWNER,contentStyleScope.id)
  root.tabIndex=-1
  if(config.minHeight!==undefined)root.style.minHeight=String(config.minHeight)+'px'
  const mobileBreakpoint=config.mobileBreakpoint??768
  const updateViewportMode=()=>root.classList.toggle(
    'oe-editor--mobile',
    (document.defaultView?.innerWidth??Infinity)<mobileBreakpoint,
  )
  updateViewportMode()
  const onViewportResize=()=>updateViewportMode()
  document.defaultView?.addEventListener?.('resize',onViewportResize)
  lifecycle.register({destroy(){document.defaultView?.removeEventListener?.('resize',onViewportResize)}})
  const blocksElement=document.createElement('div')
  blocksElement.className='oe-blocks'
  const clickArea=document.createElement('div')
  clickArea.className='oe-click-area'
  root.append(blocksElement,clickArea)
  holder.replaceChildren(root)

  const events=new EventBus()
  const publishOwned=(type,payload)=>emitSafe(events,type,payload,error=>reportDiagnostic('command.failed',`event:${type}`,error))
  const emit=(type,payload)=>publishOwned(type,immutableEventPayload(payload))
  const i18n=initI18n(config)
  const configuredInlineTools=config.inlineTools??[]
  let runtime
  let reconciler
  let logicalSelection
  let interaction
  let view
  let notifier
  let toolbar=null
  let clipboard=null
  let destroyed=false
  let ready=false

  const popup=lifecycle.register(new InlinePopupHost({
    root,
    isReadOnly:()=>runtime?.readOnly??(config.readOnly===true),
    observe:operation=>runtime?runtime.observeExtension(operation):operation(),
  }))

  const registry=lifecycle.register(new ExtensionRegistry({
    ownerDocument:document,
    blocks:config.plugins,
    inline:config.inlinePlugins??[],
    defaultBlock:config.defaultBlock,
    placeholder:config.placeholder,
    acquireStyles:config.injectStyles!==false,
    contentStyles:config.contentStyles,
    translate:(key,fallback='',params=undefined)=>{
      // Missing keys never inspect interpolation getters. Own values are captured
      // once so count selection cannot borrow an inherited or changing count.
      if(!i18n.has(key))return fallback
      const values=params?Object.assign(Object.create(null),params):undefined
      const count=values?.count
      return typeof count==='number'?i18n.plural(key,count,values):i18n.t(key,values)
    },
    showPopup:(owner,anchor,content,cleanup)=>popup.showPopup(owner,anchor,content,cleanup),
  }))

  const styles=config.injectStyles===false?null:lifecycle.register(acquireStyleUrls(CORE_STYLE_URLS,document))
  if(contentStyleScope)lifecycle.register(acquireContentStyles(config.contentStyles,document,contentStyleScope))
  /** @type {NativeInputController | null} */
  let nativeInput=null
  const inlineProjection=new InlineProjectionRuntime({
    contentStyleScope,
    preservePendingField:(blockId,key,element)=>nativeInput?.canPreservePresentationField(blockId,key,element)??false,
    registry,
    ownerDocument:document,
    readOnly:config.readOnly===true,
  })

  let crossSelection=null
  const selectionPort={
    capture:()=>crossSelection?.bookmark??logicalSelection?.capture()??null,
    restore:(bookmark,{reason=''}={})=>{
      if(bookmark?.anchor.blockId!==bookmark?.focus.blockId&&crossSelection?.restore(bookmark))return true
      if(reason==='history')return view?.restoreHistorySelection(bookmark)??false
      return logicalSelection?.restore(bookmark)
    },
  }

  let keyboardRouter=null

  runtime=lifecycle.register(new DocumentRuntime({
    registry,
    data:config.data,
    ownerDocument:document,
    readOnly:config.readOnly===true,
    createId:prefix=>prefix+'-'+uid(),
    selection:selectionPort,
    onValidationError:config.onValidationError,
    history:{maxStack:config.historyMaxStack??100,maxBytes:config.historyMaxBytes},
    diagnostics,
    requestSplit:id=>keyboardRouter?.split(id),
    requestExit:id=>keyboardRouter?.exit(id),
    onCommit:event=>{
      // The model and history are already committed. A fallible presentation,
      // clipboard, timer, or event adapter must not suppress independent
      // observers of that same immutable transaction.
      const complete=(operation,name)=>{
        try { operation() }
        catch(error) {
          try { reportDiagnostic('command.failed','commit.'+name,error) } catch {}
        }
      }
      // Revoke stale clipboard work before fallible UI refresh/notifications.
      complete(()=>clipboard?.handleTransaction(event),'clipboard')
      complete(()=>nativeInput?.handleTransaction(),'native-input')
      complete(()=>interaction?.reconcile(),'interaction')
      complete(()=>toolbar?.refresh(),'toolbar')
      complete(()=>notifier?.schedule(),'change-notifier')
      // This callback receives the engine's captured, deeply frozen change
      // graph and the runtime's frozen history envelope. Share that owned
      // graph across these notifications; other event sources still capture
      // through emit(), including shallow-frozen external values.
      complete(()=>publishOwned('transaction:committed',event),'transaction-event')
      complete(()=>publishOwned('document:changed',Object.freeze({
        origin:event.origin,
        action:event.action,
        changes:event.changes,
      })),'document-event')
      complete(()=>publishOwned('history:changed',event.history),'history-event')
    },
    projectorFactory:({activationResolver,contextFactory,projectPresentation,reportPresentationFailure})=>{
      reconciler=new BlockReconciler({
        container:blocksElement,
        registry,
        contextFactory,
        projectPresentation,
        reportPresentationFailure,
        activationResolver,
        inlineProjection,
        readOnly:config.readOnly===true,
        animationDurations:{
          insertMs:config.blockInsertAnimationMs??350,
          moveMs:config.blockMoveAnimationMs??200,
          removeMs:config.blockRemoveAnimationMs??350,
        },
      })
      return reconciler
    },
  }))

  logicalSelection=new LogicalSelection({root,reconciler})
  interaction=new InteractionState({
    runtime,
    reconciler,
    onChange:change=>{
      if(change.previousCurrentId!==change.currentId){
        emit('currentBlock:changed',{currentId:change.currentId})
      }
      const previous=change.previousSelectedIds
      const selected=change.selectedIds
      if(previous.length!==selected.length||previous.some((id,index)=>id!==selected[index])){
        emit('selection:changed',{selectedIds:selected})
      }
    },
    onError:error=>reportDiagnostic('command.failed','interaction.change',error),
    onFocus:id=>toolbar?.showFor(id),
  })
  view=new EditorViewModel({runtime,reconciler,interaction,selection:logicalSelection})
  crossSelection=lifecycle.register(new SelectionController({root,runtime,reconciler,view}))
  let triggerController=null
  // Native callbacks can queue after editing, then outlive a terminal
  // read-only round trip without any authored document revision.
  const queueTriggerRefresh=()=>{
    const modeEpoch=runtime.modeEpoch
    queueMicrotask(()=>{
      if(!destroyed&&runtime.modeEpoch===modeEpoch)triggerController?.refresh()
    })
  }
  const inlineWidgetInput=lifecycle.register(new InlineWidgetInputController({
    root,
    runtime,
    registry,
    reconciler,
    projection:inlineProjection,
    selection:logicalSelection,
    diagnostics,
    onNativeSettled:()=>triggerController?.retireFreshQueryForNativeEdit(),
    onOwnedBeforeInput:()=>nativeInput?.retirePendingInput(),
  }))
  nativeInput=lifecycle.register(new NativeInputController({
    root,
    runtime,
    reconciler,
    crossSelection,
    selection:logicalSelection,
    projection:inlineProjection,
    inlineWidgetInput,
    onControlledInput:queueTriggerRefresh,
    coalesceMs:config.historyCoalesceMs??300,
  }))
  const inlineCommands=new InlineCommandController({
    runtime,
    registry,
    selection:logicalSelection,
    onFreshText:queueTriggerRefresh,
  })
  const triggers=lifecycle.register(new InlineTriggerController({
    root,
    registry,
    reconciler,
    selection:logicalSelection,
    commands:inlineCommands,
    isComposing:()=>nativeInput.isComposing,
    isReadOnly:()=>runtime.readOnly,
    projection:inlineProjection,
    nativeInputRoute:event=>inlineWidgetInput.nativeInputRoute(event),
    observe:operation=>runtime.observeExtension(operation),
    reportError:error=>reportDiagnostic('command.failed','inline-trigger.cancel',error),
  }))
  triggerController=triggers

  const slashCommands=lifecycle.register(new SlashCommandController({
    root,
    runtime,
    registry,
    reconciler,
    selection:logicalSelection,
    view,
    inlineCommands,
    isComposing:()=>nativeInput.isComposing,
    translate:(key,fallback='')=>{
      const translated=i18n.t(key)
      return i18n.has(key)?translated:fallback
    },
    t:(key,fallback='')=>{
      const translated=i18n.t(key)
      return i18n.has(key)?translated:fallback
    },
  }))

  clipboard=lifecycle.register(new ClipboardController({
    root,
    runtime,
    registry,
    reconciler,
    selection:logicalSelection,
    view,
    crossSelection,
    inlineCommands,
    isComposing:()=>nativeInput.isComposing,
    diagnostics,
  }))

  toolbar=lifecycle.register(new BlockToolbar({
    root,
    runtime,
    registry,
    view,
    selection:logicalSelection,
    selectionPort:crossSelection,
    inlineCommands,
    reportError:(code,error)=>reportDiagnostic(code,'block-toolbar',error),
    translate:(key,fallback='')=>{
      const translated=i18n.t(key)
      return i18n.has(key)?translated:fallback
    },
    t:(key,fallback='')=>{
      const translated=i18n.t(key)
      return i18n.has(key)?translated:fallback
    },
    filterThreshold:config.toolboxFilterThreshold??7,
  }))

  const drag=lifecycle.register(new DragController({
    runtime,
    view,
    handle:toolbar.dragHandle,
    threshold:config.dragThreshold??5,
  }))

  const inlineToolbar=lifecycle.register(new InlineToolbar({
    root,
    runtime,
    registry,
    reconciler,
    selection:logicalSelection,
    selectionPort:crossSelection,
    view,
    tools:configuredInlineTools,
    reportError:(code,error)=>reportDiagnostic(code,'inline-toolbar',error),
    translate:(key,fallback='',params=undefined)=>{
      const translated=i18n.t(key,params)
      return i18n.has(key)?translated:fallback
    },
  }))

  keyboardRouter=lifecycle.register(new KeyboardRouter({
    root,
    runtime,
    registry,
    reconciler,
    selection:logicalSelection,
    view,
    inlineToolbar,
    inlineCommands,
    crossSelection,
    isComposing:()=>nativeInput.isComposing,
    reportError:error=>reportDiagnostic('command.failed','keyboard.shortcut',error),
  }))

  const onClickAreaMouseDown=event=>{
    if(event.button===0&&!runtime.readOnly)event.preventDefault()
  }
  const onClickArea=event=>{
    if(event.target===clickArea)keyboardRouter.appendDefault()
  }
  clickArea.addEventListener('mousedown',onClickAreaMouseDown)
  clickArea.addEventListener('click',onClickArea)
  lifecycle.register({destroy(){
    clickArea.removeEventListener('mousedown',onClickAreaMouseDown)
    clickArea.removeEventListener('click',onClickArea)
  }})

  // Observe this owner document so native focus outside the editor can
  // supersede a pending request; foreign elements never acquire our currentId.
  const onFocusIn=event=>interaction.observeNativeFocus(event.target)
  document.addEventListener('focusin',onFocusIn)
  lifecycle.register({destroy(){document.removeEventListener('focusin',onFocusIn)}})

  notifier=lifecycle.register(new ChangeNotifier(
    ()=>runtime.save(),
    config.onChange,
    Number.isFinite(config.changeDebounceMs)?Math.max(0,Number(config.changeDebounceMs)):250,
    document.defaultView??globalThis,
    error=>reportDiagnostic('save.failed','onChange',error),
  ))

  applyReadOnly(root,runtime.readOnly)

  const blocks=new EditorBlocksApi({runtime,view,selection:crossSelection,isDestroyed:()=>destroyed})
  let editor
  const destroy=()=>{
    if(destroyed)return
    destroyed=true
    ready=false
    lifecycle.destroy()
    emit('editor:destroyed')
  }
  const setReadOnly=value=>runtime.setReadOnly(value,discardProjectionEdits=>{
    // The projection has already accepted this transition. Independently
    // complete every terminal owner even when a plugin's cancellation/cleanup
    // throws; never roll back the successful read-only state because an
    // observer failed or leave later resources with stale authority.
    const mode=runtime.readOnly
    const complete=(name,operation)=>{
      try{operation()}catch(error){
        try{reportDiagnostic('cleanup.failed','read-only.'+name,error)}catch{}
      }
    }
    // Revoke async clipboard authority before any fallible observer/control.
    if(mode)complete('clipboard',()=>clipboard?.cancelPendingTask())
    complete('triggers',()=>triggers.setReadOnly(mode))
    complete('slash',()=>slashCommands.setReadOnly(mode))
    complete('popup',()=>popup.setReadOnly(mode))
    complete('root',()=>applyReadOnly(root,mode))
    complete('block-toolbar',()=>toolbar?.setReadOnly(mode))
    complete('inline-toolbar',()=>inlineToolbar.setReadOnly(mode))
    complete('native-input',()=>nativeInput.setReadOnly(mode,discardProjectionEdits))
    complete('drag',()=>drag.setReadOnly(mode))
    complete('read-only-notice',()=>emit('readOnly:changed',{readOnly:mode}))
    complete('history-notice',()=>emit('history:changed',{
      canUndo:runtime.canUndo,canRedo:runtime.canRedo,
    }))
  })

  editor=new EditorHandle({
    runtime,
    view,
    blocks,
    destroy,
    setReadOnly,
    inlineCommands,
    subscribe:(type,listener)=>events.on(type,payload=>{
      invokeObserver(listener,[payload],error=>reportDiagnostic('command.failed',`event:${type}`,error))
    }),
    isReady:()=>ready,
    isDestroyed:()=>destroyed,
  })

  if(config.autofocus&&!runtime.readOnly)view.focus()

  queueMicrotask(()=>{
    if(destroyed)return
    ready=true
    emit('editor:ready')
    // Event listeners run synchronously and can destroy or replace this
    // editor. Do not invoke the retained onReady hook after that teardown.
    if(destroyed)return
    invokeObserver(config.onReady,[editor],error=>reportDiagnostic('command.failed','onReady',error))
  })

  return editor
  }catch(error){
    lifecycle.destroy()
    holder.replaceChildren(...originalHolderChildren)
    reportDiagnostic('editor.create.failed','createEditor',error)
    throw error
  }
}
