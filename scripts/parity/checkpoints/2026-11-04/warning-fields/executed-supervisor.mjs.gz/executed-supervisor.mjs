import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {readFileSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
const temp='test-results/audit-closeout-2026-11-01/',root='scripts/parity/checkpoints/2026-11-04/warning-fields',mode=process.argv[2],source=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),env={...process.env,PYTHONIOENCODING:'utf-8',PYTHONDONTWRITEBYTECODE:'1'}
const run=(command,args,extra={})=>spawnSync(command,args,{encoding:'utf8',windowsHide:true,maxBuffer:128*1024*1024,env:{...env,...extra}}),report=r=>{process.stdout.write(r.stdout??'');process.stderr.write(r.stderr??'');if(r.status!==0)process.exitCode=r.status??1}
if(mode==='proof'){
 const r=run(process.execPath,['scripts/parity/warning-fields.mjs']);assert.equal(r.error,undefined);writeFileSync(join(env.EDITOR_RESULTS_DIR,'comparison.json'),r.stdout);writeFileSync(join(env.EDITOR_RESULTS_DIR,'comparison.stderr'),r.stderr);assert.equal(r.status,1,r.stderr);assert.equal(r.stderr,'');assert.equal(JSON.parse(r.stdout).candidatePass,true)
 report(run(env.EDITOR_PYTHON_PATH,[root+'/review.py','--raw',join(env.EDITOR_RESULTS_DIR,'comparison.json'),'--candidate',source,'--output',join(env.EDITOR_RESULTS_DIR,'review.json')]))
}else if(mode==='controls')report(run(process.execPath,[root+'/controls.mjs',join(env.EDITOR_RESULTS_DIR,'comparison.json'),source,join(env.EDITOR_RESULTS_DIR,'controls')]))
else if(mode?.startsWith('native-'))report(run(process.execPath,['tests/browser/physical-history.mjs'],{EDITOR_NATIVE_PAGE:mode==='native-existing'?'native-plugin-parity.html':mode==='native-warning'?'native-warning-fields.html':'native-warning-fields-trusted.html',EDITOR_NATIVE_FILTER:mode==='native-existing'?'Warning':''}))
else{
 const gates=['proof','controls','native-warning','native-warning-trusted','native-existing','docs','site'],directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init',...gates],{encoding:'utf8'}).trim();writeFileSync(temp+'warning-fields-run-path.txt',directory);env.EDITOR_RESULTS_DIR=directory
 for(const gate of gates){const command=['docs','site'].includes(gate)?['cmd.exe','/d','/s','/c','npm run '+(gate==='docs'?'test:docs':'docs:check')]:[process.execPath,temp+'run-warning-fields-gates.mjs',gate],r=run(process.execPath,['scripts/verification-results.mjs','run',gate,...(gate==='controls'?['--require','proof']:[]),'--',...command]);console.log(gate+': '+r.status+' '+(r.stdout??'').slice(-1600));if(r.status!==0)console.error((r.stderr??'').slice(-2200))}
 const r=run(process.execPath,['scripts/verification-results.mjs','finish']);console.log(r.stdout??'');process.stderr.write(r.stderr??'');process.exitCode=r.status??1
}
