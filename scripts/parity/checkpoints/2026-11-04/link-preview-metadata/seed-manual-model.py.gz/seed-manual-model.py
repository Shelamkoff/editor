"""Literal concrete metadata state, history frames and callback ownership model."""
import argparse,gzip,hashlib,json,re,subprocess,sys
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
sys.dont_write_bytecode=True
V1='5e5c7f8d2d9e9a6cf2f95cfb7fd67aba227fa340';BASELINE='e981ff308000c1d92d7e820df95113c1e19bcee8';RED='b4ac89a0ac56c679f25cc0ef1e84ca821616ee2c';GREEN='38dd32300fa68e6586a2c2a521aacb1eb6391923'
BEFORE='https://before.example/article';AFTER='https://next.example/article';NEWER='https://newer.example/article';PIXEL='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jH1sAAAAASUVORK5CYII='
META=dict(title='Metadata title',description='Metadata description',image=PIXEL,favicon=PIXEL,domain='display.example');LIFETIMES=['replace','mode','remove-undo','render','destroy'];PHASES=['load','submit','intervene','complete','replay','dispose']
def sha(b):return hashlib.sha256(b).hexdigest()
def same(a,b):return json.dumps(a,sort_keys=True,ensure_ascii=False)==json.dumps(b,sort_keys=True,ensure_ascii=False)
def specs():return[dict(id=v,variant=v) for v in ['no-provider','adjacent','intervening','reject','auto-replay']]+[dict(id=v+'/'+o,variant=v,outcome=o) for v in LIFETIMES for o in ['resolve','reject']]+[dict(id='typed-'+v,variant='typed-'+v) for v in ['mode','remove-undo','render','destroy']]+[dict(id=v,variant=v,currentOnly=True) for v in ['host-title','host-away-back','host-url']]
def data(url=BEFORE,loaded=True):return dict(url=url,title='Before title' if loaded else '',description='Before description' if loaded else '',image='',favicon='',domain={BEFORE:'before.example',AFTER:'next.example',NEWER:'newer.example'}[url],template='horizontal')
def document(value,old=False,other=False):return[dict(id='link',type='linkPreview',**({} if old else dict(dataVersion=1)),data=value),dict(id='b',type='paragraph',**({} if old else dict(dataVersion=2)),data=dict(text='BravoX' if other else 'Bravo'))]
def view(value):return dict(input=value['url'],href=value['url'],title=value['title'] or value['url'],description=value['description'])
def situation(s,old=False,red=False):
 v=s['variant'];typed=v.startswith('typed-');life=v[6:] if typed else v;automatic=v=='auto-replay';request=v!='no-provider' and not typed;initial=data(BEFORE,not automatic);submitted=initial if automatic else data(AFTER,False);current=submitted;other=v=='intervening';retired=life in LIFETIMES or v=='host-url';broken=red and v=='intervening'
 if v=='replace':current=data(NEWER,False)
 elif life in ['render','destroy']:current=dict(data(NEWER),title='Rendered successor' if life=='render' else 'Successor title')
 elif v=='host-title':current=dict(current,title='Host title')
 elif v=='host-url':current=data(NEWER)
 completed=current
 if request and not retired and v!='reject' and not broken:completed=dict(current,**META);completed['title']='Host title' if v=='host-title' else '' if v=='host-away-back' else META['title']
 if v=='replace':completed=dict(current,**dict(META,title='Newest metadata'))
 before=document(initial,old);sub=document(submitted,old);last=document(completed,old,other);host=document(dict(submitted,title='Host title'),old)
 frames=[before,last];names=['block.update' if automatic else 'native-input']
 if life=='destroy':frames=[last];names=[]
 elif v=='intervening':frames=[before,sub,document(submitted,old,True)]+([] if broken else [last]);names=['native-input','native-input']+([] if broken else ['block.update'])
 elif v=='host-title':frames=[before,sub,host,last];names=['native-input','block.update','block.update']
 elif v=='host-away-back':frames=[before,sub,host,sub,last];names=['native-input','block.update','block.update','block.update']
 elif v=='host-url' or life=='render':frames=[before,sub,last];names=['native-input','block.update' if v=='host-url' else 'document.render']
 flags=[False,False] if life=='destroy' else [True,True] if life=='remove-undo' else [True,False]
 requests=[] if not request else [BEFORE if automatic else AFTER]+([NEWER] if v=='replace' else [AFTER] if broken else [])
 return dict(v=v,typed=typed,life=life,automatic=automatic,request=request,retired=retired,broken=broken,initial=initial,submitted=submitted,current=current,completed=completed,other=other,frames=frames,names=names,flags=flags,requests=requests)
def observations(s,old=False,red=False,history=True):
 q=situation(s,old,red);v=q['v'];result=[]
 def add(phase,**items):result.extend((phase,k,value) for k,value in items.items())
 add('load',canonical=document(q['initial'],old),history=[False,False],producerPort='undefined' if old else 'function')
 submit_view=dict(view(q['initial']),input=AFTER) if q['typed'] else view(q['submitted'])
 first_requests=[] if not q['request'] else [BEFORE if q['automatic'] else AFTER]
 add('submit',canonical=document(q['submitted'],old),view=submit_view,requests=first_requests,pendingSignals=[False] if q['request'] else [],history=[False,False] if q['automatic'] else [True,False])
 add('intervene',canonical=document(q['current'],old,q['other']))
 if q['request']:add('intervene',firstAborted=q['retired'] or q['broken'])
 add('intervene',requests=q['requests'])
 add('complete',canonical=document(q['completed'],old,q['other']),view=view(q['completed']),unhandled=[],requests=q['requests'])
 undo=list(reversed(q['frames'][:-1]));redo=q['frames'][1:]
 if history:add('replay',historyBefore=q['flags'],undoStates=undo,redoStates=redo)
 add('replay',finalCanonical=document(q['completed'],old,q['other']),cursorRoundtrip=q['flags'],requestCountAfterReplay=len(q['requests']))
 errors=[dict(name='Error',message='Uncaught Error: Cannot mutate instance context during applying-projection phase')] if red and q['life'] in ['remove-undo','render'] else []
 add('dispose',rootsRemoved=True,unhandled=[],pageErrors=errors)
 return result
def native(s,other=True):
 q=situation(s);r=[]
 if not q['automatic']:
  r.append(dict(kind='url-input',trusted=True,type='insertText'))
  if not q['typed']:r.append(dict(kind='submit',trusted=True,key='Enter'))
 if q['v']=='replace':r.extend([dict(kind='url-input',trusted=True,type='insertText'),dict(kind='submit',trusted=True,key='Enter')])
 if q['v']=='intervening' and other:r.append(dict(kind='other-input',trusted=True,type='insertText'))
 return r
def events(s,red=False):
 q=situation(s,red=red);v=q['v'];result=[]
 def add(phase,action,origin,name):result.append(dict(owner='first',phase=phase,action=action,origin=origin,name=name))
 if not q['automatic']:add('submit','commit','native-input','native-input')
 if v in ['intervening','replace']:add('intervene','commit','native-input','native-input')
 elif q['life']=='remove-undo':add('intervene','commit','external','block.remove');add('intervene','undo','history','block.remove')
 elif q['life']=='render':add('intervene','commit','external','document.render')
 elif v.startswith('host-'):
  add('intervene','commit','external','block.update')
  if v=='host-away-back':add('intervene','commit','external','block.update')
 if q['request'] and not q['retired'] and v!='reject' and not q['broken'] or v=='replace':add('complete','commit','plugin','block.update')
 for action,names in [('undo',reversed(q['names'])),('redo',q['names'])]:
  for name in names:add('replay',action,'history',name)
 return result
def request_trace(s,red=False):
 q=situation(s,red=red)
 if not q['request']:return []
 first=dict(url=BEFORE if q['automatic'] else AFTER,phase='load' if q['automatic'] else 'submit',aborted=q['retired'] or q['v']=='reject' or q['broken'])
 return [first]+([dict(url=NEWER if q['v']=='replace' else AFTER,phase='intervene',aborted=q['broken'])] if q['v']=='replace' or q['broken'] else [])
def changes(s):
 q=situation(s)
 if q['automatic']:return []
 return [dict(phase='intervene' if q['v']=='intervening' or q['life'] in ['remove-undo','render','destroy'] else 'dispose',trusted=True,connected=True,blockConnected=True,active=False,value=NEWER if q['v'] in ['replace','host-url'] else AFTER)]
def verify_current(case,red=False,history=True,other=True):
 s=case['spec'];assert case['id']==s['id'] and case['planned']==case['completedPhases']==PHASES and case['error'] is None and case['diagnostics']==case['unhandled']==case['unsupported']==[]
 expected=observations(s,history=history);actual=observations(s,red=red,history=history);assert len(case['observations'])==len(expected);differences=[]
 for o,(phase,key,value),(_,_,observed) in zip(case['observations'],expected,actual):
  status='PASS' if same(value,observed) else 'FAIL';assert (o['phase'],o['property'])==(phase,key) and same(o['expected'],value) and same(o['actual'],observed) and o['status']==status,(s['id'],phase,key,o,observed,value)
  if status=='FAIL':differences.append(dict(id=s['id'],phase=phase,property=key))
 q=situation(s,red=red);assert case['replayTrace']==dict(before=q['flags'],after=q['flags'],undo=list(reversed(q['frames'][:-1])),redo=q['frames'][1:]),(s['id'],'replay trace')
 assert case['transactions']==events(s,red) and case['nativeEvents']==native(s,other) and case['requestTrace']==request_trace(s,red) and case['changeTrace']==changes(s),(s['id'],'delivery graph')
 assert same(case['pageErrors'],next(value for phase,key,value in actual if phase=='dispose' and key=='pageErrors'))
 return len(expected),differences
