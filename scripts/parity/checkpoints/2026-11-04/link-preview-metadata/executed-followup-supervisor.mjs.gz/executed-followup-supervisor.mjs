import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {readFileSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
const root='test-results/audit-closeout-2026-11-01',env={...process.env,PYTHONDONTWRITEBYTECODE:'1'},previous=readFileSync(root+'/link-preview-metadata-run-path.txt','utf8').trim()
assert.equal(JSON.parse(readFileSync(join(previous,'manifest.json'))).outcome,'failed');env.EDITOR_METADATA_PREVIOUS_RESULTS_DIR=previous
const directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init','proof','controls'],{env,encoding:'utf8'}).trim();env.EDITOR_RESULTS_DIR=directory;writeFileSync(root+'/link-preview-metadata-followup-run-path.txt',directory)
for(const name of ['proof','controls']){const r=spawnSync(process.execPath,['scripts/verification-results.mjs','run',name,...(name==='controls'?['--require','proof']:[]),'--',process.execPath,root+'/run-link-preview-metadata-'+name+'.mjs'],{env,stdio:'inherit',windowsHide:true});assert.equal(r.error,undefined);console.log(JSON.stringify({gate:name,exitCode:r.status}))}
const r=spawnSync(process.execPath,['scripts/verification-results.mjs','finish'],{env,stdio:'inherit',windowsHide:true});assert.equal(r.status,0)
