import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {join} from 'node:path'
const d=process.env.EDITOR_RESULTS_DIR,previous=process.env.EDITOR_METADATA_PREVIOUS_RESULTS_DIR||d,source=execFileSync('git',['rev-parse','HEAD']).toString().trim(),r=spawnSync(process.execPath,['scripts/parity/checkpoints/2026-11-04/link-preview-metadata/controls.mjs',join(d,'link-preview-metadata-full.json'),join(d,'link-preview-metadata-red.json'),join(previous,'native-metadata.log'),join(previous,'native-metadata-trusted.log'),join(previous,'browser.log'),source,join(d,'link-preview-metadata-controls')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});assert.equal(r.error,undefined);assert.equal(r.status,0,r.stdout+r.stderr);console.log(r.stdout)
