const retirements=['replace','mode','remove-undo','render','destroy']
export const linkPreviewMetadataCases=[...['no-provider','adjacent','intervening','reject','auto-replay'].map(variant=>({id:variant,variant})),...retirements.flatMap(variant=>['resolve','reject'].map(outcome=>({id:variant+'/'+outcome,variant,outcome}))),...['host-title','host-away-back','host-url'].map(variant=>({id:variant,variant,currentOnly:true}))]
const BEFORE='https://before.example/article',AFTER='https://next.example/article',NEWER='https://newer.example/article',PIXEL='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jH1sAAAAASUVORK5CYII='
const META={title:'Metadata title',description:'Metadata description',image:PIXEL,favicon:PIXEL,domain:'display.example'}
const copy=v=>JSON.parse(JSON.stringify(v)),stable=v=>Array.isArray(v)?v.map(stable):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])])):v,same=(a,b)=>JSON.stringify(stable(a))===JSON.stringify(stable(b)),pause=()=>new Promise(r=>setTimeout(r,25))
const data=(url=BEFORE,loaded=true)=>({url,title:loaded?'Before title':'',description:loaded?'Before description':'',image:'',favicon:'',domain:new URL(url).hostname,template:'horizontal'})
const records=(value,legacy,other=false)=>[{id:'link',type:'linkPreview',...(!legacy?{dataVersion:1}:{}),data:copy(value)},{id:'b',type:'paragraph',...(!legacy?{dataVersion:2}:{}),data:{text:other?'BravoX':'Bravo'}}]
async function waitFor(predicate){const deadline=Date.now()+3000;while(!predicate()){if(Date.now()>deadline)throw new Error('Metadata request did not start');await pause()}}
export async function runLinkPreviewMetadataCase({sourceBase='../../',legacy=false,spec,nativeInput}){
 const base=new URL(sourceBase,import.meta.url),[core,paragraph,link]=await Promise.all(['core/index.js','plugins/paragraph/index.js','plugins/link-preview/index.js'].map(p=>import(new URL(p,base))))
 const holder=document.createElement('section');document.body.append(holder);const observations=[],diagnostics=[],transactions=[],requests=[],nativeEvents=[],changeTrace=[],unhandled=[],unsupported=[],replayTrace={undo:[],redo:[]},planned=['load','submit','intervene','complete','replay','dispose'],completedPhases=[]
 const check=(phase,property,actual,expected)=>{const a=copy(actual),e=copy(expected);observations.push({phase,property,actual:a,expected:e,status:same(a,e)?'PASS':'FAIL'})}
 const rejected=event=>unhandled.push({kind:event.reason===false?'false':event.reason?.name??typeof event.reason});window.addEventListener('unhandledrejection',rejected)
 let editor,original,phase='load'
 try{
  if(legacy&&spec.currentOnly)throw new Error('The runner must declare unavailable producer cases before execution')
  const v=spec.variant,automatic=v==='auto-replay',initial=data(BEFORE,!automatic),version=legacy?'1.0.5':'2.0.0',fetchMeta=v==='no-provider'?undefined:(url,{signal})=>new Promise((resolve,reject)=>requests.push({url,signal,resolve,reject,phase})),config=fetchMeta?{fetchMeta,injectStyles:false}:{injectStyles:false}
  const make=value=>core.createEditor({holder,injectStyles:false,inlineTools:[],blockRemoveAnimationMs:0,blockInsertAnimationMs:0,blockMoveAnimationMs:0,plugins:legacy?[new paragraph.Paragraph(),new link.LinkPreview(config)]:[paragraph.createParagraphPlugin({injectStyles:false}),link.createLinkPreviewPlugin(config)],onDiagnostic:value=>diagnostics.push(value),data:{version,blocks:records(value,legacy)}})
  const observe=(value,owner)=>{if(!legacy)value.on('transaction:committed',event=>transactions.push({owner,phase,action:event.action,origin:event.origin,name:event.name}))}
  editor=make(initial);original=editor;observe(editor,'first');if(legacy)unsupported.push({property:'currentMetadataFacts',reason:'Legacy native URL/provider/abort and replay execute. The current immutable transaction fact port is not emulated.'});await pause()
  const block=()=>holder.querySelector('[data-block-id="link"]'),input=()=>block()?.querySelector('.oe-lp__url-input'),view=()=>({input:input()?.value??null,href:block()?.querySelector('.oe-lp__card')?.getAttribute('href')??null,title:block()?.querySelector('.oe-lp__title')?.textContent??null,description:block()?.querySelector('.oe-lp__desc')?.textContent??''})
  const expectedView=value=>({input:value.url,href:value.url,title:value.title||value.url,description:value.description})
  const initialInput=input();initialInput.addEventListener('change',event=>changeTrace.push({phase,trusted:event.isTrusted,connected:initialInput.isConnected,blockConnected:initialInput.closest('[data-block-id]')?.isConnected??false,active:document.activeElement===initialInput,value:initialInput.value}),{capture:true})
  const submit=async url=>{const field=input();field.focus();field.select();field.addEventListener('input',event=>nativeEvents.push({kind:'url-input',trusted:event.isTrusted,type:event.inputType}),{once:true});await nativeInput('Input.insertText',{text:url});const key={key:'Enter',code:'Enter',windowsVirtualKeyCode:13,nativeVirtualKeyCode:13};field.addEventListener('keydown',event=>nativeEvents.push({kind:'submit',trusted:event.isTrusted,key:event.key}),{once:true});await nativeInput('Input.dispatchKeyEvent',{type:'keyDown',...key,text:'\r'});await nativeInput('Input.dispatchKeyEvent',{type:'keyUp',...key});await pause()}
  check(phase,'canonical',editor.save().blocks,records(initial,legacy));check(phase,'history',[editor.canUndo,editor.canRedo],[false,false]);check(phase,'producerPort',typeof editor.blocks.update,legacy?'undefined':'function');completedPhases.push(phase)
  phase='submit';const submitted=automatic?initial:data(AFTER,false)
  if(!automatic)await submit(AFTER)
  if(fetchMeta)await waitFor(()=>requests.length===1)
  check(phase,'canonical',editor.save().blocks,records(submitted,legacy));check(phase,'view',view(),expectedView(submitted));check(phase,'requests',requests.map(r=>r.url),fetchMeta?[automatic?BEFORE:AFTER]:[]);check(phase,'pendingSignals',requests.map(r=>r.signal.aborted),fetchMeta?[false]:[]);check(phase,'history',[editor.canUndo,editor.canRedo],automatic?[false,false]:[true,false]);completedPhases.push(phase)
  phase='intervene';let current=submitted,other=false,successor=false
  if(v==='intervening'){const field=holder.querySelector('[data-block-id="b"] .oe-paragraph');field.focus();const selection=getSelection(),range=document.createRange();range.selectNodeContents(field);range.collapse(false);selection.removeAllRanges();selection.addRange(range);await nativeInput('Input.insertText',{text:'X'});other=true}
  else if(v==='mode'){editor.setReadOnly(true);editor.setReadOnly(false)}
  else if(v==='replace'){await submit(NEWER);await waitFor(()=>requests.length===2);current=data(NEWER,false)}
  else if(v==='remove-undo'){legacy?editor.blocks.remove(editor.blocks.getBlockIndex('link')):editor.blocks.remove('link');editor.undo()}
  else if(v==='render'){current={...data(NEWER),title:'Rendered successor'};editor.render({version,blocks:records(current,legacy)})}
  else if(v==='destroy'){editor.destroy();editor=make({...data(NEWER),title:'Successor title'});observe(editor,'successor');current={...data(NEWER),title:'Successor title'};successor=true;original.destroy()}
  else if(v==='host-title'){editor.blocks.update('link',r=>({data:{...r.data,title:'Host title'}}));current={...current,title:'Host title'}}
  else if(v==='host-away-back'){editor.blocks.update('link',r=>({data:{...r.data,title:'Host title'}}));editor.blocks.update('link',r=>({data:{...r.data,title:''}}))}
  else if(v==='host-url'){editor.blocks.update('link',()=>({data:data(NEWER)}));current=data(NEWER)}
  await pause();const retired=retirements.includes(v)||v==='host-url'
  check(phase,'canonical',editor.save().blocks,records(current,legacy,other));if(fetchMeta)check(phase,'firstAborted',requests[0].signal.aborted,retired);check(phase,'requests',requests.map(r=>r.url),fetchMeta?(v==='replace'?[AFTER,NEWER]:[automatic?BEFORE:AFTER]):[]);completedPhases.push(phase)
  phase='complete';if(fetchMeta){if(spec.outcome==='reject'||v==='reject')requests[0].reject(false);else requests[0].resolve(META);await pause();await pause()}
  let completed=current
  if(fetchMeta&&!retired&&v!=='reject')completed={...current,...META,...(v==='host-title'?{title:'Host title'}:v==='host-away-back'?{title:''}:{})}
  if(v==='replace'){requests[1].resolve({...META,title:'Newest metadata'});await pause();await pause();completed={...current,...META,title:'Newest metadata'}}
  check(phase,'canonical',editor.save().blocks,records(completed,legacy,other));check(phase,'view',view(),expectedView(completed));check(phase,'unhandled',unhandled,[]);check(phase,'requests',requests.map(r=>r.url),fetchMeta?(v==='replace'?[AFTER,NEWER]:[automatic?BEFORE:AFTER]):[]);completedPhases.push(phase)
  phase='replay';replayTrace.before=[editor.canUndo,editor.canRedo];while(editor.canUndo&&replayTrace.undo.length<6){editor.undo();await pause();replayTrace.undo.push(editor.save().blocks)}
  while(editor.canRedo&&replayTrace.redo.length<replayTrace.undo.length){editor.redo();await pause();replayTrace.redo.push(editor.save().blocks)}
  replayTrace.after=[editor.canUndo,editor.canRedo];check(phase,'finalCanonical',editor.save().blocks,records(completed,legacy,other));check(phase,'cursorRoundtrip',replayTrace.after,replayTrace.before);check(phase,'requestCountAfterReplay',requests.length,fetchMeta?(v==='replace'?2:1):0);completedPhases.push(phase)
  phase='dispose';editor.destroy();original.destroy();await pause();check(phase,'rootsRemoved',!holder.querySelector('.oe-editor'),true);check(phase,'unhandled',unhandled,[]);completedPhases.push(phase)
  return{id:spec.id,spec,observations,diagnostics,transactions,nativeEvents,changeTrace,unhandled,unsupported,replayTrace,requestTrace:requests.map(r=>({url:r.url,phase:r.phase,aborted:r.signal.aborted})),planned,completedPhases,error:null}
 }catch(error){return{id:spec.id,spec,observations,diagnostics,transactions,nativeEvents,changeTrace,unhandled,unsupported,replayTrace,requestTrace:requests.map(r=>({url:r.url,phase:r.phase,aborted:r.signal.aborted})),planned,completedPhases,phase,error:String(error?.stack??error)}}finally{editor?.destroy();original?.destroy();window.removeEventListener('unhandledrejection',rejected);holder.remove()}
}
