import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { copyFile, mkdtemp, mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { packInstalledDependency } from './pack-installed-dependency.mjs'
import { assertConsumerGitDependencies, assertGitArtifactIntegrity, getPinnedGitDependencies } from './package-git-dependencies.mjs'

const editorRoot = resolve(fileURLToPath(new URL('..', import.meta.url)))
const node = process.execPath
const npmCli = process.env.npm_execpath
if (!npmCli) throw new Error('Run this gate through `npm run test:package` so npm_execpath is available')
const tscCli = resolve(editorRoot, 'node_modules/typescript/bin/tsc')
const viteCli = resolve(editorRoot, 'node_modules/vite/bin/vite.js')

function run(executable, args, cwd, options = {}) {
  return execFileSync(executable, args, { cwd, encoding: 'utf8', stdio: options.capture ? 'pipe' : 'inherit',
    windowsHide: true, env: options.env ?? process.env })
}

async function writeJson(path, value) {
  await mkdir(dirname(path), { recursive: true })
  await writeFile(path, `${JSON.stringify(value, null, 2)}\n`, 'utf8')
}

function collectExportTargets(exports, result = []) {
  if (typeof exports === 'string') result.push(exports)
  else if (exports && typeof exports === 'object') {
    for (const value of Object.values(exports)) collectExportTargets(value, result)
  }
  return result
}

async function assertExportTargets(packageRoot) {
  const manifest = JSON.parse(await readFile(join(packageRoot, 'package.json'), 'utf8'))
  const missing = []
  for (const target of collectExportTargets(manifest.exports)) {
    if (target.includes('*')) continue
    try { await readFile(join(packageRoot, target), 'utf8') } catch { missing.push(target) }
  }
  if (missing.length) throw new Error(`Missing package export targets: ${missing.join(', ')}`)
}

const temporaryRoot = await mkdtemp(join(tmpdir(), 'ophire-editor-package-'))
const npmCache = join(temporaryRoot, 'npm-cache')
try {
  run(node, [npmCli, 'run', 'build'], editorRoot)
  await assertExportTargets(editorRoot)

  const packageFiles = await readdir(resolve(editorRoot, 'dist'), { recursive: true })
  for (const removed of ['renderer/async.js', 'renderer/async.d.ts']) {
    if (packageFiles.includes(removed)) throw new Error(`Removed renderer forwarder remains in dist/${removed}`)
  }
  for (const relativePath of packageFiles.filter(path => /\.(?:js|d\.ts)$/.test(path))) {
    const content = await readFile(join(editorRoot, 'dist', relativePath), 'utf8')
    if (/\.\.\/\.\.\/(?:event-bus|infinite-scroll|masonry|color-picker|cropper|carousel|expose)\//.test(content)) {
      throw new Error(`Unpublished local dependency boundary remains in dist/${relativePath}`)
    }
  }

  const packRoot = join(temporaryRoot, 'pack')
  await mkdir(packRoot)
  const packOutput = run(node, [npmCli, 'pack', '--ignore-scripts', '--pack-destination', packRoot, '--cache', npmCache], editorRoot, { capture: true }).trim()
  const tarball = join(packRoot, basename(packOutput.split(/\r?\n/).at(-1)))
  const tarEntries = run('tar', ['-tf', tarball], editorRoot, { capture: true }).split(/\r?\n/).filter(Boolean)
  const blockReadmes = [
    'paragraph', 'heading', 'list', 'quote', 'code', 'image', 'delimiter', 'table',
    'checklist', 'warning', 'embed', 'raw', 'gallery', 'carousel', 'attaches', 'link-preview',
    'toggle', 'columns', 'spoiler', 'poll', 'person',
  ]
  const requiredEntries = [
    'package/README.md',
    'package/LICENSE',
    'package/NOTICE',
    'package/THIRD_PARTY_LICENSES.txt',
    'package/dist/plugins/README.md',
    'package/dist/plugins/README.ru.md',
    'package/dist/inline-plugins/README.md',
    'package/dist/inline-plugins/README.ru.md',
    'package/dist/inline-plugins/color/README.md',
    'package/dist/inline-plugins/color/README.ru.md',
    'package/dist/inline-plugins/mention/README.md',
    'package/dist/inline-plugins/mention/README.ru.md',
    'package/dist/renderer/renderers/README.md',
    'package/dist/renderer/renderers/README.ru.md',
    'package/dist/styles.css',
    'package/dist/styles/editor.css',
    'package/dist/styles/renderer.css',
    'package/dist/styles/inline-plugins/color.css',
    'package/dist/styles/inline-plugins/mention.css',
    ...blockReadmes.map(type => `package/dist/styles/plugins/${type}.css`),
    ...blockReadmes.map(type => `package/dist/styles/renderers/${type}.css`),
    ...blockReadmes.map(type => `package/dist/plugins/${type}/README.md`),
    ...blockReadmes.map(type => `package/dist/plugins/${type}/README.ru.md`),
    ...blockReadmes.map(type => `package/dist/renderer/renderers/${type}/README.md`),
    ...blockReadmes.map(type => `package/dist/renderer/renderers/${type}/README.ru.md`),
  ]
  const missingEntries = requiredEntries.filter(entry => !tarEntries.includes(entry))
  if (missingEntries.length) throw new Error(`Tarball misses publication files: ${missingEntries.join(', ')}`)
  const forbiddenEntry = tarEntries.find(entry => /(?:^|\/)(?:node_modules|tests|benchmarks|docs|\.vitepress)(?:\/|$)|\.(?:html|vue)$/.test(entry))
  if (forbiddenEntry) throw new Error(`Tarball contains a development-only file: ${forbiddenEntry}`)

  const publishedManifest = JSON.parse(run('tar', ['-xOf', tarball, 'package/package.json'], editorRoot, { capture: true }))
  const projectLock = JSON.parse(await readFile(join(editorRoot, 'package-lock.json'), 'utf8'))
  const pinnedGitDependencies = getPinnedGitDependencies(publishedManifest, projectLock)
  const gitDependencyTarballs = new Map()
  const dependencyInstallEnv = { ...process.env, npm_config_ignore_scripts: 'true' }
  const gitPackRoot = join(temporaryRoot, 'git-dependencies')
  await mkdir(gitPackRoot)
  for (const dependency of pinnedGitDependencies) {
    // A same-name file tarball cannot satisfy a Git edge. Pack the exact
    // published pin into this disposable cache before the offline install.
    // Both the CLI flag and inherited npm config disable lifecycle scripts,
    // including any child npm process used while preparing a Git package.
    const packed = JSON.parse(run(node, [
      npmCli, 'pack', dependency.spec, '--ignore-scripts', '--json',
      '--pack-destination', gitPackRoot, '--cache', npmCache,
    ], editorRoot, { capture: true, env: dependencyInstallEnv }))
    if (packed.length !== 1 || packed[0].name !== dependency.name || packed[0].version !== dependency.version) {
      throw new Error(`${dependency.name} packed Git artifact differs from the project lock`)
    }
    const artifact = packed[0]
    const gitTarball = join(gitPackRoot, basename(artifact.filename))
    const integrity = assertGitArtifactIntegrity(dependency, artifact, await readFile(gitTarball))
    gitDependencyTarballs.set(dependency.name, gitTarball)
    console.log(JSON.stringify({ gitDependency: dependency, integrity, lifecycleScripts: false }))
  }

  const dependencyPackRoot = join(temporaryRoot, 'dependencies')
  await mkdir(dependencyPackRoot, { recursive: true })
  // Check the artifacts selected for the consumer: staged published Git pins
  // or exact installed registry bytes, with lifecycle scripts disabled.
  const dependencyPackages = ['event-bus', 'color-picker', 'cropper', 'carousel', 'expose', 'infinite-scroll', 'masonry']
    .map(directory => ({
      directory,
      packageRoot: dirname(fileURLToPath(import.meta.resolve(`@shelamkoff/${directory}/package.json`))),
    }))
  const dependencyReadmes = {
    carousel: ['arrows', 'dots', 'thumbnails', 'keyboard', 'swipe', 'autoplay', 'lazyload', 'parallax'],
    expose: ['captions', 'zoom', 'thumbnails', 'autoplay', 'transform', 'download', 'fullscreen'],
  }
  const dependencyTarballs = []
  async function prepareDependencyTarball(packageRoot) {
    const manifest = JSON.parse(await readFile(join(packageRoot, 'package.json'), 'utf8'))
    const gitTarball = gitDependencyTarballs.get(manifest.name)
    if (gitTarball) return gitTarball
    const dependencyTarball = await packInstalledDependency(packageRoot, dependencyPackRoot)
    dependencyTarballs.push(dependencyTarball)
    return dependencyTarball
  }
  for (const { directory, packageRoot } of dependencyPackages) {
    const dependencyTarball = await prepareDependencyTarball(packageRoot)
    const entries = run('tar', ['-tf', dependencyTarball], packageRoot, { capture: true }).split(/\r?\n/).filter(Boolean)
    const required = ['package/README.md', 'package/README.ru.md', 'package/LICENSE', 'package/package.json']
    for (const plugin of dependencyReadmes[directory] ?? []) {
      required.push(`package/dist/src/plugins/${plugin}/README.md`)
      required.push(`package/dist/src/plugins/${plugin}/README.ru.md`)
    }
    const missing = required.filter(entry => !entries.includes(entry))
    if (missing.length) throw new Error(`${directory} tarball misses: ${missing.join(', ')}`)
  }

  // DOMPurify is an ordinary npm runtime dependency rather than a sibling
  // @shelamkoff package. Resolve its exported ESM entry and move up from
  // dist/ to the package root; package.json itself is intentionally not an
  // exported subpath. Repack exact installed bytes without invoking prepare
  // (older npm pack releases run it even with --ignore-scripts).
  const domPurifyEntry = fileURLToPath(import.meta.resolve('dompurify'))
  const domPurifyRoot = resolve(dirname(domPurifyEntry), '..')
  await prepareDependencyTarball(domPurifyRoot)

  const transitiveRuntimeDependencies = ['highlight.js', 'jszip', 'lie', 'immediate', 'pako', 'setimmediate']
  for (const dependency of transitiveRuntimeDependencies) {
    let entry
    try { entry = fileURLToPath(import.meta.resolve(dependency)) } catch { continue }
    let packageRoot = dirname(entry)
    while (dirname(packageRoot) !== packageRoot) {
      try {
        const manifest = JSON.parse(await readFile(join(packageRoot, 'package.json'), 'utf8'))
        if (manifest.name === dependency) break
      } catch {}
      packageRoot = dirname(packageRoot)
    }
    await prepareDependencyTarball(packageRoot)
  }

  const nestedRuntimePackages = [
    'node_modules/jszip/node_modules/readable-stream',
    'node_modules/jszip/node_modules/safe-buffer',
    'node_modules/core-util-is',
    'node_modules/inherits',
    'node_modules/isarray',
    'node_modules/process-nextick-args',
    'node_modules/jszip/node_modules/string_decoder',
    'node_modules/util-deprecate',
  ]
  for (const relativeRoot of nestedRuntimePackages) {
    try {
      await prepareDependencyTarball(join(editorRoot, relativeRoot))
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error
    }
  }



  const consumerRoot = join(temporaryRoot, 'consumer')
  await mkdir(join(consumerRoot, 'src'), { recursive: true })
  await writeJson(join(consumerRoot, 'package.json'), { private: true, type: 'module' })
  run(node, [
    npmCli,
    'install',
    '--offline',
    '--ignore-scripts',
    '--no-audit',
    '--no-fund',
    '--cache', npmCache,
    tarball,
    ...dependencyTarballs,
  ], consumerRoot, { env: dependencyInstallEnv })

  const installedManifest = JSON.parse(await readFile(join(consumerRoot, 'node_modules', publishedManifest.name, 'package.json'), 'utf8'))
  const consumerLock = JSON.parse(await readFile(join(consumerRoot, 'package-lock.json'), 'utf8'))
  assertConsumerGitDependencies(installedManifest, consumerLock, pinnedGitDependencies)
  for (const { name } of pinnedGitDependencies) {
    await assertExportTargets(join(consumerRoot, 'node_modules', name))
  }
  const installedGitDependencies = pinnedGitDependencies.map(({ name }) => ({
    name,
    declared: installedManifest.dependencies[name],
    resolved: consumerLock.packages[`node_modules/${name}`].resolved,
    version: consumerLock.packages[`node_modules/${name}`].version,
    integrity: consumerLock.packages[`node_modules/${name}`].integrity,
  }))
  console.log(JSON.stringify({ offlineConsumerGitDependencies: installedGitDependencies, provenance: 'passed' }))

  const consumerSource = `
import { createEditor } from '@shelamkoff/rector'
import * as rectorRoot from '@shelamkoff/rector'
import { normalizeRichText, sanitizeHtml as sanitizePluginHtml } from '@shelamkoff/rector/plugin-kit'
import * as pluginKit from '@shelamkoff/rector/plugin-kit'
import {
  createAttachesPlugin,
  createCarouselPlugin,
  createEmbedPlugin,
  createLinkPreviewPlugin,
  createParagraphPlugin,
  createPersonPlugin,
  createPollPlugin,
} from '@shelamkoff/rector/plugins'
import { createBlockPluginsAsync } from '@shelamkoff/rector/plugins/async'
import { createMentionPlugin } from '@shelamkoff/rector/inline-plugins/mention'
import { createBoldTool } from '@shelamkoff/rector/inline-tools/bold'
import { createDefaultInlineTools } from '@shelamkoff/rector/preset'
import { EditorRenderer } from '@shelamkoff/rector/renderer'
import { createDefaultRenderersAsync } from '@shelamkoff/rector/renderer/renderers/async'
import { EventBus } from '@shelamkoff/event-bus'
import { ColorPicker, colorPickerStylesUrl, parseColorInput } from '@shelamkoff/color-picker'
import { Carousel, carouselStylesUrl } from '@shelamkoff/carousel'
import { Cropper, cropperStylesUrl } from '@shelamkoff/cropper'
import { Expose, exposeStylesUrl } from '@shelamkoff/expose'
import '@shelamkoff/rector/styles.css'
import '@shelamkoff/rector/styles/editor.css'
import '@shelamkoff/rector/plugins/person/styles.css'
import '@shelamkoff/rector/inline-plugins/color/styles.css'
import '@shelamkoff/rector/renderer/renderers/carousel/styles.css'

const configuredPlugins = [
  createCarouselPlugin({
    uploadFile: async (file, { signal }) => ({ url: signal.aborted ? '' : URL.createObjectURL(file) }),
    actions: [{ label: 'Library', handler: async ({ signal }) => signal.aborted ? null : [{ id: 'slide-1', type: 'image', src: 'https://example.com/slide.jpg' }] }],
  }),
  createAttachesPlugin({
    uploadFile: async (file, { signal }) => ({ url: signal.aborted ? '' : URL.createObjectURL(file), size: file.size }),
    actions: [{ label: 'Library', handler: async ({ signal }) => signal.aborted ? null : [{ url: 'https://example.com/file.pdf', name: 'file.pdf', extension: 'pdf' }] }],
  }),
  createEmbedPlugin({
    actions: [{ icon: '', label: 'Library', handler: async ({ signal }) => signal.aborted ? null : ({ url: 'https://example.com/cover.jpg' }) }],
    resolvePreview: async ({ signal }) => signal.aborted ? null : ({ thumbnailUrl: 'https://example.com/thumb.jpg' }),
  }),
  createLinkPreviewPlugin({ fetchMeta: async (url, { signal }) => signal.aborted ? {} : ({ title: url, domain: 'example.com' }) }),
  createPersonPlugin({
    uploadFile: async (file, { signal }) => ({ url: signal.aborted ? '' : URL.createObjectURL(file) }),
    socialResolvers: [{ test: url => url.includes('example.com'), type: 'website' }],
  }),
  createPollPlugin({
    dataSource: {
      load: async () => ({ revision: '1', total: 0, options: [] }),
      vote: async ({ optionIds }) => ({ revision: '2', total: optionIds.length, options: optionIds.map(id => ({ id, votes: 1 })) }),
    },
  }),
]

const mentionPlugin = createMentionPlugin({
  searchFunction: async (_query, _nextPageUrl, { signal }) => signal.aborted ? [] : [{ id: '1', name: 'Ada' }],
})

function usePublicEditorApi(editor = createEditor({
  holder: document.createElement('div'),
  plugins: [createParagraphPlugin()],
  inlinePlugins: [mentionPlugin],
  injectStyles: false,
})) {
  const available = [editor.isReady, editor.readOnly, editor.canUndo, editor.canRedo]
  editor.undo()
  editor.redo()
  editor.setReadOnly(!editor.readOnly)
  return available
}

if ('DocumentSchema' in rectorRoot || 'DocumentMigration' in rectorRoot || 'uid' in rectorRoot || 'sanitizeHtml' in rectorRoot || 'escapeHtml' in rectorRoot) {
  throw new Error('root package leaked extension/internal utility exports')
}

if ('setTrustedHtml' in pluginKit || 'insertTrustedHtml' in pluginKit) {
  throw new Error('plugin-kit leaked an unsanitized trusted HTML sink')
}

void [createEditor, normalizeRichText, sanitizePluginHtml, createParagraphPlugin, createPersonPlugin, configuredPlugins, createBlockPluginsAsync, mentionPlugin, createBoldTool, createDefaultInlineTools, EditorRenderer, createDefaultRenderersAsync, EventBus, ColorPicker, parseColorInput, Carousel, Cropper, Expose, colorPickerStylesUrl, carouselStylesUrl, cropperStylesUrl, exposeStylesUrl, usePublicEditorApi]
`
  await writeFile(join(consumerRoot, 'src/main.js'), consumerSource, 'utf8')
  const consumerTypeSource = `${consumerSource}
import type { BlockPluginDefinition, EditorConfig, EditorOutputData, IEditor, InlinePluginDefinition, ParagraphBlock } from '@shelamkoff/rector/types'
import type { RendererConfig } from '@shelamkoff/rector/renderer/types'
declare const publicEditor: IEditor
declare const editorConfig: EditorConfig
declare const blockPlugin: BlockPluginDefinition
declare const inlinePlugin: InlinePluginDefinition
declare const output: EditorOutputData
declare const paragraph: ParagraphBlock
declare const rendererConfig: RendererConfig
void [publicEditor, editorConfig, blockPlugin, inlinePlugin, output, paragraph, rendererConfig]
`
  await writeFile(join(consumerRoot, 'src/main.ts'), consumerTypeSource, 'utf8')
  const extensionConsumer = (await readFile(join(editorRoot, 'tests/types/extensibility-consumer.ts'), 'utf8'))
    .replaceAll('../../.package-tmp/declaration-tests/core/index.js', '@shelamkoff/rector')
    .replaceAll('../../.package-tmp/declaration-tests/renderer/index.js', '@shelamkoff/rector/renderer')
    .replaceAll('../../.package-tmp/declaration-tests/renderer/types.js', '@shelamkoff/rector/renderer/types')
    .replaceAll('../../.package-tmp/declaration-tests/plugin-kit/index.js', '@shelamkoff/rector/plugin-kit')
    .replaceAll('../../.package-tmp/declaration-tests/types.js', '@shelamkoff/rector/types')
  await writeFile(join(consumerRoot, 'src/extensibility.ts'), extensionConsumer, 'utf8')
  await writeFile(join(consumerRoot, 'index.html'), '<script type="module" src="/src/main.js"></script>\n', 'utf8')

  await copyFile(join(editorRoot, 'scripts/package-public-exports.mjs'), join(consumerRoot, 'src/public-exports.mjs'))
  const exportReport = JSON.parse(run(node, ['src/public-exports.mjs'], consumerRoot, { capture: true }))
  const tarballBytes = await readFile(tarball)
  const packageProof = {
    ...exportReport,
    tarball: basename(tarball),
    tarballSha256: createHash('sha256').update(tarballBytes).digest('hex'),
    tarballBytes: tarballBytes.length,
    contractSha256: createHash('sha256').update(await readFile(join(consumerRoot, 'src/public-exports.mjs'))).digest('hex'),
  }
  if (process.env.EDITOR_RESULTS_DIR) {
    await copyFile(tarball, join(process.env.EDITOR_RESULTS_DIR, 'package-consumer.tgz'))
    await writeJson(join(process.env.EDITOR_RESULTS_DIR, 'package-public-exports.json'), packageProof)
  }
  console.log(JSON.stringify({ publicExportContract: packageProof }))

  for (const moduleResolution of ['Bundler', 'NodeNext']) {
    await writeJson(join(consumerRoot, `tsconfig.${moduleResolution.toLowerCase()}.json`), {
      compilerOptions: {
        target: 'ES2022',
        module: moduleResolution === 'NodeNext' ? 'NodeNext' : 'ESNext',
        moduleResolution,
        strict: true,
        noEmit: true,
        skipLibCheck: false,
      },
      include: ['src/main.ts', 'src/extensibility.ts', 'src/public-exports.ts'],
    })
    run(node, [tscCli, '-p', `tsconfig.${moduleResolution.toLowerCase()}.json`], consumerRoot)
  }

  run(node, [viteCli, 'build'], consumerRoot)
  run(node, ['--input-type=module', '-e', "import('@shelamkoff/rector').then(m => { if (typeof m.createEditor !== 'function') process.exit(1) })"], consumerRoot)
  run(node, ['--input-type=module', '-e', `
    import assert from 'node:assert/strict'
    const renderer = await import('@shelamkoff/rector/renderer')
    assert.equal(typeof renderer.EditorRenderer, 'function')
    assert.equal(Object.hasOwn(renderer, 'createEditorRenderer'), false)
    await assert.rejects(import('@shelamkoff/rector/renderer/async'), {
      code: 'ERR_PACKAGE_PATH_NOT_EXPORTED',
    })
    const factories = await import('@shelamkoff/rector/renderer/renderers/async')
    assert.equal(typeof factories.createDefaultRenderersAsync, 'function')
  `], consumerRoot)
  run(node, ['--input-type=module', '-e', "Promise.all([import('highlight.js'), import('jszip')]).then(([h,z]) => { if (!h.default || !z.default) process.exit(1) })"], consumerRoot)
  // Execute the same external definitions against the installed tarball. The
  // browser fixture has no private editor imports and no built-in plugin owner.
  const browserRoot = join(consumerRoot, 'tests/browser')
  await mkdir(browserRoot, { recursive: true })
  for (const name of ['public-extension-contracts.html', 'public-extension-contracts.js', 'public-extension-conformance.js']) {
    let source = await readFile(join(editorRoot, 'tests/browser', name), 'utf8')
    if (name === 'public-extension-contracts.js') source = source
      .replaceAll('../../index.js', '@shelamkoff/rector')
      .replaceAll('../../plugin-kit/index.js', '@shelamkoff/rector/plugin-kit')
      .replaceAll('../../renderer/index.js', '@shelamkoff/rector/renderer')
    await writeFile(join(browserRoot, name), source, 'utf8')
  }
  run(node, [join(editorRoot, 'tests/browser/run.mjs')], consumerRoot, { env: {
    ...process.env, EDITOR_BROWSER_ROOT: consumerRoot, EDITOR_BROWSER_PAGE: 'public-extension-contracts.html',
  } })
  console.log(JSON.stringify({ tarball: basename(tarball), typeModes: ['Bundler', 'NodeNext'], vite: 'passed', import: 'passed', externalBrowser: 'passed' }))
} finally {
  await rm(temporaryRoot, { recursive: true, force: true })
}
