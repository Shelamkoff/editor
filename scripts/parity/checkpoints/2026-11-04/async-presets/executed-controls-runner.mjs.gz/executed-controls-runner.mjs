import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {join} from 'node:path'
const d=process.env.EDITOR_RESULTS_DIR,source=execFileSync('git',['rev-parse','HEAD']).toString().trim(),r=spawnSync(process.execPath,['scripts/parity/checkpoints/2026-11-04/async-presets/controls.mjs',join(d,'async-presets-full.json'),join(d,'package-public-exports.json'),join(d,'package-consumer.tgz'),source,join(d,'async-presets-controls')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});assert.equal(r.error,undefined);assert.equal(r.status,0,r.stdout+r.stderr);console.log(r.stdout)
