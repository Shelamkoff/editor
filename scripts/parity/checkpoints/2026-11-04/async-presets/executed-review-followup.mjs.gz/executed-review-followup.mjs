import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {copyFileSync,readFileSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
const root='test-results/audit-closeout-2026-11-01',env={...process.env,PYTHONDONTWRITEBYTECODE:'1'},previousDirectory=readFileSync(root+'/async-presets-run-path.txt','utf8').trim(),previous=JSON.parse(readFileSync(join(previousDirectory,'manifest.json')))
assert.equal(previous.outcome,'failed');assert.equal(previous.sourceUnchanged,true);assert.deepEqual(Object.entries(previous.gates).filter(([,g])=>g.outcome==='failed').map(([k])=>k),['proof']);assert.deepEqual(Object.entries(previous.gates).filter(([,g])=>g.outcome==='not-run').map(([k])=>k),['controls']);assert.equal(Object.values(previous.gates).filter(g=>g.outcome==='passed').length,9)
assert.equal(execFileSync('git',['diff','--name-only',previous.source.head,'HEAD']).toString().trim(),'scripts/parity/checkpoints/2026-11-04/async-presets/review.py')
for(const key of ['EDITOR_BROWSER_PAGE','EDITOR_BROWSER_ROOT','EDITOR_NATIVE_PAGE','EDITOR_NATIVE_FILTER','EDITOR_ASYNC_PRESETS_FILTER'])delete env[key]
const plans=[['proof',[process.execPath,root+'/run-async-presets-proof.mjs']],['controls',[process.execPath,root+'/run-async-presets-controls.mjs'],'proof']]
const directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init',...plans.map(p=>p[0])],{env,encoding:'utf8'}).trim();env.EDITOR_RESULTS_DIR=directory;writeFileSync(root+'/async-presets-review-followup-path.txt',directory)
for(const name of ['package-public-exports.json','package-consumer.tgz']){copyFileSync(join(previousDirectory,name),join(directory,name));assert.deepEqual(readFileSync(join(directory,name)),readFileSync(join(previousDirectory,name)))}
for(const[name,command,require]of plans){const r=spawnSync(process.execPath,['scripts/verification-results.mjs','run',name,...(require?['--require',require]:[]),'--',...command],{env,stdio:'inherit',windowsHide:true});assert.equal(r.error,undefined);console.log(JSON.stringify({gate:name,exitCode:r.status}))}
const r=spawnSync(process.execPath,['scripts/verification-results.mjs','finish'],{env,stdio:'inherit',windowsHide:true});assert.equal(r.status,0)
