const PIXEL='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jH1sAAAAASUVORK5CYII='
export const embedServicesCases=[
 {id:'youtube-watch',url:'https://www.youtube.com/watch?v=dQw4w9WgXcQ',service:'youtube',videoId:'dQw4w9WgXcQ'},
 {id:'vimeo-player',url:'https://player.vimeo.com/video/12345',service:'vimeo',videoId:'12345'},
 {id:'unknown-host',url:'https://videos.example/watch?v=dQw4w9WgXcQ',service:'',videoId:''},
 {id:'invalid-youtube-id',url:'https://youtube.com/watch?v=short',service:'',videoId:''},
]
const pause=()=>new Promise(resolve=>setTimeout(resolve,0)),same=(a,b)=>JSON.stringify(a)===JSON.stringify(b)
export async function runEmbedServiceCase({sourceBase,legacy,spec,nativeInput}){
 const [{createEditor},plugin]=await Promise.all([import(sourceBase+'core/index.js'),import(sourceBase+'plugins/embed/index.js')]),holder=document.createElement('section');document.body.append(holder)
 const observations=[],nativeEvents=[],planned=['load','submit','play','replay','dispose'],completedPhases=[],initial={service:'',videoId:'',caption:'<b>Author caption</b>',cover:PIXEL,title:'Author title',duration:'1:23'},record=data=>[{id:'embed',type:'embed',...(!legacy?{dataVersion:1}:{}),data}],version=legacy?'1.0.5':'2.0.0'
 const check=(phase,property,actual,expected)=>observations.push({phase,property,actual:structuredClone(actual),expected:structuredClone(expected),status:same(actual,expected)?'PASS':'FAIL'})
 let editor,phase='load'
 try{
  const config={resolvePreview:false,injectStyles:false};editor=createEditor({holder,plugins:[legacy?new plugin.Embed(config):plugin.createEmbedPlugin(config)],injectStyles:false,inlineTools:[],data:{version,blocks:record(initial)}})
  const input=holder.querySelector('.oe-embed__url-input');check(phase,'canonical',editor.save().blocks,record(initial));check(phase,'history',[editor.canUndo,editor.canRedo],[false,false]);completedPhases.push(phase)
  phase='submit';input.focus();input.select();input.addEventListener('input',e=>nativeEvents.push({type:'input',trusted:e.isTrusted,inputType:e.inputType}),{once:true});await nativeInput('Input.insertText',{text:spec.url});input.addEventListener('keydown',e=>nativeEvents.push({type:'keydown',trusted:e.isTrusted,key:e.key}),{once:true});const key={key:'Enter',code:'Enter',windowsVirtualKeyCode:13,nativeVirtualKeyCode:13};await nativeInput('Input.dispatchKeyEvent',{type:'keyDown',...key,text:'\r'});await nativeInput('Input.dispatchKeyEvent',{type:'keyUp',...key});await pause();const expected={...initial,service:spec.service,videoId:spec.videoId};check(phase,'canonical',editor.save().blocks,record(expected));check(phase,'history',[editor.canUndo,editor.canRedo],[!!spec.service,false]);completedPhases.push(phase)
  phase='play';const play=holder.querySelector('.oe-embed__play-btn');if(play){play.addEventListener('click',e=>nativeEvents.push({type:'click',trusted:e.isTrusted}),{once:true});play.scrollIntoView({block:'center'});const r=play.getBoundingClientRect();await nativeInput('Input.click',{x:r.x+r.width/2,y:r.y+r.height/2});await pause()}
  const iframe=holder.querySelector('iframe'),frame=iframe?{src:iframe.getAttribute('src'),sandbox:iframe.getAttribute('sandbox'),allow:iframe.getAttribute('allow'),title:iframe.title,fullscreen:iframe.allowFullscreen}:null
  check(phase,'iframe',frame,spec.service?{src:spec.service==='youtube'?'https://www.youtube.com/embed/'+spec.videoId+'?autoplay=1&rel=0':'https://player.vimeo.com/video/'+spec.videoId+'?autoplay=1',sandbox:'allow-scripts allow-same-origin allow-presentation allow-popups',allow:'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture',title:'Author title',fullscreen:true}:null);check(phase,'canonical',editor.save().blocks,record(expected));check(phase,'history',[editor.canUndo,editor.canRedo],[!!spec.service,false]);completedPhases.push(phase)
  phase='replay';if(editor.canUndo){editor.undo();await pause();check(phase,'undo',editor.save().blocks,record(initial));editor.redo();await pause()}check(phase,'final',editor.save().blocks,record(expected));check(phase,'iframeAfterReplay',holder.querySelector('iframe')?.getAttribute('src')??null,null);completedPhases.push(phase)
  phase='dispose';editor.destroy();check(phase,'rootRemoved',!holder.querySelector('.oe-editor'),true);completedPhases.push(phase);return{id:spec.id,spec,observations,nativeEvents,planned,completedPhases,error:null,unsupported:[]}
 }catch(error){return{id:spec.id,spec,observations,nativeEvents,planned,completedPhases,phase,error:String(error.stack??error),unsupported:[]}}finally{editor?.destroy();holder.remove()}
}
