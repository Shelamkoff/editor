import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {readFileSync,writeFileSync} from 'node:fs'
const root='test-results/audit-closeout-2026-11-01',env={...process.env,PYTHONDONTWRITEBYTECODE:'1'},previous=JSON.parse(readFileSync(readFileSync(root+'/embed-metadata-run-path.txt','utf8').trim()+'/manifest.json'))
assert.equal(previous.outcome,'failed');assert.equal(previous.sourceUnchanged,true);assert.deepEqual(Object.entries(previous.gates).filter(([,g])=>g.outcome==='failed').map(([k])=>k),['proof']);assert.deepEqual(Object.entries(previous.gates).filter(([,g])=>g.outcome==='not-run').map(([k])=>k),['controls']);assert.equal(Object.values(previous.gates).filter(g=>g.outcome==='passed').length,16)
assert.equal(execFileSync('git',['diff','--name-only',previous.source.head,'HEAD']).toString().trim(),'scripts/parity/checkpoints/2026-11-04/embed-metadata/review.py')
for(const key of ['EDITOR_BROWSER_PAGE','EDITOR_BROWSER_ROOT','EDITOR_NATIVE_PAGE','EDITOR_NATIVE_FILTER','EDITOR_EMBED_METADATA_FILTER','EDITOR_EMBED_PLAYER_LIFETIME_FILTER'])delete env[key]
const plans=[['lifetime',[process.execPath,root+'/run-embed-metadata-lifetime.mjs']],['proof',[process.execPath,root+'/run-embed-metadata-proof.mjs'],'lifetime'],['controls',[process.execPath,root+'/run-embed-metadata-controls.mjs'],'proof']]
const directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init',...plans.map(p=>p[0])],{env,encoding:'utf8'}).trim();env.EDITOR_RESULTS_DIR=directory;writeFileSync(root+'/embed-metadata-review-followup-path.txt',directory)
for(const[name,command,require]of plans){const r=spawnSync(process.execPath,['scripts/verification-results.mjs','run',name,...(require?['--require',require]:[]),'--',...command],{env,stdio:'inherit',windowsHide:true});assert.equal(r.error,undefined);console.log(JSON.stringify({gate:name,exitCode:r.status}))}
const r=spawnSync(process.execPath,['scripts/verification-results.mjs','finish'],{env,stdio:'inherit',windowsHide:true});assert.equal(r.status,0)
