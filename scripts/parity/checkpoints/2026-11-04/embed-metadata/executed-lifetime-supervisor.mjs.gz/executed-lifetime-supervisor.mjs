import assert from 'node:assert/strict'
import {spawnSync} from 'node:child_process'
import {writeFileSync} from 'node:fs'
import {join} from 'node:path'
const d=process.env.EDITOR_RESULTS_DIR,env={...process.env};delete env.EDITOR_EMBED_PLAYER_LIFETIME_FILTER
const r=spawnSync(process.execPath,['scripts/parity/embed-player-lifetime.mjs'],{env,encoding:'utf8',windowsHide:true,maxBuffer:32*1024*1024});assert.equal(r.error,undefined);writeFileSync(join(d,'embed-metadata-lifetime.json'),r.stdout);writeFileSync(join(d,'embed-metadata-lifetime.stderr'),r.stderr);writeFileSync(join(d,'embed-metadata-lifetime-process.json'),JSON.stringify({exitCode:r.status,signal:r.signal,expectedExitCode:0},null,2));assert.equal(r.status,0);assert.equal(r.stderr,'');console.log(JSON.stringify({lifetimeExitCode:r.status,bytes:r.stdout.length}))
