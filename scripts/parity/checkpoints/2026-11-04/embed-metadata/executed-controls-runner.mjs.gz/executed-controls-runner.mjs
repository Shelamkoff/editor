import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {join} from 'node:path'
const d=process.env.EDITOR_RESULTS_DIR,source=execFileSync('git',['rev-parse','HEAD']).toString().trim(),r=spawnSync(process.execPath,['scripts/parity/checkpoints/2026-11-04/embed-metadata/controls.mjs',join(d,'embed-metadata-full.json'),join(d,'embed-metadata-lifetime.json'),'test-results/audit-closeout-2026-11-01/embed-metadata-red.json',source,join(d,'embed-metadata-controls')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});assert.equal(r.error,undefined);assert.equal(r.status,0,r.stdout+r.stderr);console.log(r.stdout)
