# Lossless field-completion proof archive

This archive preserves original recorded manifests, failure result JSON, and raw proof logs without rewriting their contents. All payload files have SHA-256 and original location entries in ARCHIVE-INDEX.json. Review/manifest.json retains its accepted hash; later commit identity and independent v3 review are separate files.

The final isolated source passed unit1967, generated7, both checkJs projects, build/documentation/package, ordinary100+63+28 and full native36+14. Broad run-fIlUUK honestly remains failed because its initial package attempt encountered a symlink-only dependency tarball; the passed run-k1dcc8 completes that required gate. run-wnoBSV lacked Chrome in its package command. These setup failures are preserved, not recast as product RED. The initial invalid consumer import is under excluded-setup/run-PkDZ3R. Native-removal's post-fix trailing-space/NBSP oracle error is separately retained alongside its original ownership RED and corrected independent LXR-to-LR GREEN.

Source commits and final full patch are reconstructible from the repository plus archived patches. Intermediate dirty RED attempts retain their exact C11 source identities and recorded historical patches; this archive does not invent an unrecorded complete checkout for each intermediate state. This is an evidence archive, not full integrated acceptance or a universal parity/performance claim.

The new integrated Chrome156 acceptance runs separately in /tmp/rector-completion-integration-20261029/test-results/run-60Px2b on cb12753c/treee69c866e. Its running results are intentionally not mixed into this completed isolated proof archive.
