# Field projection completion / Image alternative text

This is a bounded review handoff for the optional captured `BlockInstance.afterProjection(field)` contract and its Image consumer. Main was not edited. Production and public documentation are frozen in the full patch; three earlier local commits contain the test-first contract and native failure oracles.

## Accepted behavior under test

- Completion follows final mounted projection and connection callbacks, and precedes canonical/history acceptance.
- Canonical sidecar updates, mode cancellation, standalone affected-field recovery, and genuine native finalization (including normalized no-op) use the same BlockReconciler owner.
- The captured callback receives the exact frozen rich-field descriptor and original receiver. Errors including undefined and callable thenables fail the owning attempt.
- Protected mutation/control admission and exact field/instance leases remain in force. Direct author or same-block sibling Text/private-widget changes are rejected. Standalone damaged fields use existing local retirement and no-query-retry containment.
- Image computes alternative text from the final caption and uses exact captured node membership for all alt writes. Frozen Image10 is unchanged.

## Verification

All 1,967 existing Node tests, 7 generated declaration/strict consumer checks, both checkJs configurations, build, source/locales/README/docs checks, and installed-package consumers passed. Browser pages: projection 100/100, presentation recovery 63/63, mode recovery 28/28, full native library 36/36, full native presentation recovery 14/14. The native final pages were run without filters. Every final gate reports sourceUnchanged=true.

The broad C11 manifest deliberately remains failed because its first package attempt found a symlink-only dependency tarball in this isolated worktree. A second package attempt reached the external browser without EDITOR_CHROME_PATH and failed setup. Both raw failures are preserved; byte-identical physical copies of five isolated dependencies and the explicit Chrome path repaired the environment. The fresh package-ready manifest is passed. No gate or source was changed to suppress either failure.

## Scope limits

This does not claim full Image/Gallery parity, a general auxiliary-DOM rollback, control of arbitrary third-party mutations elsewhere in the document, layout/paint completion, or a universal performance result. Absent callbacks return before completion-specific DOM observation. Gallery/Carousel production is untouched. The fixture's original invalid import and trailing-space/NBSP expectation are classified separately in the manifest and are not counted as product defects.

See manifest.json for exact source identities, patch and log hashes, commands/times, real RED controls and environment corrections.
