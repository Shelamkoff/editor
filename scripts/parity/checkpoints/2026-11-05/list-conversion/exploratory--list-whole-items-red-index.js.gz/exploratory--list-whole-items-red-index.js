// @ts-check
import { isRichTextEmpty } from '../../shared/richTextEmpty.js'
import { createItemSelectionSlice } from '../shared/itemSelectionSlice.js'
import { definitionStyles } from '../shared/definitionStyles.js'
import { setSanitizedHtml } from '../../plugin-kit/index.js'
import { listDataSchema } from '../../shared/blockSchemas/list.js'
import { acceptsTextPayload, richTextFromPayload } from '../shared/textConversion.js'

const editorStyles=new URL('./list.css',import.meta.url).href
const ICON_UL='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6h11"/><path d="M9 12h11"/><path d="M9 18h11"/><path d="M5 6v.01"/><path d="M5 12v.01"/><path d="M5 18v.01"/></svg>'
const ICON_OL='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 6h9"/><path d="M11 12h11"/><path d="M11 18h9"/><path d="M4 16a2 2 0 1 1 4 0c0 .591-.5 1-1 1.5l-3 2.5h4"/><path d="M6 10v-6l-2 2"/></svg>'

/**
 * Create the immutable List v2 definition with stable item identities.
 * @param {{injectStyles?: boolean, css?: string}} [config]
 * @returns {import('../../plugin-kit/types').BlockPluginDefinition<{style:'ordered'|'unordered',items:Array<{id:string,text:string}>}>}
 */
export function createListPlugin(config = {}) {
  const toolbox=Object.freeze([
    Object.freeze({
      id:'unordered',
      label:Object.freeze({key:'bulletedTitle',fallback:'Bulleted List'}),
      icon:ICON_UL,
      configure(base){return {...base,style:'unordered'}},
    }),
    Object.freeze({
      id:'ordered',
      label:Object.freeze({key:'numberedTitle',fallback:'Numbered List'}),
      icon:ICON_OL,
      configure(base){return {...base,style:'ordered'}},
    }),
  ])

  /** @type {import('../../plugin-kit/types').BlockCapabilities<{style:'ordered'|'unordered',items:Array<{id:string,text:string}>}>} */
  const capabilities=Object.freeze({
    formatting:Object.freeze({inlineTools:true}),
    empty:Object.freeze({
      isEmpty:(data,context)=>data.items.every(item=>isRichTextEmpty(item.text,context)),
    }),
    merge:Object.freeze({
      merge(target,source){
        const occupied=new Set(target.items.map(item=>item.id))
        const appended=source.items.map((item,index)=>{
          let id=item.id
          let suffix=0
          while(occupied.has(id))id=`merged-${index}-${suffix++}-${item.id}`
          occupied.add(id)
          return {...item,id}
        })
        return {...target,items:[...target.items,...appended]}
      },
    }),
    shortcuts:Object.freeze(/** @type {import('../../plugin-kit/types').ShortcutCapability<any>} */ ({
      handle(input,data,context){
        const id=input.fieldKey.startsWith('item:')?input.fieldKey.slice(5):''
        const index=data.items.findIndex(item=>item.id===id)
        if(index<0)return null
        if(input.key==='Enter'&&!input.shiftKey){
          const current=data.items[index]
          if(isRichTextEmpty(current.text,context)){
            if(data.items.length===1)return {kind:'exit'}
            const remaining={...data,items:data.items.filter(item=>item.id!==id)}
            if(index===data.items.length-1)return {kind:'exit',data:remaining}
            const next=data.items[index+1]
            return {
              kind:'update',
              data:remaining,
              focus:{fieldKey:`item:${next.id}`,offset:'start'},
            }
          }
          const parts=context.splitField(input.fieldKey,input.selection)
          if(!parts)return null
          const newId=context.createId('item')
          const items=data.items.map(item=>item.id===id?{...item,text:parts.before}:item)
          items.splice(index+1,0,{id:newId,text:parts.after})
          return {kind:'update',data:{...data,items},focus:{fieldKey:`item:${newId}`,offset:'start'}}
        }
        if(input.key==='Backspace'&&input.selection.start===0&&input.selection.end===0&&index>0){
          const previous=data.items[index-1]
          const items=data.items.map(item=>({...item}))
          items[index-1].text+=items[index].text
          items.splice(index,1)
          return {kind:'update',data:{...data,items},focus:{fieldKey:`item:${previous.id}`,offset:context.fieldLength(`item:${previous.id}`)}}
        }
        return null
      },
    })),
    selectionSlice:createItemSelectionSlice(),
    conversion:Object.freeze({
      selectionMode:'per-block',
      export(data){
        return {kind:'rich-text',data:{text:data.items.map(item=>item.text).join('<br>')}}
      },
      canImport(payload){
        return acceptsTextPayload(payload)
      },
      import(payload){
        return {style:/** @type {'unordered'} */('unordered'),items:[{id:'item-0',text:richTextFromPayload(payload)}]}
      },
    }),
    clipboard:Object.freeze({
      slice(data,context){
        const selected=[]
        const remaining=[]
        for(const item of data.items){
          const field=context.field(`item:${item.id}`)
          if(!field){
            remaining.push({...item})
            continue
          }
          if(field.whole||field.selected){
            selected.push({...item,text:field.selected})
          }
          const text=field.before+field.after
          if(text)remaining.push({...item,text})
        }
        if(!selected.length)throw new Error('List clipboard selection is empty')
        if(!remaining.length)remaining.push({id:context.createId('item'),text:''})
        return {
          parts:[{kind:/** @type {'local-block'} */ ('local-block'),data:{style:data.style,items:selected}}],
          remaining:{style:data.style,items:remaining},
          focus:null,
        }
      },
    }),
    settings:Object.freeze({
      kind:/** @type {'actions'} */('actions'),
      actions(data){
        return [
          Object.freeze({id:'unordered',label:Object.freeze({key:'bulletedTitle',fallback:'Bulleted List'}),icon:ICON_UL,active:data.style==='unordered'}),
          Object.freeze({id:'ordered',label:Object.freeze({key:'numberedTitle',fallback:'Numbered List'}),icon:ICON_OL,active:data.style==='ordered'}),
        ]
      },
      apply(data,actionId){
        if(actionId!=='ordered'&&actionId!=='unordered')throw new RangeError(`Unknown list style: ${actionId}`)
        return {...data,style:actionId}
      },
    }),
    htmlImport:Object.freeze({
      matchesRoot(element){
        return element.tagName==='UL'||element.tagName==='OL'
      },
      importRoot(element,context){
        const items=[...element.children].filter(child=>child.tagName==='LI').map(li=>({
          id:context.createId('item'),
          text:context.serializeRichText(li),
        }))
        if(!items.length)throw new TypeError('Imported list root must contain list items')
        return {
          style:element.tagName==='OL'?/** @type {'ordered'} */('ordered'):/** @type {'unordered'} */('unordered'),
          items,
        }
      },
    }),
  })

  return Object.freeze({
    type:'list',
    label:Object.freeze({key:'bulletedTitle',fallback:'Bulleted List'}),
    icon:ICON_UL,
    styles: definitionStyles(config, [editorStyles]),
    toolbox,
    schema:listDataSchema,
    capabilities,
    setup(){
      let destroyed=false
      return {
        create(initial,context){
          if(destroyed)throw new Error('List runtime is destroyed')
          const document=context.ownerDocument
          const host=document.createElement('div')
          host.className='oe-list-host'
          let list
          let data={style:initial.style,items:initial.items.map(item=>({...item}))}
          let readOnly=context.isReadOnly()
          let instanceDestroyed=false
          const nodes=new Map()

          const createItem=item=>{
            const li=document.createElement('li')
            li.className='oe-list__item'
            li.dataset.itemId=item.id
            li.contentEditable=readOnly?'false':'true'
            if(item.text)setSanitizedHtml(li,item.text)
            nodes.set(item.id,li)
            return li
          }

          const reconcile=(next,previousCanonical)=>{
            const previousText=new Map((previousCanonical?.items??[]).map(item=>[item.id,item.text]))
            const tag=next.style==='ordered'?'ol':'ul'
            if(!list||list.tagName.toLowerCase()!==tag){
              const replacement=document.createElement(tag)
              replacement.className=`oe-list oe-list--${next.style}`
              replacement.dataset.style=next.style
              if(list)list.replaceWith(replacement)
              else host.appendChild(replacement)
              list=replacement
            }
            const live=new Set()
            for(const [index,item] of next.items.entries()){
              live.add(item.id)
              const li=nodes.get(item.id)??createItem(item)
              li.contentEditable=readOnly?'false':'true'
              // Hydrated inline widgets differ from canonical token markup.
              // An unchanged item keeps its live children and native range.
              if(previousText.get(item.id)!==item.text&&li.innerHTML!==item.text){
                if(item.text)setSanitizedHtml(li,item.text)
                else li.textContent=''
              }
              // Do not move a stable editing host: DOM reparenting can reset
              // its native selection even when its final order is unchanged.
              if(list.children[index]!==li)list.insertBefore(li,list.children[index]??null)
            }
            for(const [id,node] of nodes){
              if(live.has(id))continue
              node.remove()
              nodes.delete(id)
            }
            data={style:next.style,items:next.items.map(item=>({...item}))}
          }

          reconcile(data)
          return {
            element:host,
            read:()=>({
              style:data.style,
              items:data.items.map(item=>({
                id:item.id,
                text:nodes.get(item.id)?.innerHTML.trim()??item.text,
              })),
            }),
            update(next,previousCanonical){if(!instanceDestroyed)reconcile(next,previousCanonical)},
            editableFields:()=>Object.freeze(data.items.flatMap(item=>{
              const element=nodes.get(item.id)
              return element?[Object.freeze({
                key:`item:${item.id}`,
                element,
                mode:/** @type {'rich-text'} */('rich-text'),
              })]:[]
            })),
            setReadOnly(value){
              readOnly=value
              for(const node of nodes.values())node.contentEditable=value?'false':'true'
            },
            focus(target){
              if(instanceDestroyed||readOnly)return
              const key=target?.fieldKey
              const id=key?.startsWith('item:')?key.slice(5):data.items[0]?.id
              nodes.get(id)?.focus()
            },
            destroy(){instanceDestroyed=true;nodes.clear()},
          }
        },
        destroy(){destroyed=true},
      }
    },
  })
}
