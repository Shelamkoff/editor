import assert from 'node:assert/strict'
import {readFileSync,writeFileSync} from 'node:fs'
import {execFileSync,spawnSync} from 'node:child_process'
import {join} from 'node:path'
const temp='test-results/audit-closeout-2026-11-01/',root='scripts/parity/checkpoints/2026-11-05/list-edit/',initial=readFileSync(temp+'list-edit-run-path.txt','utf8').trim(),source=JSON.parse(readFileSync(join(initial,'manifest.json'))).source.head,head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();assert.equal(head,source)
const directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init','review','controls'],{encoding:'utf8'}).trim();writeFileSync(temp+'list-edit-followup-run-path.txt',directory)
const env={...process.env,EDITOR_RESULTS_DIR:directory},reviewer=temp+'review-list-edit-corrected.mjs',raw=join(initial,'comparison.json')
for(const gate of['review','controls']){const command=gate==='review'?[reviewer,raw,source,join(directory,'review.json')]:[root+'controls.mjs',reviewer,raw,source,join(directory,'controls')],r=spawnSync(process.execPath,['scripts/verification-results.mjs','run',gate,...(gate==='controls'?['--require','review']:[]),'--',process.execPath,...command],{env,encoding:'utf8',windowsHide:true,maxBuffer:64*1024*1024});console.log(gate+': '+r.status+' '+(r.stdout??'').slice(-900));if(r.status!==0)console.error(r.stderr)}
const r=spawnSync(process.execPath,['scripts/verification-results.mjs','finish'],{env,encoding:'utf8',windowsHide:true,maxBuffer:16*1024*1024});console.log(r.stdout??'');process.stderr.write(r.stderr??'');process.exitCode=r.status??1
