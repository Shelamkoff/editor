// @ts-check
import { findNodeAtOffset, getTextLength, getTextOffset } from '../shared/textOffset.js'

const HIGHLIGHT_KEY = 'oe-cross-select-v2'

function clonePoint(point) {
  return point ? { blockId: point.blockId, fieldKey: point.fieldKey, offset: point.offset } : null
}

export class SelectionController {
  #root
  #runtime
  #reconciler
  #view
  #document
  #window
  #controller
  #dragStart = null
  #bookmark = null
  #range = null
  #wholeBlocks = false
  #conversionCaret = false
  #stagingComposition = false
  #openingComposition = false
  #generation = 0
  #navigationX = null
  #highlight = null

  constructor({ root, runtime, reconciler, view }) {
    if (!root?.ownerDocument) throw new TypeError('SelectionController requires an editor root')
    this.#root = root
    this.#runtime = runtime
    this.#reconciler = reconciler
    this.#view = view
    this.#document = root.ownerDocument
    this.#window = this.#document.defaultView
    const AbortControllerCtor = this.#window?.AbortController ?? AbortController
    this.#controller = new AbortControllerCtor()
    const signal = this.#controller.signal

    try {
      root.addEventListener('mousedown', event => this.#onMouseDown(event), { signal })
      root.addEventListener('dragstart', event => {
        // Extending our logical range must not become native text drag/drop.
        if (this.#dragStart) event.preventDefault()
      }, { signal })
      this.#document.addEventListener('mousemove', event => this.#onMouseMove(event), { signal })
      this.#document.addEventListener('mouseup', () => this.#onMouseUp(), { signal })
      this.#document.addEventListener('selectionchange', () => this.#ensureCurrent(), { signal })
      this.#document.addEventListener('mousedown', event => {
        const target = event.target
        if (target && typeof target === 'object' && 'nodeType' in target && !root.contains(target)) {
          this.clear()
          const native = this.#window?.getSelection?.()
          if (native?.anchorNode && root.contains(native.anchorNode)) native.removeAllRanges()
        }
      }, { capture: true, signal })
    } catch (error) {
      // A native event host can fail after installing one of the callbacks.
      // Constructor failure leaves no public controller for destroy(), so
      // revoke the entire provisional listener scope before propagating it.
      try { this.#controller.abort() } catch {}
      throw error
    }
  }

  get active() {
    this.#ensureCurrent()
    if (this.wholeBlockIds.length) return true
    return Boolean(
      this.#bookmark
      && this.#range
      && (
        this.#wholeBlocks
        || this.#bookmark.anchor.blockId !== this.#bookmark.focus.blockId
        || this.#bookmark.anchor.fieldKey !== this.#bookmark.focus.fieldKey
      )
    )
  }

  get dragging() {
    return this.#dragStart !== null
  }

  get wholeBlockIds() {
    this.#ensureCurrent()
    return this.#wholeBlocks ? this.#runtime.ids()
      : !this.#bookmark ? this.#view.selectedIds : []
  }

  get bookmark() {
    this.#ensureCurrent()
    if (!this.#bookmark) return null
    return { anchor: clonePoint(this.#bookmark.anchor), focus: clonePoint(this.#bookmark.focus), ...(this.#conversionCaret ? { conversionCaret: true } : {}) }
  }

  get range() {
    this.#ensureCurrent()
    return this.#range?.cloneRange() ?? null
  }

  text() {
    return this.#range?.toString() ?? ''
  }

  extend(direction, granularity = 'character') {
    if (this.#controller.signal.aborted || this.#wholeBlocks || this.#runtime.readOnly) return false
    const native = this.#window?.getSelection?.()
    let bookmark = this.bookmark
    if (!this.active) {
      const anchor = this.#logicalPoint(native?.anchorNode, native?.anchorOffset)
      const focus = this.#logicalPoint(native?.focusNode, native?.focusOffset)
      if (!anchor || !focus || anchor.blockId !== focus.blockId || anchor.fieldKey !== focus.fieldKey) return false
      const local = this.#reconciler.getEditableField(focus.blockId, focus.fieldKey)
      if (!local || local.mode === 'plain-text') return false
      const atEdge = direction === 'backward' ? focus.offset === 0 : focus.offset === getTextLength(local.element)
      if (granularity === 'lineboundary' || (granularity !== 'line' && !atEdge)) return false
      bookmark = { anchor, focus }
    }
    const field = this.#reconciler.getEditableField(bookmark.focus.blockId, bookmark.focus.fieldKey)
    if (!field || field.mode === 'plain-text' || typeof native?.modify !== 'function') return false
    const caret = findNodeAtOffset(field.element, bookmark.focus.offset, 'start')
    const beforeRange=this.#document.createRange()
    beforeRange.setStart(caret.node,caret.offset)
    beforeRange.collapse(true)
    const beforeRect=beforeRange.getBoundingClientRect()
    if(granularity==='line')this.#navigationX??=beforeRect.left
    else this.#navigationX=null
    // Let the browser own grapheme, word and line movement inside one host.
    // A native extended Range across hosts would otherwise be clipped.
    this.#deactivate()
    field.element.focus({ preventScroll: true })
    native.collapse(caret.node, caret.offset)
    native.modify('move', direction, granularity)
    let focus = this.#logicalPoint(native.focusNode, native.focusOffset)
    if (!focus) {
      this.restore(bookmark)
      return false
    }
    const sameHost=focus.blockId === bookmark.focus.blockId && focus.fieldKey === bookmark.focus.fieldKey
    const afterRect=native.rangeCount?native.getRangeAt(0).getBoundingClientRect():beforeRect
    const staysOnLine=granularity==='line'&&sameHost&&Math.abs(afterRect.top-beforeRect.top)<Math.max(1,beforeRect.height/2)
    if (staysOnLine || (granularity==='line'&&!sameHost) || (sameHost && focus.offset === bookmark.focus.offset && granularity !== 'lineboundary')) {
      const fields = this.#runtime.ids().flatMap(blockId => this.#reconciler.getEditableFields(blockId)
        .filter(field => field.mode !== 'plain-text' && field.element.getClientRects().length)
        .map(field => ({ blockId, ...field })))
      const index = fields.findIndex(field => field.blockId === bookmark.focus.blockId && field.key === bookmark.focus.fieldKey)
      const next = fields[index + (direction === 'backward' ? -1 : 1)]
      if (next) {
        focus = { blockId: next.blockId, fieldKey: next.key, offset: direction === 'backward' ? getTextLength(next.element) : 0 }
        if(granularity==='line'){
          next.element.scrollIntoView({block:'nearest',inline:'nearest'})
          const rect=next.element.getBoundingClientRect()
          const lineHeight=Number.parseFloat(this.#window.getComputedStyle(next.element).lineHeight)||beforeRect.height||16
          const y=direction==='backward'?rect.bottom-Math.min(rect.height,lineHeight)/2:rect.top+Math.min(rect.height,lineHeight)/2
          const hit=this.#dragCaretFromPoint(this.#navigationX,y)
          const point=hit?this.#logicalPoint(hit.node,hit.offset):null
          if(point?.blockId===next.blockId&&point.fieldKey===next.key)focus=point
        }
      }
    }
    const restored = this.restore({ anchor: bookmark.anchor, focus })
    if (restored && bookmark.anchor.blockId === focus.blockId && bookmark.anchor.fieldKey === focus.fieldKey) this.#deactivate()
    return restored
  }

  clear() {
    this.#navigationX=null
    this.#dragStart = null
    this.#deactivate()
  }

  selectBlocks(ids) {
    if (this.#controller.signal.aborted) return false
    if (!Array.isArray(ids)) throw new TypeError('Selected block ids must be an array')
    const generation = this.#runtime.generation
    const revision = this.#runtime.revision
    const modeEpoch = this.#runtime.modeEpoch
    const owned = () => !this.#controller.signal.aborted
      && generation === this.#runtime.generation
      && revision === this.#runtime.revision
      && modeEpoch === this.#runtime.modeEpoch
    for (const id of ids) {
      if (!owned()) return false
      if (typeof id !== 'string' || !this.#runtime.has(id)) throw new Error(`Unknown block id: ${id}`)
      // The ID membership check may destroy the editor or replace its model.
      if (!owned()) return false
    }
    if (!owned()) return false
    this.#dragStart = null
    this.#navigationX = null
    this.#deactivate({ clearBlocks: false })
    if (!owned()) return false
    this.#view.select(ids)
  }

  restore(bookmark) {
    // A native selection callback may synchronously replace a mounted field,
    // switch the editor's control mode, or retire this controller. Validate
    // the two range endpoints across every external DOM ownership boundary.
    if (this.#controller.signal.aborted) return false
    const generation = this.#runtime.generation
    const revision = this.#runtime.revision
    const modeEpoch = this.#runtime.modeEpoch
    const canRestore = () => !this.#controller.signal.aborted
      && this.#runtime.health !== 'destroyed'
      && this.#runtime.health !== 'failed'
      && generation === this.#runtime.generation
      && revision === this.#runtime.revision
      && modeEpoch === this.#runtime.modeEpoch
    const built = this.#buildRange(bookmark)
    if (!built || !canRestore() || !this.#ownsRangeEndpoints(bookmark,built)) return false
    const native = this.#window?.getSelection?.()
    if (!native || !canRestore()) return false
    if (bookmark.conversionCaret && typeof native.collapse !== 'function') return false
    try {
      const field = this.#reconciler.getEditableField(bookmark.anchor.blockId,bookmark.anchor.fieldKey)
      if (!field || !canRestore() || !this.#ownsRangeEndpoints(bookmark,built)) return false
      // A DOM Range is inherently ordered and cannot represent a backward
      // native anchor/focus. Reject that unsupported gesture before touching
      // the previous author selection.
      const hasBaseAndExtent=typeof native.setBaseAndExtent==='function'
      const hasCollapseExtend=typeof native.collapse==='function'
        &&typeof native.extend==='function'
      if (!hasBaseAndExtent && !hasCollapseExtend
        && this.#comparePoints(bookmark.anchor,bookmark.focus)>0) return false
      if (!canRestore() || !this.#ownsRangeEndpoints(bookmark,built)) return false
      field.element.focus()
      if (!canRestore() || !this.#ownsRangeEndpoints(bookmark,built)) return false
      if (hasBaseAndExtent) {
        native.setBaseAndExtent(built.anchor.node,built.anchor.offset,built.focus.node,built.focus.offset)
      } else if (hasCollapseExtend) {
        native.collapse(built.anchor.node,built.anchor.offset)
        if (!canRestore() || !this.#ownsRangeEndpoints(bookmark,built)) return false
        native.extend(built.focus.node,built.focus.offset)
      } else {
        native.removeAllRanges()
        native.addRange(built.range)
      }
      if (!canRestore() || !this.#ownsRangeEndpoints(bookmark,built)
        || !this.#nativeSelectionMatches(bookmark,native)) return false
      if(bookmark.conversionCaret){
        // Conversion's final native collapsed caret is part of the same
        // successful author gesture. Publishing highlight/current blocks
        // before this callback would leak a retired cross-selection if it
        // throws, remounts the field or hands focus to another editor.
        const last=this.#reconciler.getEditableField(bookmark.focus.blockId,bookmark.focus.fieldKey)
        if (!last || !canRestore() || !this.#ownsRangeEndpoints(bookmark,built)) return false
        last.element.focus({preventScroll:true})
        if (!canRestore() || !this.#ownsRangeEndpoints(bookmark,built)) return false
        native.collapse(built.focus.node,built.focus.offset)
        const collapsed={anchor:bookmark.focus,focus:bookmark.focus}
        if (!canRestore() || !this.#ownsRangeEndpoints(bookmark,built)
          || this.#document.activeElement!==last.element
          || !this.#nativeSelectionMatches(collapsed,native)) return false
        if (!canRestore()) return false
      }
      this.#activate(bookmark,built.range)
      if (!canRestore()) return false
      if(bookmark.conversionCaret){
        this.#conversionCaret=true
        this.#view.setCurrent(bookmark.focus.blockId)
      }
      return canRestore()
    } catch { return false }
  }

  #nativeSelectionMatches(bookmark,native) {
    // Native setters can silently do nothing, and selectionchange listeners
    // can synchronously install a different caret inside the *same* fields.
    // The logical bookmark must still match both mounted native endpoints
    // before we publish selected blocks or our custom highlight.
    const matches=(node,offset,point)=>{
      const field=this.#reconciler.getEditableField(point.blockId,point.fieldKey)
      return Boolean(node&&field&&field.mode!=='plain-text'
        &&field.element.contains(node)
        &&getTextOffset(field.element,node,offset)===point.offset)
    }
    return matches(native.anchorNode,native.anchorOffset,bookmark.anchor)
      &&matches(native.focusNode,native.focusOffset,bookmark.focus)
  }

  #ownsRangeEndpoints(bookmark,built) {
    if (!bookmark?.anchor || !bookmark?.focus) return false
    const anchor=this.#reconciler.getEditableField(bookmark.anchor.blockId,bookmark.anchor.fieldKey)
    const focus=this.#reconciler.getEditableField(bookmark.focus.blockId,bookmark.focus.fieldKey)
    return Boolean(anchor&&focus
      &&anchor.mode!=='plain-text' &&focus.mode!=='plain-text'
      &&anchor.element.contains(built.anchor.node)
      &&focus.element.contains(built.focus.node))
  }

  activate(range) {
    if (this.#controller.signal.aborted || !range || range.collapsed) return false
    const generation = this.#runtime.generation
    const revision = this.#runtime.revision
    const modeEpoch = this.#runtime.modeEpoch
    const owned = () => !this.#controller.signal.aborted
      && generation === this.#runtime.generation
      && revision === this.#runtime.revision
      && modeEpoch === this.#runtime.modeEpoch
    const start = this.#logicalPoint(range.startContainer, range.startOffset)
    if (!owned()) return false
    const end = this.#logicalPoint(range.endContainer, range.endOffset)
    if (!owned() || !start || !end
      || (start.blockId === end.blockId && start.fieldKey === end.fieldKey)) return false

    const native = this.#window?.getSelection?.() ?? null
    if (!owned()) return false
    const nativeAnchor = native?.anchorNode
      ? this.#logicalPoint(native.anchorNode, native.anchorOffset)
      : null
    if (!owned()) return false
    const nativeFocus = native?.focusNode
      ? this.#logicalPoint(native.focusNode, native.focusOffset)
      : null
    if (!owned()) return false
    const nativeRange = native?.rangeCount ? native.getRangeAt(0) : null
    if (!owned()) return false
    const matchesNative = nativeRange
      && nativeRange.compareBoundaryPoints(0, range) === 0
      && nativeRange.compareBoundaryPoints(2, range) === 0
    if (!owned()) return false
    const bookmark = matchesNative && nativeAnchor && nativeFocus
      ? { anchor: nativeAnchor, focus: nativeFocus }
      : { anchor: start, focus: end }

    this.#activate(bookmark, range)
    return owned()
  }

  deactivate() {
    this.#deactivate()
  }

  /** Restore a completed structural operation only to the same mounted
   * block and author revision. A queued callback may outlive render(), Undo,
   * a read-only change, or the user's move to another block.
   * @param {string} blockId
   * @param {any} target
   */
  #queueOwnedFocus(blockId,target) {
    const generation=this.#runtime.generation
    const revision=this.#runtime.revision
    const modeEpoch=this.#runtime.modeEpoch
    const ownsFocus=()=>!this.#controller.signal.aborted&&!this.#runtime.readOnly
      &&this.#runtime.health!=='destroyed'
      &&this.#runtime.health!=='failed'
      &&generation===this.#runtime.generation
      &&revision===this.#runtime.revision
      &&modeEpoch===this.#runtime.modeEpoch
      &&this.#runtime.has(blockId)
    if(!ownsFocus())return
    const mounted=this.#view.element(blockId)
    if(!ownsFocus()||!mounted)return
    const native=this.#window?.getSelection?.()
    if(!ownsFocus())return
    const focused=this.#document.activeElement
    const nativePosition=native?{
      anchorNode:native.anchorNode,anchorOffset:native.anchorOffset,
      focusNode:native.focusNode,focusOffset:native.focusOffset,
    }:null
    if(!ownsFocus())return
    queueMicrotask(()=>{
      if(!ownsFocus())return
      // A later author caret movement does not advance document revision.
      // Recheck ownership AFTER reading each externally observable view/DOM
      // getter: a reentrant callback can retire this editor while returning
      // the same mounted element or current-block ID.
      const current=this.#window?.getSelection?.()
      if(!ownsFocus())return
      const nativeMoved=nativePosition&&(
        current?.anchorNode!==nativePosition.anchorNode
        ||current?.anchorOffset!==nativePosition.anchorOffset
        ||current?.focusNode!==nativePosition.focusNode
        ||current?.focusOffset!==nativePosition.focusOffset
      )
      if(!ownsFocus()||nativeMoved)return
      const currentMounted=this.#view.element(blockId)
      if(!ownsFocus()||currentMounted!==mounted)return
      const currentId=this.#view.currentId
      if(!ownsFocus()||currentId!==blockId)return
      const active=this.#document.activeElement
      if(!ownsFocus()||active!==focused)return
      this.#view.focus(blockId,target)
    })
  }

  removeWholeBlocks() {
    if (this.#controller.signal.aborted) return false
    const ids = this.wholeBlockIds
    if (!ids.length) return false
    const currentId = this.#runtime.interact('selection.remove', () => this.#runtime.removeBlocks(ids), blockId => {
      if (!blockId) return null
      const field = this.#reconciler.getEditableFields(blockId)[0]
      const point = { blockId, fieldKey: field?.key ?? '', offset: 0 }
      return { anchor: point, focus: { ...point } }
    })
    if (!currentId) return false
    if (!this.#canPresentCommitted()) return true
    this.#deactivate()
    this.#view.reconcileInteraction()
    if(currentId){
      this.#view.setCurrent(currentId)
      this.#queueOwnedFocus(currentId,{offset:'start'})
    }
    return true
  }

  replace(replacement = { kind: 'text', text: '' }) {
    if (this.#controller.signal.aborted) return false
    const bookmark = this.bookmark
    const whole = this.wholeBlockIds
    if (!bookmark && !whole.length) return false
    const result = this.#runtime.interact('selection.replace', () => whole.length
      ? this.#runtime.replaceWholeDocument(replacement, whole)
      : this.#runtime.replaceLogicalRange(bookmark, replacement), point => {
        if (!point) return null
        const caret = { blockId: point.blockId, fieldKey: point.fieldKey, offset: point.offset }
        return { anchor: caret, focus: { ...caret } }
      })
    if (!result) return false
    if (!this.#canPresentCommitted()) return true
    this.#deactivate()
    this.#view.reconcileInteraction()
    this.#view.setCurrent(result.blockId)
    this.#queueOwnedFocus(result.blockId,{
      fieldKey: result.fieldKey,
      offset: result.offset,
    })
    return true
  }

  beginComposition() {
    if (this.#openingComposition) return null
    // User focus and native selection callbacks can recursively attempt to
    // begin IME on the same selection. Only the outer staging turn may issue
    // a composition handle; the flag is cleared even after a native throw.
    this.#openingComposition = true
    try {
    if (this.#controller.signal.aborted || this.#runtime.readOnly
      || this.#runtime.health !== 'ready' || !this.active) return null
    const generation = this.#runtime.generation
    const revision = this.#runtime.revision
    const modeEpoch = this.#runtime.modeEpoch
    const canStage = () => !this.#controller.signal.aborted
      && !this.#runtime.readOnly
      && this.#runtime.health === 'ready'
      && generation === this.#runtime.generation
      && revision === this.#runtime.revision
      && modeEpoch === this.#runtime.modeEpoch
    const bookmark = this.bookmark
    if (!canStage()) return null
    if (!bookmark && this.wholeBlockIds.length) return this.#beginWholeComposition(this.wholeBlockIds)
    const built = this.#buildRange(bookmark)
    const native = this.#window?.getSelection?.()
    if (!built || !native || !canStage() || typeof native.setBaseAndExtent !== 'function'
      || !this.#ownsRangeEndpoints(bookmark,built)) return null
    const start = this.#comparePoints(bookmark.anchor, bookmark.focus) <= 0 ? bookmark.anchor : bookmark.focus
    const field = this.#reconciler.getEditableField(start.blockId, start.fieldKey)
    if (!field || field.mode === 'plain-text' || !canStage()
      || !this.#ownsRangeEndpoints(bookmark,built)) return null
    const whole = this.#wholeBlocks
    let settled = false
    // Stage the preedit caret before retiring the existing author-selected
    // range. Focus/native selection callbacks can throw, remount the field,
    // move to another editor or revoke the control epoch. In all such cases
    // retain the old logical range rather than leaking an IME session.
    const stagingCaret={blockId:start.blockId,fieldKey:start.fieldKey,offset:start.offset}
    let staged=false
    this.#stagingComposition=true
    try {
      field.element.focus({ preventScroll: true })
      if (canStage() && this.#document.activeElement===field.element
        && this.#ownsRangeEndpoints(bookmark,built)) {
        native.setBaseAndExtent(
          built.range.startContainer,built.range.startOffset,
          built.range.startContainer,built.range.startOffset,
        )
        const collapsed={anchor:stagingCaret,focus:stagingCaret}
        staged=canStage() && this.#document.activeElement===field.element
          && this.#ownsRangeEndpoints(bookmark,built)
          && this.#nativeSelectionMatches(collapsed,native)
      }
    } catch {
      staged=false
    } finally {
      this.#stagingComposition=false
    }
    if (!staged) return null
    this.#deactivate()
    // clearSelection notifies host observers. If one of them has already
    // selected new blocks (or changed control mode), do not hand out an IME
    // session with an obsolete author selection.
    if (!canStage() || this.#view.selectedIds.length) return null
    const restore = () => {
      if (settled) return false
      // IME may alter the provisional caret within its current host, but a
      // newer focus on another host, or remount of the original field, is a
      // different author gesture and permanently revokes this old session.
      let ownsNativeHost=false
      try {
        const currentField=this.#reconciler.getEditableField(start.blockId,start.fieldKey)
        ownsNativeHost=currentField?.element===field.element
          &&this.#document.activeElement===field.element
      } catch {}
      if (!ownsNativeHost || this.#controller.signal.aborted || this.#runtime.readOnly
        || this.#runtime.health !== 'ready' || this.#runtime.modeEpoch !== modeEpoch
        || this.#runtime.generation !== generation || this.#runtime.revision !== revision) {
        settled=true
        return false
      }
      settled = true
      if (!this.restore(bookmark)) return false
      this.#wholeBlocks = whole
      if (whole) this.#view.select(this.#runtime.ids())
      return true
    }
    return {
      blockId: start.blockId,
      fieldKey: start.fieldKey,
      commit: text => restore() && this.replace({ kind: 'text', text }),
      cancel: restore,
    }
    } finally {
      this.#openingComposition = false
    }
  }

  split() {
    if (this.#controller.signal.aborted) return false
    const bookmark=this.bookmark
    if(!bookmark||this.#wholeBlocks||this.#runtime.readOnly)return false
    const target=this.#runtime.interact('selection.split',()=>{
      const structured=this.#runtime.splitStructuredSelection(bookmark)
      if(structured)return structured
      const point=this.#runtime.replaceLogicalRange(bookmark,{kind:'text',text:''})
      const id=point?this.#runtime.splitBlock(point.blockId,point.fieldKey,{start:point.offset,end:point.offset}):false
      return id?{blockId:id,offset:0}:false
    },target=>{
      if(!target)return null
      const fields=this.#reconciler.getEditableFields(target.blockId)
      const field=target.fieldKey?fields.find(field=>field.key===target.fieldKey):fields[0]
      if(!field)return null
      const caret={blockId:target.blockId,fieldKey:field.key,offset:target.offset}
      return {anchor:caret,focus:{...caret}}
    })
    if(!target)return false
    if(!this.#canPresentCommitted())return true
    this.#deactivate()
    this.#view.reconcileInteraction()
    this.#view.setCurrent(target.blockId)
    this.#queueOwnedFocus(target.blockId,{...(target.fieldKey?{fieldKey:target.fieldKey}:{}),offset:target.offset})
    return true
  }

  #beginWholeComposition(ids) {
    const generation = this.#runtime.generation
    const revision = this.#runtime.revision
    const modeEpoch = this.#runtime.modeEpoch
    const ownsStage = () => !this.#controller.signal.aborted
      && !this.#runtime.readOnly
      && this.#runtime.health !== 'destroyed'
      && this.#runtime.health !== 'failed'
      && this.#runtime.generation === generation
      && this.#runtime.revision === revision
      && this.#runtime.modeEpoch === modeEpoch
    const blockId = ids.find(id => this.#reconciler.getEditableFields(id).length)
    const field = blockId ? this.#reconciler.getEditableFields(blockId)[0] : null
    if (!field || !ownsStage()) return null
    // Focus can trigger a newer explicit author selection without changing
    // revision or control epoch. A retained IME handle must not replace it.
    const selectedBefore=[...this.#view.selectedIds]
    if (!ownsStage()) return null
    let settled = false
    // Focus is an externally observable operation. Stage first, then retire
    // the former whole-block selection only if the new editing host accepted
    // its focus. A failed/throwing focus must leave that selection intact.
    let focused = false
    try {
      focused = this.#view.focus(blockId, { fieldKey: field.key, offset: 'start' }) === true
    } catch {
      return null
    }
    if (!focused || !ownsStage()) return null
    const selectedAfter=[...this.#view.selectedIds]
    if (!ownsStage() || selectedAfter.length!==selectedBefore.length
      || selectedAfter.some((id,index)=>id!==selectedBefore[index])) return null
    // Untouched blocks must never retain provisional preedit DOM after the
    // canonical commit. The old selection is retired only after stage succeeds.
    this.#deactivate()
    if (!ownsStage()) return null
    const stagedSelection=[...this.#view.selectedIds]
    if (stagedSelection.length) return null
    const stagedCurrent=this.#view.currentId
    const stagedFocus=this.#document.activeElement
    const restore = () => {
      if (settled) return false
      let sameAuthorSelection=false
      try {
        const currentSelected=[...this.#view.selectedIds]
        sameAuthorSelection=currentSelected.length===stagedSelection.length
          &&currentSelected.every((id,index)=>id===stagedSelection[index])
          &&this.#view.currentId===stagedCurrent
          &&this.#document.activeElement===stagedFocus
      } catch {}
      if (!sameAuthorSelection || this.#controller.signal.aborted || this.#runtime.readOnly
        || this.#runtime.health !== 'ready' || this.#runtime.modeEpoch !== modeEpoch
        || this.#runtime.generation !== generation || this.#runtime.revision !== revision) {
        settled=true
        return false
      }
      settled = true
      this.selectBlocks(ids)
      return true
    }
    return {
      blockId, fieldKey: field.key,
      commit: text => restore() && this.replace({ kind: 'text', text }),
      cancel: restore,
    }
  }

  selectAllBlocks() {
    if(this.#controller.signal.aborted || !this.#runtime.size)return false
    const firstId=this.#runtime.idAt(0)
    const lastId=this.#runtime.idAt(this.#runtime.size-1)
    if(!firstId||!lastId)return false
    const firstFields = this.#reconciler.getEditableFields(firstId)
    const lastFields = this.#reconciler.getEditableFields(lastId)
    const first = firstFields[0]
    const last = lastFields[lastFields.length - 1]
    if (!first || !last || first.mode === 'plain-text' || last.mode === 'plain-text') {
      const ids = this.#runtime.ids()
      const fields = ids.flatMap(blockId => this.#reconciler.getEditableFields(blockId)
        .filter(field => field.mode !== 'plain-text')
        .map(field => ({ blockId, ...field })))
      const anchor = fields[0]
      const focus = fields[fields.length - 1]
      const firstShell = this.#reconciler.getElement(firstId)
      const lastShell = this.#reconciler.getElement(lastId)
      if (!firstShell || !lastShell) return false
      if (!anchor || !focus) {
        this.selectBlocks(ids)
        return true
      }
      const bookmark = {
        anchor: { blockId: anchor.blockId, fieldKey: anchor.key, offset: 0 },
        focus: { blockId: focus.blockId, fieldKey: focus.key, offset: getTextLength(focus.element) },
      }
      const native = this.#window?.getSelection?.()
      if (!native) return false
      const editingRange = this.#buildRange(bookmark)
      if (!editingRange) return false
      const range = this.#document.createRange()
      range.setStartBefore(firstShell)
      range.setEndAfter(lastShell)
      anchor.element.focus({ preventScroll: true })
      native.removeAllRanges()
      native.addRange(editingRange.range)
      this.#activate(bookmark, range)
      this.#wholeBlocks = true
      this.#view.select(ids)
      return true
    }
    const bookmark = {
      anchor: { blockId: firstId, fieldKey: first.key, offset: 0 },
      focus: { blockId: lastId, fieldKey: last.key, offset: getTextLength(last.element) },
    }
    const restored = this.restore(bookmark)
    if (restored) this.#wholeBlocks = true
    return restored
  }

  destroy() {
    if (this.#controller.signal.aborted) return
    // Revoke native listeners before entering DOM/view cleanup callbacks.
    // Clearing selected blocks can synchronously call destroy() again, and
    // errors in one observer must not prevent independent resource release.
    this.#controller.abort()
    this.#navigationX = null
    this.#dragStart = null
    this.#bookmark = null
    this.#conversionCaret = false
    this.#range = null
    this.#wholeBlocks = false
    try { this.#root.classList.remove('oe-editor--cross-selecting') } catch {}
    try { this.#view.clearSelection() } catch {}
    try { this.#hideHighlight() } catch {}
  }

  #canPresentCommitted() {
    // A successful model transaction may synchronously publish to a host
    // callback that destroys this selection owner. Its canonical result
    // remains committed, but the old selection cannot touch detached DOM.
    return !this.#controller.signal.aborted
      && !this.#runtime.readOnly
      && this.#runtime.health !== 'destroyed'
      && this.#runtime.health !== 'failed'
  }

  #deactivate({ clearBlocks = true } = {}) {
    this.#bookmark = null
    this.#conversionCaret = false
    this.#range = null
    this.#wholeBlocks = false
    this.#root.classList.remove('oe-editor--cross-selecting')
    if (clearBlocks) this.#view.clearSelection()
    this.#hideHighlight()
  }

  #ensureCurrent() {
    // Native focus/selectionchange may fire while the IME preedit is being
    // staged. Until its caret has been proven valid, preserve the original
    // cross-block author bookmark rather than clearing it reentrantly.
    if (this.#stagingComposition || !this.#bookmark) return
    if (this.#generation !== this.#runtime.generation) {
      this.clear()
      return
    }
    const native = this.#window?.getSelection?.()
    if (!this.#dragStart && !this.#wholeBlocks && native?.rangeCount === 0) {
      this.clear()
      return
    }
    const owner = native?.isCollapsed && native.anchorNode
      ? this.#reconciler.resolveEditableTarget(native.anchorNode)
      : null
    const emptyWholeSelection = this.#wholeBlocks
      && this.#bookmark.anchor.blockId === this.#bookmark.focus.blockId
      && this.#bookmark.anchor.fieldKey === this.#bookmark.focus.fieldKey
      && this.#bookmark.anchor.offset === this.#bookmark.focus.offset
    const retainedCaret = this.#conversionCaret && owner
      && owner.blockId === this.#bookmark.focus.blockId
      && owner.fieldKey === this.#bookmark.focus.fieldKey
      && getTextOffset(owner.element,native.anchorNode,native.anchorOffset) === this.#bookmark.focus.offset
    if (!this.#dragStart && !emptyWholeSelection && !retainedCaret && owner && owner.element === this.#document.activeElement) this.clear()
  }

  #onMouseDown(event) {
    if (this.#controller.signal.aborted) return
    const generation = this.#runtime.generation
    const revision = this.#runtime.revision
    const modeEpoch = this.#runtime.modeEpoch
    const owned = () => !this.#controller.signal.aborted
      && generation === this.#runtime.generation
      && revision === this.#runtime.revision
      && modeEpoch === this.#runtime.modeEpoch
    this.#navigationX=null
    if (event.button !== 0) return
    // Toolbar inputs own their native focus without starting a document drag.
    if (event.target?.closest?.('.oe-inline-toolbar') || !owned()) return
    const caret = this.#caretFromPoint(event.clientX, event.clientY)
    if (!owned()) return
    const point = caret ? this.#logicalPoint(caret.node, caret.offset) : null
    if (!owned()) return
    if (!point) {
      if (event.target && this.#root.contains(event.target) && owned()) this.clear()
      return
    }
    this.#deactivate()
    // Clear-selection observers can synchronously retire this editor or
    // publish a different author gesture. A retired mouse press owns no drag.
    if (!owned()) return
    this.#dragStart = { caret, point, generation, bookmark: null }
  }

  #onMouseMove(event) {
    const drag = this.#dragStart
    if (!drag || (event.buttons & 1) === 0 || this.#controller.signal.aborted) return
    const owned = () => !this.#controller.signal.aborted && this.#dragStart === drag
      && !this.#runtime.readOnly
      && drag.generation === this.#runtime.generation
    if (!owned()) {
      this.clear()
      return
    }
    // Native geometry and mounted-field resolvers may synchronously destroy
    // the controller. Never dereference the retired drag after those reads.
    const caret = this.#dragCaretFromPoint(event.clientX, event.clientY)
    if (!owned()) return
    const point = caret ? this.#logicalPoint(caret.node, caret.offset) : null
    if (!owned() || !point) return
    if (point.blockId === drag.point.blockId
      && point.fieldKey === drag.point.fieldKey) {
      drag.bookmark = null
      if (this.active && owned()) this.#deactivate()
      return
    }

    const bookmark = { anchor: clonePoint(drag.point), focus: clonePoint(point) }
    const built = this.#buildRange(bookmark, drag.caret, caret)
    if (!owned() || !built) return
    drag.bookmark = bookmark
    event.preventDefault()
    if (!owned()) return
    this.#activate(bookmark, built.range)
    if (!owned()) return

    const selection = this.#window?.getSelection?.()
    if (!owned()) return
    if (selection && typeof selection.setBaseAndExtent === 'function') {
      try {
        selection.setBaseAndExtent(
          drag.caret.node,
          drag.caret.offset,
          caret.node,
          caret.offset,
        )
      } catch {}
    }
  }

  #onMouseUp() {
    const drag = this.#dragStart
    this.#dragStart = null
    if (!drag?.bookmark || drag.generation !== this.#runtime.generation || this.#runtime.readOnly) return
    if (!this.#reconciler.resolveEditableTarget(drag.caret.node)) return
    // Native dragging is confined to one editing host. Restore our completed
    // logical range after that native drag releases its selection ownership.
    this.restore(drag.bookmark)
  }

  #activate(bookmark, range) {
    this.#conversionCaret = false
    this.#generation = this.#runtime.generation
    this.#bookmark = { anchor: clonePoint(bookmark.anchor), focus: clonePoint(bookmark.focus) }
    this.#range = range.cloneRange()
    this.#root.classList.add('oe-editor--cross-selecting')
    this.#showHighlight(range)

    const anchorIndex=this.#runtime.indexOf(bookmark.anchor.blockId)
    const focusIndex=this.#runtime.indexOf(bookmark.focus.blockId)
    if(anchorIndex>=0&&focusIndex>=0){
      const from=Math.min(anchorIndex,focusIndex)
      const to=Math.max(anchorIndex,focusIndex)
      this.#view.select(this.#runtime.ids().slice(from,to+1))
    }
  }

  #logicalPoint(node, offset) {
    const owner = this.#reconciler.resolveEditableTarget(node)
    if (!owner) return null
    return {
      blockId: owner.blockId,
      fieldKey: owner.fieldKey,
      offset: getTextOffset(owner.element, node, offset),
    }
  }

  #buildRange(bookmark, anchorCaret = null, focusCaret = null) {
    const anchor = bookmark?.anchor
    const focus = bookmark?.focus
    if (!anchor || !focus) return null
    const anchorResolved = anchorCaret ?? this.#resolvePoint(anchor, 'start')
    const focusResolved = focusCaret ?? this.#resolvePoint(focus, 'end')
    if (!anchorResolved || !focusResolved) return null

    const order = this.#comparePoints(anchor, focus)
    const start = order <= 0 ? anchorResolved : focusResolved
    const end = order <= 0 ? focusResolved : anchorResolved
    const range = this.#document.createRange()
    try {
      range.setStart(start.node, start.offset)
      range.setEnd(end.node, end.offset)
    } catch {
      return null
    }
    return { range, anchor: anchorResolved, focus: focusResolved }
  }

  #resolvePoint(point, bias) {
    const field = this.#reconciler.getEditableField(point.blockId, point.fieldKey)
    if (!field || field.mode === 'plain-text') return null
    return findNodeAtOffset(field.element, point.offset, bias)
  }

  #comparePoints(left, right) {
    const leftBlock=this.#runtime.indexOf(left.blockId)
    const rightBlock=this.#runtime.indexOf(right.blockId)
    if (leftBlock !== rightBlock) return leftBlock - rightBlock
    const fields = this.#reconciler.getEditableFields(left.blockId)
    const leftField = fields.findIndex(field => field.key === left.fieldKey)
    const rightField = fields.findIndex(field => field.key === right.fieldKey)
    if (leftField !== rightField) return leftField - rightField
    return left.offset - right.offset
  }

  #caretFromPoint(x, y) {
    if (typeof this.#document.caretPositionFromPoint === 'function') {
      const point = this.#document.caretPositionFromPoint(x, y)
      return point ? { node: point.offsetNode, offset: point.offset } : null
    }
    const legacy = Reflect.get(this.#document, 'caretRangeFromPoint')
    if (typeof legacy === 'function') {
      const range = legacy.call(this.#document, x, y)
      return range ? { node: range.startContainer, offset: range.startOffset } : null
    }
    return null
  }

  #dragCaretFromPoint(x, y) {
    // Native hit testing returns non-editable containers in margins and gaps.
    // Keep the drag inside the nearest visible rich-text field, as in v1.
    let nearest = null
    for (const blockId of this.#runtime.ids()) {
      for (const field of this.#reconciler.getEditableFields(blockId)) {
        if (field.mode === 'plain-text') continue
        const rect = field.element.getBoundingClientRect()
        if (!rect.width || !rect.height) continue
        const vertical = Math.max(rect.top - y, y - rect.bottom, 0)
        const horizontal = Math.max(rect.left - x, x - rect.right, 0)
        if (!nearest || vertical < nearest.vertical || (vertical === nearest.vertical && horizontal < nearest.horizontal)) {
          nearest = { field, rect, vertical, horizontal }
        }
      }
    }
    if (!nearest) return null
    const { field, rect } = nearest
    if (y < rect.top) return findNodeAtOffset(field.element, 0, 'start')
    if (y > rect.bottom) return findNodeAtOffset(field.element, getTextLength(field.element), 'end')
    const caret = this.#caretFromPoint(
      Math.max(rect.left + 1, Math.min(rect.right - 1, x)),
      Math.max(rect.top + 1, Math.min(rect.bottom - 1, y)),
    )
    return caret && field.element.contains(caret.node) ? caret : null
  }

  #showHighlight(range) {
    const HighlightCtor = this.#window?.Highlight
    const highlights = this.#window?.CSS?.highlights
    if (!HighlightCtor || !highlights) return
    const highlight = new HighlightCtor(range)
    highlights.set(HIGHLIGHT_KEY, highlight)
    this.#highlight = highlight
  }

  #hideHighlight() {
    const highlight = this.#highlight
    this.#highlight = null
    if (!highlight) return
    const highlights = this.#window?.CSS?.highlights
    if (highlights?.get?.(HIGHLIGHT_KEY) === highlight) highlights.delete(HIGHLIGHT_KEY)
  }
}
