import {readFile,writeFile,mkdir} from 'node:fs/promises'
import {spawn} from 'node:child_process'
import {createWriteStream} from 'node:fs'
const root='/workspace/editor-audit-complete',out='/workspace/editor/test-results/audit-completion/complete-e88992ee'
let native
while(!native?.finishedAt){native=JSON.parse(await readFile(out+'/native/manifest.json','utf8'));if(!native.finishedAt)await new Promise(r=>setTimeout(r,2000))}
const pages=[...new Set([...native.results.filter(r=>!r.passed).map(r=>r.page),'native-color-lifetime.html','native-color-lifetime-trusted.html'])]
const manifest={candidate:native.source,startedAt:new Date().toISOString(),pages,results:[]}
await mkdir(out+'/followups',{recursive:true})
for(const page of pages){
 const started=Date.now(),log=createWriteStream(out+'/followups/'+page+'.log')
 const child=spawn(process.execPath,[out+'/followup-physical.mjs'],{cwd:root,env:{...process.env,EDITOR_NATIVE_PAGE:page,EDITOR_CHROME_PATH:'/usr/bin/chromium',EDITOR_RESULTS_DIR:out+'/followups/'+page},stdio:['ignore','pipe','pipe']})
 child.stdout.pipe(log,{end:false});child.stderr.pipe(log,{end:false})
 const code=await new Promise(r=>child.on('close',r));await new Promise(r=>log.end(r))
 const bytes=await readFile(out+'/followups/'+page+'.log','utf8'),match=bytes.match(/^Native [^\n]+: (\d+) passed$/m)
 const result={page,code,passed:code===0&&!!match,passedCases:match?Number(match[1]):null,durationMs:Date.now()-started}
 manifest.results.push(result);await writeFile(out+'/followups/manifest.json',JSON.stringify(manifest,null,2)+'\n');console.log(JSON.stringify(result))
}
manifest.finishedAt=new Date().toISOString();manifest.passed=manifest.results.every(r=>r.passed);await writeFile(out+'/followups/manifest.json',JSON.stringify(manifest,null,2)+'\n');process.exitCode=manifest.passed?0:1
