import {readFile,writeFile,mkdir} from 'node:fs/promises'
import {spawn} from 'node:child_process'
import {createWriteStream} from 'node:fs'
const root='/workspace/editor-audit-complete',out='/workspace/editor/test-results/audit-completion/complete-e88992ee'
let corpus,native
while(!corpus?.finishedAt||!native?.finishedAt){
 corpus=JSON.parse(await readFile(out+'/corpora/manifest.json','utf8'))
 try{native=JSON.parse(await readFile(out+'/followups/manifest.json','utf8'))}catch{}
 if(!corpus.finishedAt||!native?.finishedAt)await new Promise(r=>setTimeout(r,2000))
}
const files=corpus.results.filter(r=>!r.candidatePass||r.timedOut||r.parseError).map(r=>r.file)
const manifest={candidate:corpus.source,startedAt:new Date().toISOString(),files,results:[]}
await mkdir(out+'/corpus-followups',{recursive:true})
for(const file of files){
 const log=createWriteStream(out+'/corpus-followups/'+file+'.json'),stderr=createWriteStream(out+'/corpus-followups/'+file+'.stderr'),started=Date.now()
 const child=spawn(process.execPath,[root+'/scripts/parity/'+file],{cwd:root,env:{...process.env,EDITOR_CHROME_PATH:'/usr/bin/chromium',EDITOR_PLAYWRIGHT_PATH:'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs'},stdio:['ignore','pipe','pipe']})
 child.stdout.pipe(log,{end:false});child.stderr.pipe(stderr,{end:false})
 const code=await new Promise(r=>child.on('close',r));await Promise.all([new Promise(r=>log.end(r)),new Promise(r=>stderr.end(r))])
 let candidatePass=false,parseError=null
 try{candidatePass=JSON.parse(await readFile(out+'/corpus-followups/'+file+'.json','utf8')).candidatePass===true}catch(e){parseError=String(e)}
 const result={file,code,candidatePass,parseError,timedOut:false,durationMs:Date.now()-started};manifest.results.push(result)
 await writeFile(out+'/corpus-followups/manifest.json',JSON.stringify(manifest,null,2)+'\n');console.log(JSON.stringify(result))
}
manifest.finishedAt=new Date().toISOString();manifest.passed=manifest.results.every(r=>r.candidatePass&&!r.parseError)
await writeFile(out+'/corpus-followups/manifest.json',JSON.stringify(manifest,null,2)+'\n');process.exitCode=manifest.passed?0:1
