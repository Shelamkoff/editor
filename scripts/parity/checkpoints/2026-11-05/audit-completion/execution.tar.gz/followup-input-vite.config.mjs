import {execFileSync} from 'node:child_process'
import {appendFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
const commit='3d06f168045c1f633e470142bbb441d0207d46d2'
const paths=['tests/browser/color-lifetime-fixture.js','tests/browser/regressions/person-cards-native.js']
const overrides=new Map(paths.map(path=>{const bytes=execFileSync('git',['show',commit+':'+path],{cwd:'/workspace/editor'});return ['/workspace/editor-audit-complete/'+path,{path,bytes,sha256:createHash('sha256').update(bytes).digest('hex')}]}))
export default {cacheDir:process.env.EDITOR_VITE_CACHE_DIR,plugins:[{name:'recorded-test-input',enforce:'pre',load(id){const override=overrides.get(id.split('?')[0]);if(!override)return;const {path,bytes,sha256}=override;appendFileSync('/workspace/editor/test-results/audit-completion/complete-e88992ee/followup-input-loads.jsonl',JSON.stringify({commit,path,sha256,loadedAt:new Date().toISOString()})+'\n');return bytes.toString('utf8')}}]}
