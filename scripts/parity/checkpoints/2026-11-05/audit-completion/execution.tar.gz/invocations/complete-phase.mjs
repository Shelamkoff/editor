import{spawn}from'node:child_process'
import{readFile,writeFile}from'node:fs/promises'
import{createWriteStream}from'node:fs'
const root='/workspace/editor-audit-complete',out='/workspace/editor/test-results/audit-completion/complete-e88992ee',base='/workspace/editor/test-results/audit-completion'
const environment={...process.env,EDITOR_CHROME_PATH:'/usr/bin/chromium',EDITOR_PLAYWRIGHT_PATH:'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs',EDITOR_V1_ROOT:'/workspace/editor-reference-v1',EDITOR_SPEC_BASELINE_ROOT:'/workspace/editor-reference-baseline'}
const manifest={candidate:'e88992ee55b17e635be38a7ef715c076f6a8ac64',startedAt:new Date().toISOString(),steps:[]}
async function run(name,args,cwd=root){const log=createWriteStream(out+'/'+name+'.log'),child=spawn(process.execPath,args,{cwd,env:environment,stdio:['ignore','pipe','pipe']});child.stdout.pipe(log,{end:false});child.stderr.pipe(log,{end:false});const code=await new Promise(r=>child.on('close',r));await new Promise(r=>log.end(r));manifest.steps.push({name,code,args});await writeFile(out+'/phase-manifest.json',JSON.stringify(manifest,null,2)+'\n');console.log(JSON.stringify({name,code}));return code}
let integration
while(!integration?.finishedAt){integration=JSON.parse(await readFile(root+'/test-results/run-TINFMX/manifest.json','utf8'));if(!integration.finishedAt)await new Promise(r=>setTimeout(r,2000))}
if(integration.outcome!=='passed')throw Error('Complete integration did not pass; retain its original results and resolve before starting final comparisons')
if(await run('structural',['benchmarks/structural-authoring.mjs','git:8761946d','git:e88992ee',out+'/structural']))throw Error('Final structural proof failed')
if(await run('physical-intro',[out+'/physical-intro.mjs']))throw Error('Physical introduction failed')
await run('block-roundtrip',['scripts/parity/block-roundtrip.mjs'])
if(await run('html-native-layers',['scripts/parity/html-native-layers.mjs','e88992ee']))throw Error('HTML layer proof failed')
await Promise.all([run('native-union',[base+'/native-union.mjs',root,out+'/native','2'],'/workspace/editor'),run('corpus-union',[base+'/corpus-complete.mjs'],'/workspace/editor')])
manifest.finishedAt=new Date().toISOString();await writeFile(out+'/phase-manifest.json',JSON.stringify(manifest,null,2)+'\n')
