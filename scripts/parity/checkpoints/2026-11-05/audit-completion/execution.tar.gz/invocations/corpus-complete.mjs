import { readdir,readFile,writeFile,mkdir } from 'node:fs/promises'
import { spawn,execFileSync } from 'node:child_process'
import { createWriteStream } from 'node:fs'
import { join,resolve } from 'node:path'
const root='/workspace/editor-audit-complete',directory=resolve('test-results/audit-completion/complete-e88992ee/corpora')
await mkdir(directory,{recursive:true})
const files=[]
for(const file of(await readdir(join(root,'scripts/parity'))).sort()){
 if(!file.endsWith('.mjs')||/classifiers|verification|verify-|audit|\.test\./.test(file))continue
 const text=await readFile(join(root,'scripts/parity',file),'utf8')
 if(text.includes('candidatePass'))files.push(file)
}
const source=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim()
const manifest={source,root,startedAt:new Date().toISOString(),files,results:[]}
let next=0
const save=()=>writeFile(join(directory,'manifest.json'),JSON.stringify(manifest,null,2)+'\n')
await save()
async function worker(){while(next<files.length){const file=files[next++],started=Date.now(),log=createWriteStream(join(directory,file+'.json')),stderr=createWriteStream(join(directory,file+'.stderr'))
 const child=spawn(process.execPath,[join(root,'scripts/parity',file)],{cwd:root,env:{...process.env,EDITOR_PLAYWRIGHT_PATH:'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs',EDITOR_CHROME_PATH:'/usr/bin/chromium'},stdio:['ignore','pipe','pipe']})
 child.stdout.pipe(log,{end:false});child.stderr.pipe(stderr,{end:false});let timedOut=false
 const timer=setTimeout(()=>{timedOut=true;child.kill('SIGTERM')},900000)
 const result=await new Promise(resolve=>{child.once('error',error=>resolve({error:String(error)}));child.once('exit',(code,signal)=>resolve({code,signal}))});clearTimeout(timer)
 await Promise.all([new Promise(r=>log.end(r)),new Promise(r=>stderr.end(r))]);let candidatePass=false,parseError=null
 try{const report=JSON.parse(await readFile(join(directory,file+'.json'),'utf8'));candidatePass=report.candidatePass===true}catch(error){parseError=String(error)}
 const entry={file,...result,timedOut,candidatePass,parseError,durationMs:Date.now()-started,passed:result.code===0&&!timedOut&&candidatePass};manifest.results.push(entry);await save();console.log(JSON.stringify(entry))
}}
await Promise.all([worker(),worker()]);manifest.finishedAt=new Date().toISOString();manifest.sourceAfter=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();manifest.passed=manifest.source===manifest.sourceAfter&&manifest.results.length===files.length&&manifest.results.every(r=>r.passed);await save();process.exitCode=manifest.passed?0:1
