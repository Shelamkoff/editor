import { readFile, writeFile } from 'node:fs/promises'
import { spawn } from 'node:child_process'
import { resolve,join } from 'node:path'
const root='/workspace/editor-audit-complete'
const directory='/workspace/editor-audit-complete/test-results/run-TINFMX'
const gates=[['typecheck',['npm','run','typecheck']],['node',['npm','test']],['build',['npm','run','build']],['package',['npm','run','test:package']],['browser',['node','tests/browser/run.mjs']],['heap',['node','tests/browser/heap-gate.mjs']],['docs',['npm','run','test:docs']],['types',['npm','run','test:types']],['site',['npm','run','docs:check']],['bundle',['node','benchmarks/bundle-budget.mjs','--enforce']]]
const invocation={root,directory,umask:process.umask().toString(8),startedAt:new Date().toISOString(),gates,results:[]}
await writeFile('/workspace/editor/test-results/audit-completion/complete-e88992ee/gate-invocation.json',JSON.stringify(invocation,null,2)+'\n')
for(const[name,command]of gates){
 const child=spawn(process.execPath,[join(root,'scripts/verification-results.mjs'),'run',name,'--',...command],{cwd:root,env:{...process.env,EDITOR_RESULTS_DIR:directory,EDITOR_PLAYWRIGHT_PATH:'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs',EDITOR_CHROME_PATH:'/usr/bin/chromium'},stdio:'inherit'})
 const code=await new Promise(resolve=>{child.on('exit',resolve);child.on('error',()=>resolve(-1))});invocation.results.push({name,code});console.log(JSON.stringify({gate:name,code}));await writeFile('/workspace/editor/test-results/audit-completion/complete-e88992ee/gate-invocation.json',JSON.stringify(invocation,null,2)+'\n')
}
const finish=spawn(process.execPath,[join(root,'scripts/verification-results.mjs'),'finish'],{cwd:root,env:{...process.env,EDITOR_RESULTS_DIR:directory},stdio:'inherit'})
const code=await new Promise(resolve=>finish.on('exit',resolve));process.exitCode=code??1
