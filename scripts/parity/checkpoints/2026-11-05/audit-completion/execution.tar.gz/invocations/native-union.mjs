import { readdir,readFile,writeFile,mkdir } from 'node:fs/promises'
import { spawn,execFileSync } from 'node:child_process'
import { createWriteStream } from 'node:fs'
import { join,resolve } from 'node:path'
const root=resolve(process.argv[2]),directory=resolve(process.argv[3]),workers=Number(process.argv[4]??2)
await mkdir(directory,{recursive:true})
const source=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim()
const inventory=(await readdir(join(root,'tests/browser'))).filter(p=>/^native-[a-z0-9-]+\.html$/.test(p)).sort()
const pages=[...inventory.filter(p=>p.includes('gallery-viewer-options')),...inventory.filter(p=>!p.includes('gallery-viewer-options'))]
let displayQueue=Promise.resolve()
const manifest={source,root,startedAt:new Date().toISOString(),workers,pages,results:[]}
const save=()=>writeFile(join(directory,'manifest.json'),JSON.stringify(manifest,null,2)+'\n')
let next=0
await save()
async function work(){
 while(next<pages.length){
  const page=pages[next++];let releaseDisplay;if(page.includes('gallery-viewer-options')){const previous=displayQueue;displayQueue=new Promise(resolve=>{releaseDisplay=resolve});await previous}
  const started=Date.now(),logPath=join(directory,page+'.log'),log=createWriteStream(logPath)
  const child=spawn(process.execPath,[join(root,'tests/browser/physical-history.mjs')],{cwd:root,env:{...process.env,EDITOR_NATIVE_PAGE:page,EDITOR_RESULTS_DIR:join(directory,page),...(page.includes('gallery-viewer-options')?{EDITOR_CHROME_HEADLESS:'0',DISPLAY:':91'}:{})},stdio:['ignore','pipe','pipe']})
  child.stdout.pipe(log,{end:false});child.stderr.pipe(log,{end:false})
  let timedOut=false
  const timer=setTimeout(()=>{timedOut=true;child.kill('SIGTERM')},600000)
  const result=await new Promise(resolve=>{child.once('error',error=>resolve({error:String(error)}));child.once('exit',(code,signal)=>resolve({code,signal}))})
  clearTimeout(timer);await new Promise(resolve=>log.end(resolve));releaseDisplay?.()
  const bytes=await readFile(logPath,'utf8'),match=bytes.match(/^Native [^\n]+: (\d+) passed$/m)
  const entry={page,...result,timedOut,passedCases:match?Number(match[1]):null,durationMs:Date.now()-started,passed:result.code===0&&!timedOut&&Boolean(match)}
  manifest.results.push(entry);await save();console.log(JSON.stringify(entry))
 }
}
await Promise.all(Array.from({length:workers},work))
manifest.finishedAt=new Date().toISOString();manifest.sourceAfter=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim()
manifest.passed=manifest.source===manifest.sourceAfter&&manifest.results.length===pages.length&&manifest.results.every(r=>r.passed)
await save();console.log(JSON.stringify({passed:manifest.passed,pages:pages.length,cases:manifest.results.reduce((n,r)=>n+(r.passedCases??0),0),failed:manifest.results.filter(r=>!r.passed)}));process.exitCode=manifest.passed?0:1
