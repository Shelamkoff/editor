import {execFileSync} from 'node:child_process'
import {appendFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
const commit='e27aa184',path='tests/browser/color-lifetime-fixture.js'
const bytes=execFileSync('git',['show',commit+':'+path],{cwd:'/workspace/editor'})
const sha256=createHash('sha256').update(bytes).digest('hex')
export default {cacheDir:process.env.EDITOR_VITE_CACHE_DIR,plugins:[{name:'recorded-color-test-input',enforce:'pre',load(id){if(id.split('?')[0]!=='/workspace/editor-audit-complete/'+path)return;appendFileSync('/workspace/editor/test-results/audit-completion/complete-e88992ee/color-input-loads.jsonl',JSON.stringify({commit,path,sha256,loadedAt:new Date().toISOString()})+'\n');return bytes.toString('utf8')}}]}
