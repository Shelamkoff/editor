import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const temp = 'test-results/audit-closeout-2026-11-01/'
const script = temp + 'run-table-transfer-native-remainder.mjs'
const node = process.execPath
const env = { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONDONTWRITEBYTECODE: '1' }
const run = (args, extra = {}) => spawnSync(node, args, { env: { ...env, ...extra }, encoding: 'utf8', windowsHide: true, maxBuffer: 96 * 1024 * 1024 })
function output(result) {
  process.stdout.write(result.stdout ?? '')
  process.stderr.write(result.stderr ?? '')
}

if (process.argv[2] === 'execute') {
  for (const page of ['native-conversion-preservation.html', 'native-compound-residuals.html', 'native-compound-residuals-trusted.html']) {
    const result = run(['tests/browser/physical-history.mjs'], { EDITOR_NATIVE_PAGE: page, EDITOR_NATIVE_FILTER: '' })
    output(result)
    if (result.status !== 0) { process.exitCode = result.status ?? 1; break }
  }
} else {
  const original = readFileSync(temp + 'table-transfer-run-path.txt', 'utf8').trim()
  const manifest = JSON.parse(readFileSync(join(original, 'manifest.json')))
  const head = execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim()
  assert.equal(head, manifest.source.head)
  assert.equal(manifest.outcome, 'failed')
  assert.equal(manifest.source.dirty, false)
  assert.equal(manifest.sourceUnchanged, true)
  for (const [name, gate] of Object.entries(manifest.gates)) assert.equal(gate.outcome, ['native-related', 'site'].includes(name) ? 'failed' : 'passed')
  const log = readFileSync(join(original, 'native-related.log'), 'utf8')
  assert.match(log, /Native native-clipboard\.html: 25 passed/)
  assert.match(log, /Native native-plugin-field-clipboard\.html: 68 passed/)
  assert.match(log, /CDP Runtime\.evaluate timed out/)
  assert(!log.includes('Native native-conversion-preservation.html:'))
  const site = readFileSync(join(original, 'site.log'), 'utf8')
  assert.match(site, /htmlPages.:127/)
  assert.match(site, /en\/light styled tooltip: null/)
  const commands = {
    'native-related-remainder': [node, script, 'execute'],
    'site-browser-remainder': [node, 'scripts/vitepress-browser-smoke.mjs'],
  }
  const directory = execFileSync(node, ['scripts/verification-results.mjs', 'init', ...Object.keys(commands)], { encoding: 'utf8' }).trim()
  writeFileSync(temp + 'table-transfer-remainder-run-path.txt', directory)
  env.EDITOR_RESULTS_DIR = directory
  let exitCode = 0
  for (const [gate, command] of Object.entries(commands)) {
    const result = run(['scripts/verification-results.mjs', 'run', gate, '--', ...command])
    console.log(gate + ' ' + result.status + ' ' + (result.stdout ?? '').slice(-850))
    process.stderr.write((result.stderr ?? '').slice(-2000))
    if (result.status !== 0) exitCode = result.status ?? 1
  }
  const finish = run(['scripts/verification-results.mjs', 'finish'])
  output(finish)
  process.exitCode = exitCode || finish.status || 0
}
