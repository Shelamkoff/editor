import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { writeFileSync } from 'node:fs'
import { join } from 'node:path'

const temp = 'test-results/audit-closeout-2026-11-01/'
const scope = 'scripts/parity/checkpoints/2026-11-05/table-transfer'
const supervisor = temp + 'run-table-transfer-gates.mjs'
const source = execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim()
const env = { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONDONTWRITEBYTECODE: '1' }
const [mode] = process.argv.slice(2)
const node = process.execPath
const run = (command, args, extra = {}) => spawnSync(command, args, {
  encoding: 'utf8', windowsHide: true, maxBuffer: 128 * 1024 * 1024, env: { ...env, ...extra },
})
function report(result) {
  process.stdout.write(result.stdout ?? '')
  process.stderr.write(result.stderr ?? '')
  process.exitCode = result.status ?? 1
}
const nativePages = {
  'native-table': ['native-table-transfer.html', 'native-table-transfer-trusted.html', 'native-table-cells.html', 'native-table-cells-trusted.html', 'native-table-keyboard.html'],
  'native-related': ['native-clipboard.html', 'native-plugin-field-clipboard.html', 'native-conversion-preservation.html', 'native-compound-residuals.html', 'native-compound-residuals-trusted.html'],
}

if (mode === 'proof') {
  const result = run(node, ['scripts/parity/table-transfer.mjs'])
  const path = join(env.EDITOR_RESULTS_DIR, 'comparison.json')
  writeFileSync(path, result.stdout ?? '')
  writeFileSync(join(env.EDITOR_RESULTS_DIR, 'comparison.stderr'), result.stderr ?? '')
  assert.equal(result.status, 0, result.stderr)
  assert.equal(result.stderr, '')
  report(run(node, [scope + '/review.mjs', path, source, join(env.EDITOR_RESULTS_DIR, 'review.json')]))
} else if (mode === 'controls') {
  report(run(node, [scope + '/controls.mjs', scope + '/review.mjs', join(env.EDITOR_RESULTS_DIR, 'comparison.json'), source, join(env.EDITOR_RESULTS_DIR, 'controls')]))
} else if (nativePages[mode]) {
  for (const page of nativePages[mode]) {
    const result = run(node, ['tests/browser/physical-history.mjs'], { EDITOR_NATIVE_PAGE: page, EDITOR_NATIVE_FILTER: '' })
    report(result)
    if (result.status !== 0) break
  }
} else {
  const npm = script => ['cmd.exe', '/d', '/s', '/c', 'npm run ' + script]
  const commands = {
    proof: [node, supervisor, 'proof'], controls: [node, supervisor, 'controls'],
    build: npm('build'), node: npm('test'), typecheck: npm('typecheck'), types: npm('test:types'),
    browser: [node, 'tests/browser/run.mjs'],
    'native-table': [node, supervisor, 'native-table'], 'native-related': [node, supervisor, 'native-related'],
    package: npm('test:package'), bundle: [node, 'benchmarks/bundle-budget.mjs', '--enforce'],
    heap: [node, 'tests/browser/heap-gate.mjs'], docs: npm('test:docs'), site: npm('docs:check'),
    assets: [node, 'scripts/check-package-assets.mjs'],
  }
  const directory = execFileSync(node, ['scripts/verification-results.mjs', 'init', ...Object.keys(commands)], { encoding: 'utf8' }).trim()
  writeFileSync(temp + 'table-transfer-run-path.txt', directory)
  env.EDITOR_RESULTS_DIR = directory
  for (const [gate, command] of Object.entries(commands)) {
    const requirements = gate === 'controls' ? ['--require', 'proof'] : []
    const result = run(node, ['scripts/verification-results.mjs', 'run', gate, ...requirements, '--', ...command])
    console.log(gate + ': ' + result.status + ' ' + (result.stdout ?? '').slice(-1000))
    if (result.status !== 0) console.error((result.stderr ?? '').slice(-1500))
  }
  report(run(node, ['scripts/verification-results.mjs', 'finish']))
}
