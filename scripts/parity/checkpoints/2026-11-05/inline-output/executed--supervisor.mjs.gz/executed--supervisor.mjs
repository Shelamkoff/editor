import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {readFileSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
const temp='test-results/audit-closeout-2026-11-01/',root='scripts/parity/checkpoints/2026-11-05/inline-output',mode=process.argv[2],source=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),env={...process.env,PYTHONIOENCODING:'utf-8',PYTHONDONTWRITEBYTECODE:'1'}
const run=(command,args,extra={})=>spawnSync(command,args,{encoding:'utf8',windowsHide:true,maxBuffer:128*1024*1024,env:{...env,...extra}}),report=r=>{process.stdout.write(r.stdout??'');process.stderr.write(r.stderr??'');if(r.status!==0)process.exitCode=r.status??1}
if(mode==='proof'){const r=run(process.execPath,['scripts/parity/inline-output.mjs']),path=join(env.EDITOR_RESULTS_DIR,'inline-output.json');writeFileSync(path,r.stdout??'');writeFileSync(path+'.stderr',r.stderr??'');assert.equal(r.status,0,r.stderr);assert.equal(r.stderr,'');report(run(process.execPath,[root+'/review.mjs',path,source,join(env.EDITOR_RESULTS_DIR,'inline-output-review.json')]))}
else if(mode==='controls')report(run(process.execPath,[root+'/controls.mjs',root+'/review.mjs',join(env.EDITOR_RESULTS_DIR,'inline-output.json'),source,join(env.EDITOR_RESULTS_DIR,'inline-output-controls')]))
else if(mode?.startsWith('browser-')){for(const page of mode==='browser-existing'?['mention.html','renderer-lifetimes.html','roundtrip-trusted-types.html']:[mode==='browser-trusted'?'inline-output-trusted-types.html':'inline-output.html']){const r=run(process.execPath,['tests/browser/run.mjs'],{EDITOR_BROWSER_PAGE:page});report(r);if(r.status!==0)break}}
else{
 const gates=['proof','controls','browser-fields','browser-trusted','browser-existing','docs','site'],directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init',...gates],{encoding:'utf8'}).trim();writeFileSync(temp+'inline-output-run-path.txt',directory);env.EDITOR_RESULTS_DIR=directory
 for(const gate of gates){const command=['docs','site'].includes(gate)?['cmd.exe','/d','/s','/c','npm run '+(gate==='docs'?'test:docs':'docs:check')]:[process.execPath,temp+'run-inline-output-gates.mjs',gate],r=run(process.execPath,['scripts/verification-results.mjs','run',gate,...(gate==='controls'?['--require','proof']:[]),'--',...command]);console.log(gate+': '+r.status+' '+(r.stdout??'').slice(-1600));if(r.status!==0)console.error((r.stderr??'').slice(-2200))}
 const r=run(process.execPath,['scripts/verification-results.mjs','finish']);console.log(r.stdout??'');process.stderr.write(r.stderr??'');process.exitCode=r.status??1
}
