import{execFileSync,spawnSync}from'node:child_process'
import{writeFileSync}from'node:fs'
const tag=process.argv[2];if(!/^[a-z-]+$/.test(tag))throw Error('Scope tag required')
const directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init','docs','site'],{encoding:'utf8'}).trim();writeFileSync('test-results/audit-closeout-2026-11-01/'+tag+'-post-run-path.txt',directory);const env={...process.env,EDITOR_RESULTS_DIR:directory}
for(const gate of['docs','site']){const r=spawnSync(process.execPath,['scripts/verification-results.mjs','run',gate,'--','cmd.exe','/d','/s','/c','npm run '+(gate==='docs'?'test:docs':'docs:check')],{env,encoding:'utf8',windowsHide:true,maxBuffer:96*1024*1024});console.log(gate+': '+r.status+' '+(r.stdout??'').slice(-1700));if(r.status!==0)console.error((r.stderr??'').slice(-2400))}
const r=spawnSync(process.execPath,['scripts/verification-results.mjs','finish'],{env,encoding:'utf8',windowsHide:true,maxBuffer:16*1024*1024});console.log(r.stdout??'');process.stderr.write(r.stderr??'');process.exitCode=r.status??1
