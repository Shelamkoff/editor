"""Author's independent public snapshot model. No runtime/fixture imports."""
import argparse
import copy
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

RED = '5dbf2458f88086e359a62c9619a23cb2efad739d'
RED_SHA = '70e7ae0b603dd93eb6a909bb506cb837af7efc7365b5ec0547552c54ff7957a4'
INTEGRATION = 'efb62a4b95a865f2607a427d75577affbe0a54bb'
V1 = '5e5c7f8d2d9e9a6cf2f95cfb7fd67aba227fa340'
BASELINE = 'e981ff308000c1d92d7e820df95113c1e19bcee8'

def digest(raw): return hashlib.sha256(raw).hexdigest()
def exact(a, b): return json.dumps(a, sort_keys=True, separators=(',', ':')) == json.dumps(b, sort_keys=True, separators=(',', ':'))
def read(path):
    raw = Path(path).read_bytes()
    return gzip.decompress(raw) if str(path).endswith('.gz') else raw

def payload(): return dict(nested=dict(value=7), tags=['kept'], __proto__=dict(literal=True), constructor='own')
def document(updated=False):
    result = []
    for index, ident in enumerate(['a', 'b', 'c']):
        data = (dict(text='Opaque', rows=[dict(cells=[dict(text='Nested', metadata=dict(alignment='left'))])], own=payload()) if index == 1
                else dict(text=('<b>Updated</b> {{opaque}}' if updated else '<b>Alpha</b> &amp; {{opaque}}') if index == 0 else 'Tail'))
        result.append(dict(id=ident, type='future-block' if index == 1 else 'paragraph', dataVersion=7 if index == 1 else 2, data=data,
                           tunes=dict(textAlign='right', layout=dict(gap=2)), inline=dict(opaque=dict(type='future-inline', dataVersion=3, data=payload()))))
        if index: result[-1]['revision'] = 17 if index == 1 else 'wire-c'
    return result

def snapshot(record): return dict(copy.deepcopy(record), status='unregistered' if record['type'] == 'future-block' else 'active')
def specs():
    result = [dict(id='/'.join(['read', mode, query, target]), kind='read', mode=mode, query=query, target=target)
              for mode in ['editable', 'read-only'] for query in ['get', 'at', 'list', 'iterator'] for target in ['known', 'unknown']]
    result += [dict(id='update/'+query, kind='update', mode='editable', query=query, target='known') for query in ['get', 'at', 'list', 'iterator']]
    result += [dict(id='catalog/'+mode, kind='catalog', mode=mode) for mode in ['editable', 'read-only']]
    result += [dict(id='retired-iterator/'+step, kind='retired-iterator', mode='editable', step=step) for step in ['before-first', 'after-first']]
    return result

def verify_case(case, legacy=False):
    spec = case['spec']; assert case['id'] == spec['id']
    phases = ['legacy-control', 'dispose'] if legacy else ['load', spec['kind'], 'dispose']
    assert case['planned'] == case['completedPhases'] == phases
    assert case['error'] is None and case['diagnostics'] == []
    observations = {(o['phase'], o['property']): o for o in case['observations']}; checked = set()
    assert len(observations) == len(case['observations'])
    def check(phase, property, expected):
        key = (phase, property); checked.add(key); value = observations[key]
        assert value['status'] == 'PASS' and exact(value['actual'], expected) and exact(value['expected'], expected), (case['id'], key, value, expected)
    if legacy:
        check('legacy-control', 'actualLegacyCatalog', dict(count=3, byId='a', byIndex='a', index=0, current='a', ids=['a', 'b', 'c']))
        check('legacy-control', 'actualLegacyAuthorText', '<b>Alpha</b> &amp; {{opaque}}')
        assert len(case['unsupported']) == 1 and case['unsupported'][0]['property'] == 'currentDetachedSnapshotContract'
    else:
        assert case['unsupported'] == []
        check('load', 'canonical', document()); check('load', 'history', [False, False])
        phase = spec['kind']
        def selected(updated=False):
            records = document(updated)
            if spec.get('query') in ['get', 'at']: records = [records[1 if spec['target'] == 'unknown' else 0]]
            return [snapshot(r) for r in records]
        if phase == 'read':
            records = selected(); count = len(records)
            check(phase, 'snapshots', records); check(phase, 'secondSnapshots', records)
            check(phase, 'frozenEnvelopes', [True]*count); check(phase, 'listFrozen', spec['query'] == 'list')
            check(phase, 'mutableNestedPayload', [[False, False, False] for _ in records]); check(phase, 'noLiveDom', [False]*count)
            check(phase, 'immutableId', True); check(phase, 'otherReadUnchanged', records); check(phase, 'freshReadUnchanged', records)
            check(phase, 'canonicalUnchanged', document()); check(phase, 'history', [False, False, 0])
        elif phase == 'update':
            check(phase, 'producerInput', snapshot(document()[0])); check(phase, 'retainedSnapshot', selected())
            check(phase, 'freshSnapshot', selected(True)); check(phase, 'canonical', document(True)); check(phase, 'history', [True, False])
            check(phase, 'retainedInputDetached', document(True)); check(phase, 'undo', True); check(phase, 'undoCanonical', document())
            check(phase, 'redo', True); check(phase, 'redoCanonical', document(True)); check(phase, 'retainedProducerOriginal', 2)
        elif phase == 'catalog':
            check(phase, 'catalog', dict(count=3, current='a', indices=[0, 1, 2, -1], ids=['a', 'b', 'c']))
            check(phase, 'newCurrent', 'c'); check(phase, 'missingReads', [True]*3)
            check(phase, 'canonicalUnchanged', document()); check(phase, 'history', [False, False, 0])
        else:
            if spec['step'] == 'after-first': check(phase, 'first', snapshot(document()[0]))
            check(phase, 'iteratorDenied', True); check(phase, 'oldApiDenied', [True]*6)
            check(phase, 'successorCanonical', document()); check(phase, 'successorHistory', [False, False, 0])
    check('dispose', 'rootRemoved', True)
    assert checked == set(observations)
    expected_events = [dict(action=action, origin='external' if action == 'commit' else 'history', name='block.update') for action in ['commit', 'undo', 'redo']] if not legacy and spec['kind'] == 'update' else []
    assert exact(case['transactions'], expected_events)
    return len(checked) + 1

def git_blobs(queries):
    queries = sorted(set(queries)); raw = subprocess.check_output(['git', 'cat-file', '--batch'], input=('\n'.join(queries)+'\n').encode())
    result, offset = {}, 0
    for query in queries:
        end = raw.index(b'\n', offset); header = raw[offset:end].split(); assert len(header) == 3 and header[1] == b'blob', query
        size = int(header[2]); offset = end+1; result[query] = raw[offset:offset+size]; offset += size
        assert raw[offset:offset+1] == b'\n'; offset += 1
    assert offset == len(raw); return result

def main():
    parser = argparse.ArgumentParser()
    for name in ['raw', 'output']: parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--candidate', required=True)
    parser.add_argument('--exploratory', action='store_true')
    opts = parser.parse_args(); raw = read(opts.raw); data = json.loads(raw)
    assert data['headBefore'] == data['headAfter'] == opts.candidate and data['candidatePass'] is True
    assert data['filter'] == '' and data['group'] == 'public-snapshots' and data['serverErrors'] == []
    assert [r['source'] for r in data['results']] == ['v1', 'spec-baseline', 'candidate']
    assert {s['label']:s['sha'] for s in data['sources']} == {'v1':V1, 'spec-baseline':BASELINE, 'candidate':opts.candidate}
    semantic = {}
    for result in data['results']:
        assert exact([c['spec'] for c in result['cases']], specs()) and result['pageErrors'] == result['inputErrors'] == []
        for c in result['cases']:
            for o in c['observations']: assert o['status'] == ('PASS' if exact(o['actual'], o['expected']) else 'FAIL')
        semantic[result['source']] = sum(verify_case(c, result['source']=='v1') for c in result['cases'])
    red_path = Path('scripts/parity/checkpoints/2026-11-03/public-snapshots/source-red.json.gz')
    red_bytes = read(red_path); assert digest(red_bytes) == RED_SHA
    red = json.loads(red_bytes); assert red['headBefore'] == red['headAfter'] == RED and red['candidatePass'] is False
    assert red['group'] == data['group'] and red['filter'] == ''
    assert exact([c['spec'] for c in red['results'][2]['cases']], specs())
    for result in red['results'][:2]:
        assert result['pageErrors'] == result['inputErrors'] == []
        for c in result['cases']: verify_case(c, result['source']=='v1')
    incomplete, positive = 0, 0
    for c in red['results'][2]['cases']:
        if c['spec']['mode'] == 'read-only':
            assert '#captureFieldModes' in c['error'] and "reading 'map'" in c['error']
            assert c['completedPhases'] == c['observations'] == c['diagnostics'] == c['transactions'] == c['unsupported'] == []
            incomplete += 1
        else: verify_case(c); positive += 1
    assert (incomplete, positive) == (9,15)
    queries = [s['sha']+':'+p for corpus in [data,red] for s in corpus['sources'] for p in s['loaded']]
    runner, fixture = 'scripts/parity/public-snapshots.mjs', 'tests/browser/public-snapshots-fixture.js'
    queries += [source+':'+p for source in [RED,opts.candidate] for p in [runner,fixture]]
    blobs = git_blobs(queries)
    for corpus in [data,red]:
        for s in corpus['sources']:
            assert s['tree'] == subprocess.check_output(['git','rev-parse',s['sha']+'^{tree}']).decode().strip()
            for p,sha in s['loaded'].items(): assert digest(blobs[s['sha']+':'+p]) == sha
        assert corpus['runnerSha256'] == digest(blobs[corpus['headBefore']+':'+runner])
        assert corpus['fixtureSha256'] == digest(blobs[corpus['headBefore']+':'+fixture])
    for p in [runner,fixture]: assert blobs[RED+':'+p] == blobs[opts.candidate+':'+p] == Path(p).read_bytes()
    runtime = ['core','shared','plugins','plugin-kit','inline-tools','inline-plugins','renderer','preset','locale','index.js','index.d.ts','types.d.ts','package.json','package-lock.json']
    changed = subprocess.check_output(['git','diff','--name-only',RED,opts.candidate,'--',*runtime]).decode().splitlines()
    assert changed == ['core/BlockReconciler.js']
    patch = subprocess.check_output(['git','diff','--unified=0',RED,opts.candidate,'--','core/BlockReconciler.js']).decode()
    assert [line for line in patch.splitlines() if line.startswith('+') and not line.startswith('+++')] == ['+        fields: [],']
    assert not [line for line in patch.splitlines() if line.startswith('-') and not line.startswith('---')]
    for p,sha in data['dependencyFiles'].items(): assert digest((Path('node_modules')/p).read_bytes()) == sha
    for name,version in data['dependencyVersions'].items(): assert json.loads((Path('node_modules')/name/'package.json').read_bytes())['version'] == version
    assert data['node'] == 'v24.22.2' and data['browser'] == '156.0.8078.80' and data['platform'] == 'win32 x64'
    assert data['packageLockSha256'] == digest(Path('package-lock.json').read_bytes())
    result = dict(status='PASS',candidate=opts.candidate,cases=24,currentObservations=sum(len(c['observations']) for c in data['results'][2]['cases']),semanticChecks=semantic,
                  rawSha256=digest(raw),reviewerSha256=digest(Path(__file__).read_bytes()),sourceRed=dict(source=RED,sha256=RED_SHA,incomplete=9,positiveControls=15),
                  productionModuleIdentities=sum(len(s['loaded']) for s in data['sources']),dependencyFiles=len(data['dependencyFiles']),dependencyVersions=data['dependencyVersions'])
    opts.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))

if __name__ == '__main__': main()
