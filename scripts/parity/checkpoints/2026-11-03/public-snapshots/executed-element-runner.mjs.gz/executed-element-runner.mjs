import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
const result = spawnSync(process.execPath, ['tests/browser/physical-history.mjs'], { env: { ...process.env, EDITOR_NATIVE_PAGE: 'native-element-range.html' }, windowsHide: true, stdio: 'inherit' })
assert.equal(result.error, undefined); process.exitCode = result.status
