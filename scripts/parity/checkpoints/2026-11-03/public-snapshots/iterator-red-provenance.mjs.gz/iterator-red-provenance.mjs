import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync,writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const root='scripts/parity/checkpoints/2026-11-03/public-snapshots/',temp='test-results/audit-closeout-2026-11-01/',source='05b286fa1f325ae010521f6a576742fecb0d9dbe'
const hash=value=>createHash('sha256').update(value).digest('hex'),raw=readFileSync(temp+'public-snapshots-iterator-red.json'),data=JSON.parse(raw)
assert.equal(data.headBefore,source);assert.equal(data.headAfter,source);assert.equal(data.group,'public-snapshots');assert.equal(data.filter,'');assert.equal(data.candidatePass,false)
for(const row of data.results){assert.equal(row.cases.length,26);assert.deepEqual(row.pageErrors,[]);assert.deepEqual(row.inputErrors,[]);for(const c of row.cases){assert.equal(c.error,null);assert.deepEqual(c.completedPhases,c.planned)}}
for(const row of data.results.slice(1)){
 const failed=row.cases.flatMap(c=>c.observations.filter(o=>o.status==='FAIL').map(o=>({id:c.id,...o})))
 assert.deepEqual(failed.map(o=>[o.id,o.phase,o.property]),[['iterator/render-status','iterate','retainedSnapshot'],['iterator/remove-status','iterate','retainedSnapshot']])
 for(const o of failed){const actual=structuredClone(o.actual);actual.status=o.expected.status;assert.deepEqual(actual,o.expected);assert.equal(o.actual.status,o.expected.status==='active'?'unregistered':'active')}
}
assert.ok(data.results[0].cases.every(c=>c.observations.every(o=>o.status==='PASS')))
for(const[path,key]of [['scripts/parity/public-snapshots.mjs','runnerSha256'],['tests/browser/public-snapshots-fixture.js','fixtureSha256']])assert.equal(hash(execFileSync('git',['show',source+':'+path])),data[key])
const unit=readFileSync(temp+'iterator-status-red-unit.log');assert.ok(unit.includes('tests 2')&&unit.includes('fail 2')&&unit.includes('after render')&&unit.includes('after remove'))
const artifacts={}
for(const[name,bytes]of [['iterator-red.json.gz',raw],['iterator-red-unit.log.gz',unit],['iterator-red-provenance.mjs.gz',readFileSync(temp+'archive-snapshot-iterator-red.mjs')]]){const stored=gzipSync(bytes,{level:9});writeFileSync(root+name,stored);artifacts[name]={sha256:hash(stored),decodedSha256:hash(bytes),bytes:stored.length,decodedBytes:bytes.length}}
writeFileSync(root+'iterator-red-hashes.json',JSON.stringify(artifacts,null,2)+'\n')
writeFileSync(root+'iterator-red-review.json',JSON.stringify({source,rawSha256:hash(raw),cases:26,observations:333,failedObservations:2,incomplete:0,positiveControls:24,status:'ATTRIBUTED_REGRESSION'},null,2)+'\n')
console.log(JSON.stringify({source,rawSha256:hash(raw),failed:2,positiveControls:24}))
