// Run after the iterator RED and its production fix are committed.
import { spawnSync } from 'node:child_process'
const run=args=>spawnSync(process.execPath,['scripts/verification-results.mjs',...args],{encoding:'utf8',windowsHide:true,maxBuffer:96*1024*1024})
const npm=script=>['cmd.exe','/d','/s','/c','npm run '+script]
const gates=[['build',npm('build')],['node',[process.execPath,'--test']],['types',npm('typecheck')],['browser',[process.execPath,'tests/browser/run.mjs']],
 ['native-tools',[process.execPath,'test-results/audit-closeout-2026-11-01/run-snapshot-tools.mjs']],
 ['native-element',[process.execPath,'test-results/audit-closeout-2026-11-01/run-element-range-native.mjs']],
 ['snapshots-proof',[process.execPath,'test-results/audit-closeout-2026-11-01/run-public-snapshots-proof.mjs']],
 ['snapshots-controls',[process.execPath,'test-results/audit-closeout-2026-11-01/run-public-snapshots-controls.mjs']],
 ['bundle',[process.execPath,'benchmarks/bundle-budget.mjs','--enforce']],['heap',[process.execPath,'tests/browser/heap-gate.mjs']],
 ['docs',npm('test:docs')],['package',npm('test:package')],['site',npm('docs:check')]]
for(const name of ['EDITOR_BROWSER_PAGE','EDITOR_BROWSER_ROOT','EDITOR_NATIVE_PAGE','EDITOR_NATIVE_FILTER','EDITOR_PUBLIC_SNAPSHOTS_FILTER','EDITOR_ALIGNMENT_FILTER','EDITOR_ELEMENT_RANGE_FILTER'])delete process.env[name]
const initialized=run(['init',...gates.map(([name])=>name)])
if(initialized.status!==0)throw Error(initialized.stdout+initialized.stderr)
process.env.EDITOR_RESULTS_DIR=initialized.stdout.trim();console.log(process.env.EDITOR_RESULTS_DIR)
for(const[name,command]of gates){const result=run(['run',name,...(name==='snapshots-controls'?['--require','snapshots-proof']:[]),'--',...command]);console.log(name+': '+result.status);if(result.status!==0)console.error(result.stdout.slice(-3500)+result.stderr.slice(-3500))}
const result=run(['finish']);console.log('finish: '+result.status);process.exitCode=result.status
