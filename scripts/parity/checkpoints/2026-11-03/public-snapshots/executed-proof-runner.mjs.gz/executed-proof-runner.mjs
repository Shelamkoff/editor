import assert from 'node:assert/strict'
import { execFileSync,spawnSync } from 'node:child_process'
import { readFileSync,writeFileSync } from 'node:fs'
import { join } from 'node:path'
const directory=process.env.EDITOR_RESULTS_DIR,root='scripts/parity/checkpoints/2026-11-03/public-snapshots',env={...process.env};delete env.EDITOR_PUBLIC_SNAPSHOTS_FILTER
const raw=join(directory,'public-snapshots-full.json'),result=spawnSync(process.execPath,['scripts/parity/public-snapshots.mjs'],{env,encoding:'utf8',windowsHide:true,maxBuffer:32*1024*1024})
assert.equal(result.error,undefined);writeFileSync(raw,result.stdout);writeFileSync(join(directory,'public-snapshots-full.stderr'),result.stderr)
writeFileSync(join(directory,'public-snapshots-process.json'),JSON.stringify({exitCode:result.status,signal:result.signal,expectedExitCode:1,reason:'Two historical baseline metadata failures retain raw exit 1; the current 26-case contract and independent model pass separately.'},null,2))
assert.equal(result.status,1);assert.equal(result.stderr,'')
const source=execFileSync('git',['rev-parse','HEAD']).toString().trim()
const review=spawnSync(process.env.EDITOR_PYTHON_PATH,[join(root,'review.py'),'--raw',raw,'--candidate',source,'--browser',join(directory,'browser.log'),'--node',join(directory,'node.log'),'--output',join(directory,'public-snapshots-review.json')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024})
assert.equal(review.error,undefined);assert.equal(review.status,0,review.stderr)
console.log(JSON.stringify({rawComparisonExit:result.status,review:JSON.parse(readFileSync(join(directory,'public-snapshots-review.json')))}))
