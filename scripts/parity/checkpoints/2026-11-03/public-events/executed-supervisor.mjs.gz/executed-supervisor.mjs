import { spawnSync } from 'node:child_process'
const run=args=>spawnSync(process.execPath,['scripts/verification-results.mjs',...args],{encoding:'utf8',windowsHide:true,maxBuffer:96*1024*1024})
const npm=script=>['cmd.exe','/d','/s','/c','npm run '+script]
const gates=[['types',npm('typecheck')],['browser',[process.execPath,'tests/browser/run.mjs']],
 ['events-proof',[process.execPath,'test-results/audit-closeout-2026-11-01/run-public-events-proof.mjs']],
 ['events-controls',[process.execPath,'test-results/audit-closeout-2026-11-01/run-public-events-controls.mjs']],['docs',npm('test:docs')]]
for(const name of ['EDITOR_BROWSER_PAGE','EDITOR_BROWSER_ROOT','EDITOR_NATIVE_PAGE','EDITOR_NATIVE_FILTER','EDITOR_PUBLIC_EVENTS_FILTER'])delete process.env[name]
const initialized=run(['init',...gates.map(([name])=>name)])
if(initialized.status!==0)throw Error(initialized.stdout+initialized.stderr)
process.env.EDITOR_RESULTS_DIR=initialized.stdout.trim();console.log(process.env.EDITOR_RESULTS_DIR)
for(const[name,command]of gates){const result=run(['run',name,...(name==='events-controls'?['--require','events-proof']:[]),'--',...command]);console.log(name+': '+result.status);if(result.status!==0)console.error(result.stdout.slice(-2500)+result.stderr.slice(-2500))}
const result=run(['finish']);console.log('finish: '+result.status);process.exitCode=result.status
