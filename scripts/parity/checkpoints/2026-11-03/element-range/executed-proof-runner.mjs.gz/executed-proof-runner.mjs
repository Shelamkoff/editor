import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
const directory = process.env.EDITOR_RESULTS_DIR, root = 'scripts/parity/checkpoints/2026-11-03/element-range'
const raw = join(directory, 'element-range-full.json'), env = { ...process.env }; delete env.EDITOR_ELEMENT_RANGE_FILTER
const result = spawnSync(process.execPath, ['scripts/parity/element-range.mjs'], { env, encoding: 'utf8', windowsHide: true, maxBuffer: 32 * 1024 * 1024 })
assert.equal(result.error, undefined); writeFileSync(raw, result.stdout); writeFileSync(join(directory, 'element-range-full.stderr'), result.stderr)
writeFileSync(join(directory, 'element-range-process.json'), JSON.stringify({ exitCode: result.status, signal: result.signal, expectedExitCode: 1, reason: 'Historical failed observations retain raw exit 1; current actions and manual contract review pass separately.' }, null, 2))
assert.equal(result.status, 1); assert.equal(result.stderr, '')
const candidate = execFileSync('git', ['rev-parse', 'HEAD']).toString().trim()
const review = spawnSync(process.env.EDITOR_PYTHON_PATH, [join(root, 'review.py'), '--raw', raw, '--candidate', candidate, '--native', join(directory, 'native.log'), '--output', join(directory, 'element-range-review.json')], { encoding: 'utf8', windowsHide: true, maxBuffer: 8 * 1024 * 1024 })
assert.equal(review.error, undefined); assert.equal(review.status, 0, review.stderr)
console.log(JSON.stringify({ rawComparisonExit: result.status, review: JSON.parse(readFileSync(join(directory, 'element-range-review.json'))) }))
