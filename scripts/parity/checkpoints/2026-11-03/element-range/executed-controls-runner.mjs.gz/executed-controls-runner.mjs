import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { join } from 'node:path'
const directory = process.env.EDITOR_RESULTS_DIR, source = execFileSync('git', ['rev-parse', 'HEAD']).toString().trim()
const result = spawnSync(process.execPath, ['scripts/parity/checkpoints/2026-11-03/element-range/controls.mjs', join(directory, 'element-range-full.json'), source, join(directory, 'native.log'), join(directory, 'element-range-controls')], { encoding: 'utf8', windowsHide: true, maxBuffer: 8 * 1024 * 1024 })
assert.equal(result.error, undefined); assert.equal(result.status, 0, result.stdout + result.stderr); console.log(result.stdout)
