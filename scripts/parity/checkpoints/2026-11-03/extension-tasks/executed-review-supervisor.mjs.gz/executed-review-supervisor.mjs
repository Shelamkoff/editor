import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {readFileSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
const temp='test-results/audit-closeout-2026-11-01/',first=readFileSync(temp+'extension-tasks-run-path.txt','utf8').trim(),prior=JSON.parse(readFileSync(join(first,'manifest.json'))),env={...process.env,PYTHONDONTWRITEBYTECODE:'1'},directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init','model','controls'],{env,encoding:'utf8'}).trim();env.EDITOR_RESULTS_DIR=directory;writeFileSync(temp+'extension-tasks-review-run-path.txt',directory)
const root='scripts/parity/checkpoints/2026-11-03/extension-tasks',task=join(first,'extension-tasks-full.json'),history=join(first,'continuation-authority-full.json'),browser=join(first,'browser.log'),source=prior.source.head
const plans=[['model',[env.EDITOR_PYTHON_PATH,root+'/review.py','--raw',task,'--continuation',history,'--browser',browser,'--candidate',source,'--output',join(directory,'extension-tasks-review.json')]],['controls',[process.execPath,root+'/controls.mjs',task,history,browser,source,join(directory,'extension-tasks-controls')],'model']]
for(const[name,command,require]of plans){const r=spawnSync(process.execPath,['scripts/verification-results.mjs','run',name,...(require?['--require',require]:[]),'--',...command],{env,stdio:'inherit',windowsHide:true});assert.equal(r.error,undefined);console.log(JSON.stringify({gate:name,exitCode:r.status}))}
const r=spawnSync(process.execPath,['scripts/verification-results.mjs','finish'],{env,stdio:'inherit',windowsHide:true});assert.equal(r.status,0)
