import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {writeFileSync} from 'node:fs'
const root='test-results/audit-closeout-2026-11-01',env={...process.env,PYTHONDONTWRITEBYTECODE:'1'},directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init','types','browser','proof','controls','docs'],{env,encoding:'utf8'}).trim();env.EDITOR_RESULTS_DIR=directory;writeFileSync(root+'/extension-tasks-run-path.txt',directory)
const plans=[['types',['cmd.exe','/d','/s','/c','npm run test:types']],['browser',[process.execPath,'tests/browser/run.mjs']],['proof',[process.execPath,root+'/run-extension-tasks-proof.mjs'],'browser'],['controls',[process.execPath,root+'/run-extension-tasks-controls.mjs'],'proof'],['docs',['cmd.exe','/d','/s','/c','npm run test:docs']]]
for(const[name,command,require]of plans){const r=spawnSync(process.execPath,['scripts/verification-results.mjs','run',name,...(require?['--require',require]:[]),'--',...command],{env,stdio:'inherit',windowsHide:true});console.log(JSON.stringify({gate:name,exitCode:r.status}));assert.equal(r.error,undefined)}
const r=spawnSync(process.execPath,['scripts/verification-results.mjs','finish'],{env,stdio:'inherit',windowsHide:true});assert.equal(r.status,0)
