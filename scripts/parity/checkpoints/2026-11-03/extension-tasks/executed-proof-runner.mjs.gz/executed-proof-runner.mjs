import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {writeFileSync,readFileSync} from 'node:fs'
import {join} from 'node:path'
const directory=process.env.EDITOR_RESULTS_DIR,root='scripts/parity/checkpoints/2026-11-03/extension-tasks',env={...process.env};delete env.EDITOR_EXTENSION_TASKS_FILTER
for(const name of ['extension-tasks','continuation-authority']){
 const r=spawnSync(process.execPath,['scripts/parity/'+name+'.mjs'],{env,encoding:'utf8',windowsHide:true,maxBuffer:48*1024*1024});assert.equal(r.error,undefined);writeFileSync(join(directory,name+'-full.json'),r.stdout);writeFileSync(join(directory,name+'-full.stderr'),r.stderr);writeFileSync(join(directory,name+'-process.json'),JSON.stringify({exitCode:r.status,signal:r.signal,expectedExitCode:1,reason:'Preserved historical defects; current source must pass independently.'},null,2));assert.equal(r.status,1);assert.equal(r.stderr,'')
}
const source=execFileSync('git',['rev-parse','HEAD']).toString().trim(),r=spawnSync(process.env.EDITOR_PYTHON_PATH,[join(root,'review.py'),'--raw',join(directory,'extension-tasks-full.json'),'--continuation',join(directory,'continuation-authority-full.json'),'--browser',join(directory,'browser.log'),'--candidate',source,'--output',join(directory,'extension-tasks-review.json')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});assert.equal(r.error,undefined);assert.equal(r.status,0,r.stderr);console.log(readFileSync(join(directory,'extension-tasks-review.json'),'utf8'))
