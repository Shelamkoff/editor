import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { join } from 'node:path'
const primary = 'test-results/run-rwO0s2', source = '247b4a42583b0d2179c52da1fd9960ad28e7ca1c'
const result = spawnSync(process.execPath, ['scripts/parity/checkpoints/2026-11-03/alignment/controls.mjs', join(primary, 'alignment-full.json'), source, primary,
  join(process.env.EDITOR_RESULTS_DIR, 'alignment-controls')], { encoding: 'utf8', windowsHide: true, maxBuffer: 8 * 1024 * 1024 })
assert.equal(result.error, undefined); assert.equal(result.status, 0, result.stdout + result.stderr)
console.log(result.stdout)
