import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
const directory = process.env.EDITOR_RESULTS_DIR
assert.ok(directory && process.env.EDITOR_PYTHON_PATH)
const raw = join(directory, 'alignment-full.json')
const env = { ...process.env }; delete env.EDITOR_ALIGNMENT_FILTER
const result = spawnSync(process.execPath, ['scripts/parity/alignment.mjs'], { encoding: 'utf8', windowsHide: true, env, maxBuffer: 128 * 1024 * 1024 })
assert.equal(result.error, undefined)
writeFileSync(raw, result.stdout); writeFileSync(join(directory, 'alignment-full.stderr'), result.stderr)
writeFileSync(join(directory, 'alignment-process.json'), JSON.stringify({ exitCode: result.status, signal: result.signal, expectedExitCode: 1,
  reason: 'Historical failed observations and incomplete actions keep raw exit 1; candidate and independent contract model are evaluated separately.' }, null, 2))
assert.equal(result.status, 1); assert.equal(result.stderr, '')
const candidate = execFileSync('git', ['rev-parse', 'HEAD']).toString().trim()
const args = ['scripts/parity/checkpoints/2026-11-03/alignment/review.py', '--raw', raw, '--candidate', candidate,
  '--browser', join(directory, 'browser-all.log'), '--output', join(directory, 'alignment-review.json')]
for (const value of ['left', 'center', 'right', 'justify']) args.push('--native-' + value, join(directory, 'native-' + value + '.log'))
const review = spawnSync(process.env.EDITOR_PYTHON_PATH, args, { encoding: 'utf8', windowsHide: true, maxBuffer: 8 * 1024 * 1024 })
assert.equal(review.error, undefined); assert.equal(review.status, 0, review.stderr)
console.log(JSON.stringify({ rawComparisonExit: result.status, review: JSON.parse(readFileSync(join(directory, 'alignment-review.json'))) }))
