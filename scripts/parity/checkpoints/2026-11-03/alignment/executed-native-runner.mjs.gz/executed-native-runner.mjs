import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
const value = process.argv[2]
assert.ok(['left', 'center', 'right', 'justify'].includes(value))
const result = spawnSync(process.execPath, ['tests/browser/physical-history.mjs'], { env: { ...process.env, EDITOR_NATIVE_PAGE: 'native-alignment-' + value + '.html' }, windowsHide: true, stdio: 'inherit' })
assert.equal(result.error, undefined); process.exitCode = result.status
