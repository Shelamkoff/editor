import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'
const directory = process.env.EDITOR_RESULTS_DIR, primary = 'test-results/run-rwO0s2', source = '247b4a42583b0d2179c52da1fd9960ad28e7ca1c'
const reviewSource = execFileSync('git', ['rev-parse', 'HEAD']).toString().trim()
const args = ['scripts/parity/checkpoints/2026-11-03/alignment/review.py', '--raw', join(primary, 'alignment-full.json'),
  '--candidate', source, '--review-source', reviewSource, '--browser', join(primary, 'browser-all.log'), '--output', join(directory, 'alignment-review.json')]
for (const value of ['left', 'center', 'right', 'justify']) args.push('--native-' + value, join(primary, 'native-' + value + '.log'))
const result = spawnSync(process.env.EDITOR_PYTHON_PATH, args, { encoding: 'utf8', windowsHide: true, maxBuffer: 8 * 1024 * 1024 })
assert.equal(result.error, undefined); assert.equal(result.status, 0, result.stderr)
console.log(JSON.stringify(JSON.parse(readFileSync(join(directory, 'alignment-review.json')))))
