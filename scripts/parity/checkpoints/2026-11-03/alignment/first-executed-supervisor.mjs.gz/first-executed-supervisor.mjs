import { spawnSync } from 'node:child_process'
const run = args => spawnSync(process.execPath, ['scripts/verification-results.mjs', ...args], { encoding: 'utf8', windowsHide: true, maxBuffer: 128 * 1024 * 1024 })
const gates = [
  ['types', ['cmd.exe', '/d', '/s', '/c', 'npm run typecheck']],
  ['browser-all', [process.execPath, 'tests/browser/run.mjs']],
  ...['left', 'center', 'right', 'justify'].map(value => ['native-' + value, [process.execPath, 'test-results/audit-closeout-2026-11-01/run-alignment-native.mjs', value]]),
  ['alignment-proof', [process.execPath, 'test-results/audit-closeout-2026-11-01/run-alignment-proof.mjs']],
  ['alignment-controls', [process.execPath, 'test-results/audit-closeout-2026-11-01/run-alignment-controls.mjs']],
  ['docs', ['cmd.exe', '/d', '/s', '/c', 'npm run test:docs']],
]
for (const name of ['EDITOR_BROWSER_PAGE', 'EDITOR_BROWSER_ROOT', 'EDITOR_NATIVE_PAGE', 'EDITOR_NATIVE_FILTER', 'EDITOR_ALIGNMENT_FILTER']) delete process.env[name]
const initialized = run(['init', ...gates.map(([name]) => name)])
if (initialized.status !== 0) throw Error(initialized.stdout + initialized.stderr)
process.env.EDITOR_RESULTS_DIR = initialized.stdout.trim(); console.log(process.env.EDITOR_RESULTS_DIR)
for (const [name, command] of gates) {
  const result = run(['run', name, ...(name === 'alignment-controls' ? ['--require', 'alignment-proof'] : []), '--', ...command])
  console.log(name + ': ' + result.status)
  if (result.status !== 0) console.error(result.stdout.slice(-4000) + result.stderr.slice(-4000))
}
const result = run(['finish']); console.log('finish: ' + result.status)
if (result.status !== 0) console.error(result.stdout.slice(-4000) + result.stderr.slice(-4000))
process.exitCode = result.status
