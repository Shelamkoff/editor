#!/usr/bin/env python3
"""Script-tool manual character/mark model extended from the frozen common-tool oracle.

This is the author's verification script, not an independent peer review."""
import argparse
import collections
import hashlib
import gzip
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

BASE = 'd67229c08f5fae7101cb2a252f2d56385224da08'
INTEGRATION = '13b79cc62ceb29fe7a73b5d5dca9d3cde1c37b9e'
INTEGRATION_MANIFEST_SHA256 = '89b6477f25f5479e7e59a962f4427fad2894a4fec21e0dd82e968610dc48da2b'
V1 = '5e5c7f8d2d9e9a6cf2f95cfb7fd67aba227fa340'
SPEC = 'e981ff308000c1d92d7e820df95113c1e19bcee8'
STYLE = 'style(color:rgb(128, 0, 0))'
LINK = 'a[["href","/kept"],["rel","noopener noreferrer"]]'
COLOR = {'value': '#aBcDef'}
MENTION = {'id': 'ada', 'name': 'Ada'}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def exact(left, right):
    return json.dumps(left, ensure_ascii=False, separators=(',', ':'), sort_keys=True) == json.dumps(right, ensure_ascii=False, separators=(',', ':'), sort_keys=True)


def cases():
    result = []
    for tool in ['code', 'marker']:
        for variant in ['apply', 'mixed', 'nested']:
            for shape in ['single'] if variant == 'nested' else ['single', 'cross', 'fields']:
                for boundary in ['Text', 'Element']:
                    for backward in [False, True]:
                        result.append(dict(id='/'.join([tool, variant, shape, boundary, 'backward' if backward else 'forward']), tool=tool, variant=variant, shape=shape, boundary=boundary, backward=backward))
        for backward in [False, True]:
            result.append(dict(id='/'.join([tool, 'noop', 'atomic', 'backward' if backward else 'forward']), tool=tool, noop='atomic', shape='single', boundary='Element', backward=backward))
        for lifetime in ['read-only', 'destroy']:
            result.append(dict(id='/'.join([tool, 'lifetime', lifetime]), tool=tool, lifetime=lifetime))
    return result


def append(result, text, marks=(), kind='text'):
    if not text:
        return
    marks = sorted(set(marks))
    if kind == 'text' and result and result[-1]['kind'] == kind and result[-1]['marks'] == marks:
        result[-1]['text'] += text
    else:
        result.append(dict(kind=kind, text=text, marks=marks))


def authored(spec, changed=False, typed=False):
    """Manual per-character target marks; no fixture HTML or expected values."""
    target = spec['tag']
    edge = 'i'
    middle = 's'
    lead, end = [], []
    if 'lifetime' in spec:
        append(lead, 'Abc', [edge] + ([] if changed else [target]))
        append(lead, ' ')
        append(lead, '{{swatch}}', kind='widget')
        append(lead, ' ')
        append(lead, '{{mention}}', kind='widget')
        append(lead, ' Tail')
        return [lead]
    append(lead, ('X' if typed else '') + 'un')
    if 'noop' in spec:
        append(lead, '{{swatch}}', kind='widget')
        append(lead, ' ')
        append(lead, '{{mention}}', kind='widget')
        append(lead, ' rest')
        return [lead]
    whole = spec['boundary'] == 'Element'
    if spec['variant'] == 'nested':
        for index, char in enumerate('Alpha'):
            selected_character = whole or index == 2
            append(lead, char, [edge] + ([target] if not changed or not selected_character else []))
        append(lead, ' ')
        append(lead, '{{swatch}}', kind='widget')
        append(lead, ' ')
        append(lead, '{{mention}}', kind='widget')
        append(lead, ' rest')
        return [lead]
    apply = spec['variant'] == 'apply'
    for index, char in enumerate('Alpha'):
        selected_character = whole or index >= 2
        has_target = (changed and selected_character) if apply else not (changed and selected_character)
        append(lead, char, [edge] + ([target] if has_target else []))
    new_target = [target] if changed and apply else []
    old_target = [target] if not changed and not apply else []
    append(lead, ' Plain ', new_target)
    append(lead, 'MiXeD & tail', [middle, STYLE] + new_target + old_target)
    append(lead, '\n', kind='break')
    append(lead, 'Link', [edge, LINK] + new_target + old_target)
    append(lead, ' ', new_target)
    append(lead, '{{swatch}}', kind='widget')
    append(lead, ' ', new_target)
    append(lead, '{{mention}}', kind='widget')
    if spec['shape'] == 'single':
        append(lead, ' ', new_target)
    for index, char in enumerate('Bravo'):
        selected_character = whole or index < 3
        has_target = (changed and selected_character) if apply else not (changed and selected_character)
        append(end, char, [edge] + ([target] if has_target else []))
    append(end, ' rest')
    if spec['shape'] == 'single':
        for token in end:
            append(lead, token['text'], token['marks'], token['kind'])
        return [lead]
    return [lead, end]


def logical_length(tokens):
    return sum(1 if token['kind'] != 'text' else len(token['text'].encode('utf-16-le')) // 2 for token in tokens)


def selected(spec, changed=False):
    if 'lifetime' in spec:
        return dict(anchor=3, focus=0, collapsed=False)
    if spec.get('noop'):
        first = dict(field='a', offset=2)
        last = dict(field='a', offset=3)
    else:
        names = ['quote.text', 'quote.caption'] if spec['shape'] == 'fields' else ['a', 'b']
        whole = spec['boundary'] == 'Element'
        first = dict(field=names[0], offset=3 if whole else 5)
        last_offset = (8 if whole else 6) if spec['variant'] == 'nested' else logical_length(authored(spec, changed, typed=True)[-1]) - 5 - (0 if whole else 2)
        last = dict(field=names[0 if spec['shape'] == 'single' else 1], offset=last_offset)
    return dict(anchor=last if spec['backward'] else first, focus=first if spec['backward'] else last, collapsed=False)


class Meaning(HTMLParser):
    """Independent parser of recorded canonical strings, without browser code."""
    def __init__(self, value):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.result = []
        self.feed(value)

    def marks(self):
        return [mark for _, value in self.stack for mark in value]

    def handle_starttag(self, tag, attrs):
        if tag == 'br':
            append(self.result, '\n', self.marks(), 'break')
            return
        attrs = dict(attrs)
        if tag == 'span':
            values = []
            for item in attrs.get('style', '').split(';'):
                if ':' not in item:
                    continue
                prop, value = [part.strip() for part in item.split(':', 1)]
                value = {'#800000': 'rgb(128, 0, 0)', '#ffff00': 'rgb(255, 255, 0)'}.get(value, value)
                values.append((prop, value))
            marks = ['style(' + ';'.join(key + ':' + value for key, value in sorted(values)) + ')'] if values else []
        elif tag == 'a':
            marks = ['a' + json.dumps(sorted([list(value) for value in attrs.items()]), ensure_ascii=False, separators=(',', ':'))]
        else:
            marks = [{'strong': 'b', 'em': 'i', 'strike': 's', 'del': 's'}.get(tag, tag)]
        self.stack.append((tag, marks))

    def handle_endtag(self, tag):
        assert self.stack and self.stack[-1][0] == tag, (tag, self.stack)
        self.stack.pop()

    def handle_data(self, data):
        for part in re.split(r'(\{\{(?:swatch|mention)\}\})', data):
            append(self.result, part, self.marks(), 'widget' if part in ['{{swatch}}', '{{mention}}'] else 'text')


def cases():
    result = []
    for mode in ['sup', 'sub', 'none']:
        for tag in ['sup', 'sub'] if mode == 'none' else [mode]:
            for variant in ['apply', 'mixed', 'nested']:
                if mode == 'none' and variant == 'apply': continue
                for shape in ['single'] if variant == 'nested' else ['single', 'cross', 'fields']:
                    for boundary in ['Text', 'Element']:
                        for backward in [False, True]:
                            result.append(dict(id='/'.join(['script', mode, tag, variant, shape, boundary, 'backward' if backward else 'forward']),
                                               tool='script', variant=variant, shape=shape, boundary=boundary, backward=backward, mode=mode, tag=tag))
            for backward in [False, True]:
                result.append(dict(id='/'.join(['script', mode, tag, 'noop', 'atomic', 'backward' if backward else 'forward']),
                                   tool='script', noop='atomic', shape='single', boundary='Element', backward=backward, mode=mode, tag=tag))
            for lifetime in ['read-only', 'destroy']:
                result.append(dict(id='/'.join(['script', mode, tag, 'lifetime', lifetime]), tool='script', lifetime=lifetime, mode=mode, tag=tag))
    assert len(result) == 104
    for tag in ['sup', 'sub']:
        for shape in ['single', 'cross', 'fields']:
            for boundary in ['Text', 'Element']:
                for backward in [False, True]:
                    result.append(dict(id='/'.join(['script', 'host', tag, 'apply', shape, boundary, 'backward' if backward else 'forward']),
                                       tool='script', variant='apply', shape=shape, boundary=boundary, backward=backward, mode=tag, tag=tag, hostTag=tag))
    assert len(result) == 128
    return result

def verify_candidate(case):
    spec = case['spec']
    semantic_checks = 0
    assert case['error'] is None and case['diagnostics'] == case['unsupported'] == []
    assert case['completedPhases'] == case['planned']
    count = 39 if spec.get('lifetime') == 'destroy' else 37 if 'lifetime' in spec else 45 if 'noop' in spec else 51
    if 'hostTag' in spec: count += 1
    assert len(case['observations']) == count, (case['id'], len(case['observations']), count)
    observations = {(item['phase'], item['property']): item for item in case['observations']}
    assert len(observations) == count
    button_phase = 'live-action' if 'lifetime' in spec else 'apply'
    for property in ['auxiliaryPanelFocus', 'trustedPanelAction', 'acceptedPanelClosed']:
        assert observations[(button_phase, property)]['actual'] is True and observations[(button_phase, property)]['expected'] is True
        semantic_checks += 1
    for (phase, property), item in observations.items():
        assert item['status'] == 'PASS' and exact(item['actual'], item['expected']), (case['id'], phase, property)
        expected = None
        if property == 'fixedInputMeaning':
            value = authored(spec); expected = value[0] if 'lifetime' in spec else value
        elif property == 'independentPrecedingEdit': expected = authored(spec, typed=True)
        elif property == 'intendedTextAndMarks': expected = authored(spec, changed=not spec.get('noop'), typed=not spec.get('noop'))
        elif property == 'liveCapabilityStillWorks': expected = authored(spec, changed=True)[0]
        elif property in ['selection', 'exactInitialEndpoints']:
            expected = selected(spec, changed=phase in ['apply', 'redo-action', 'live-action', 'redo'])
        elif property == 'visibleTextAndMarks':
            changed = phase in ['apply', 'redo-action', 'live-action', 'redo'] and not spec.get('noop')
            typed = phase in ['input', 'undo-action', 'redo-input', 'redo-action', 'apply'] and 'lifetime' not in spec
            if spec.get('noop'): typed = phase in ['input', 'redo-input']
            value = authored(spec, changed=changed, typed=typed); expected = value[0] if 'lifetime' in spec else value
        elif property == 'visibleWidgets':
            widgets = [dict(id='swatch', type='color', value='#aBcDef', label='#aBcDef', dot='rgb(171, 205, 239)', contenteditable='false'),
                       dict(id='mention', type='mention', value='ada', label='@Ada', dot=None)]
            expected = widgets if 'lifetime' in spec else [widgets] + ([[]] if spec.get('shape') in ['cross', 'fields'] else [])
        elif property in ['liveWidgetIdentity', 'trustedNamedButton', 'trustedLiveButton', 'trustedInsert']: expected = True
        elif property in ['producerCalls', 'currentProducerOnce']: expected = 1
        elif property in ['oldProducerSilent', 'currentProducerSilent', 'retiredProducerStillSilent']: expected = 0
        elif property == 'retainedButtonCannotChangeHistory': expected = [False, False]
        elif property == 'noCompletedAction': expected = []
        elif property == 'applicationHostBoundary': expected = dict(same=True, tag=spec['hostTag'], marker='outside')
        elif property == 'history':
            if 'lifetime' in spec: expected = dict(load=[False, False], undo=[False, True], redo=[True, False])[phase]
            elif 'noop' in spec:
                undo, redo = dict(load=(False, False), **{'prepare-redo': (False, True), 'apply': (False, True), 'redo-input': (True, False), 'undo-input': (False, True)})[phase]
                expected = dict(canUndo=undo, canRedo=redo)
            else:
                undo, redo = dict(load=(False, False), apply=(True, False), **{'undo-action': (True, True), 'undo-input': (False, True), 'redo-input': (True, True), 'redo-action': (True, False)})[phase]
                expected = dict(canUndo=undo, canRedo=redo)
        if expected is not None:
            assert exact(item['actual'], expected) and exact(item['expected'], expected), (case['id'], phase, property, item['actual'], expected)
            semantic_checks += 1
        if property in ['exactCanonicalDocument', 'canonicalNoop', 'originalRedoPreserved', 'onlyOriginalEditWasUndoable', 'retainedButtonCannotAuthor']:
            states = item['actual']
            typed = 'lifetime' not in spec and phase not in ['prepare-redo', 'undo-input', 'apply']
            changed = phase in ['redo-action', 'redo'] and not spec.get('noop')
            strings = [states[0]['data']['text'], states[0]['data']['caption']] if spec.get('shape') == 'fields' else [block['data']['text'] for block in states]
            assert [Meaning(value).result for value in strings] == authored(spec, changed=changed, typed=typed)
            assert [block['id'] for block in states] == (['same-id'] if 'lifetime' in spec else ['a', 'b'] if spec.get('shape') == 'cross' else ['a'])
            assert all(block['dataVersion'] == (1 if spec.get('shape') == 'fields' else 2) for block in states)
            assert states[0]['inline'] == dict(swatch=dict(type='color', dataVersion=1, data=COLOR), mention=dict(type='mention', dataVersion=1, data=MENTION))
            assert all(not block.get('inline') for block in states[1:])
            assert [block['type'] for block in states] == (['quote'] if spec.get('shape') == 'fields' else ['paragraph'] * len(states))
            semantic_checks += 1
    native = dict(action='commit', origin='native-input', name='native-input')
    action = dict(action='commit', origin='user', name='inline.script')
    undo_tool = dict(action='undo', origin='history', name='inline.script')
    redo_tool = dict(action='redo', origin='history', name='inline.script')
    undo_native = dict(action='undo', origin='history', name='native-input')
    redo_native = dict(action='redo', origin='history', name='native-input')
    expected = [action, undo_tool, redo_tool] if 'lifetime' in spec else [native, undo_native, redo_native, undo_native] if 'noop' in spec else [native, action, undo_tool, undo_native, redo_native, redo_tool]
    assert exact(case['transactions'], expected), (case['id'], case['transactions'], expected)
    trusted = [] if 'lifetime' in spec else [dict(type='input', inputType='insertText', trusted=True)]
    trusted += [dict(type='keydown', key='z', trusted=True)] * (2 if 'lifetime' in spec else 3 if 'noop' in spec else 4)
    assert exact(case['trusted'], trusted)
    return semantic_checks + 2

def main():
    parser = argparse.ArgumentParser(); parser.add_argument('raw', type=Path); opts = parser.parse_args()
    raw = json.loads(opts.raw.read_bytes())
    specs = [spec for spec in cases() if not raw['filter'] or raw['filter'] in spec['id']]
    assert specs
    summaries = []
    for row in raw['results']:
        assert row['pageErrors'] == row['inputErrors'] == []
        assert [item['spec'] for item in row['cases']] == specs
        failures = []
        for case in row['cases']:
            for observation in case['observations']:
                status = 'PASS' if exact(observation['actual'], observation['expected']) else 'FAIL'
                assert observation['status'] == status
                if status == 'FAIL': failures.append([case['id'], observation['phase'], observation['property']])
            if row['source'] == 'candidate': verify_candidate(case)
        summaries.append(dict(source=row['source'], cases=len(row['cases']), observations=sum(len(case['observations']) for case in row['cases']),
                              incomplete=sum(case['error'] is not None for case in row['cases']), failedObservations=len(failures), failuresByProperty=dict(collections.Counter(item[2] for item in failures))))
    print(json.dumps(dict(status='PASS', scope='Exploratory author verification by manual character/mark model, not immutable acceptance.', summaries=summaries)))

if __name__ == '__main__': main()
