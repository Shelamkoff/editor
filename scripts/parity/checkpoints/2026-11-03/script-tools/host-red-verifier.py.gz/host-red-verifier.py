from pathlib import Path
import gzip
import hashlib
import json
import runpy
import subprocess

root = Path('test-results/audit-closeout-2026-11-01')
source = '369a52be147390398da02ec7f0753ea21593b539'
raw_bytes = (root / 'script-tools-369a52be-host-red.json').read_bytes(); raw = json.loads(raw_bytes)
assert raw['headBefore'] == raw['headAfter'] == source and raw['group'] == 'script' and raw['filter'] == 'script/host/'
assert raw['candidatePass'] is False and raw['serverErrors'] == []
assert (root / 'script-tools-369a52be-host-red.stderr').read_bytes() == b''
assert subprocess.check_output(['git', 'diff', '--name-only', 'HEAD']) == b''
model = runpy.run_path(str(root / 'review-script-tools-probe.py'))
batch = runpy.run_path('scripts/parity/checkpoints/2026-11-03/presentation-authority/review.py')['git_blobs']
queries = [source + ':' + path for path in ['scripts/parity/script-tools.mjs', 'tests/browser/basic-mark-tools-parity-fixture.js']]
queries += [entry['sha'] + ':' + path for entry in raw['sources'] for path in entry['loaded']]
blobs = batch(queries); digest = lambda value: hashlib.sha256(value).hexdigest()
assert digest(blobs[source + ':scripts/parity/script-tools.mjs']) == raw['runnerSha256']
assert digest(blobs[source + ':tests/browser/basic-mark-tools-parity-fixture.js']) == raw['fixtureSha256']
for entry in raw['sources']:
    for path, expected in entry['loaded'].items(): assert digest(blobs[entry['sha'] + ':' + path]) == expected
candidate = raw['results'][2]
assert [case['spec'] for case in candidate['cases']] == [spec for spec in model['cases']() if spec['id'].startswith('script/host/')]
assert len(candidate['cases']) == 24
for case in candidate['cases']:
    assert case['error'] is None and case['completedPhases'] == case['planned'] and case['unsupported'] == case['diagnostics'] == []
    items = {(item['phase'], item['property']): item for item in case['observations']}
    intended = items[('apply', 'intendedTextAndMarks')]
    assert intended['status'] == 'FAIL'
    assert model['exact'](intended['expected'], model['authored'](case['spec'], changed=True, typed=True))
    assert model['exact'](intended['actual'], model['authored'](case['spec'], changed=False, typed=True))
    boundary = items[('apply', 'applicationHostBoundary')]
    assert model['exact'](boundary['actual'], dict(same=True, tag=case['spec']['hostTag'], marker='outside'))
    assert items[('apply', 'auxiliaryPanelFocus')]['actual'] is True
    assert items[('apply', 'trustedPanelAction')]['actual'] is True
    for item in case['observations']:
        if item['property'] in ['fixedInputMeaning', 'fixedWidgetPayload', 'independentPrecedingEdit', 'exactInitialEndpoints']:
            assert item['status'] == 'PASS'
report = dict(status='CONFIRMED_RED', candidate=source, rawSha256=digest(raw_bytes), cases=24,
              candidateObservations=sum(len(case['observations']) for case in candidate['cases']), failedCandidateCases=24,
              failedCandidateObservations=sum(item['status'] == 'FAIL' for case in candidate['cases'] for item in case['observations']),
              productionModulesVerified=sum(len(entry['loaded']) for entry in raw['sources']),
              note='Application-owned sup/sub is incorrectly treated as authored mode: all trusted matching actions leave accepted own formatting unchanged. Positive input/range/focus/application-boundary controls pass. No production method is replaced.')
out = Path('scripts/parity/checkpoints/2026-11-03/script-tools'); artifacts = {}
for name, value in [('host-red.json.gz', raw_bytes), ('host-red.stderr.gz', b''),
                    ('host-red-review.json.gz', (json.dumps(report, indent=2) + '\n').encode()),
                    ('host-red-verifier.py.gz', Path(__file__).read_bytes()),
                    ('host-red-model.py.gz', (root / 'review-script-tools-probe.py').read_bytes()),
                    ('host-red-provenance.py.gz', Path('scripts/parity/checkpoints/2026-11-03/presentation-authority/review.py').read_bytes())]:
    stored = gzip.compress(value, compresslevel=9, mtime=0); (out / name).write_bytes(stored)
    artifacts[name] = dict(sha256=digest(stored), decodedSha256=digest(value))
(out / 'host-red-hashes.json').write_text(json.dumps(artifacts, indent=2) + '\n', encoding='utf8', newline='\n')
print(json.dumps(report))
