import { spawnSync } from 'node:child_process'
const runner='scripts/verification-results.mjs'
const run=args=>spawnSync(process.execPath,[runner,...args],{encoding:'utf8',windowsHide:true,maxBuffer:96*1024*1024})
const npm=script=>['cmd.exe','/d','/s','/c','npm run '+script]
const native=(name,page)=>[name,[process.execPath,'tests/browser/physical-history.mjs'],page]
const gates=[['build',npm('build')],['node',[process.execPath,'--test']],['types',npm('typecheck')],['browser',[process.execPath,'tests/browser/run.mjs']],
 native('native-html','native-html-content.html'),native('native-roundtrip','native-roundtrip-preservation.html'),native('native-media','native-plugin-media.html'),native('native-plugins','native-plugin-parity.html'),native('native-person','native-person-modes.html'),native('native-code-marker','native-code-marker.html'),
 native('native-tools','native-tools.html'),
 native('native-script-sup','native-script-tools-sup.html'),native('native-script-sub','native-script-tools-sub.html'),native('native-script-none','native-script-tools-none.html'),native('native-script-host','native-script-host.html'),
 native('native-optional','native-optional-inline-update.html'),native('native-presentation','native-presentation-recovery.html'),
 ['navigation',[process.execPath,'scripts/parity/html-content-navigation.mjs']],['deferred',[process.execPath,'scripts/parity/deferred-projection-loading.mjs']],['responsive',[process.execPath,'scripts/parity/html-responsive-content.mjs']],['layers',[process.execPath,'scripts/parity/html-native-layers.mjs','HEAD']],['resources',[process.execPath,'scripts/parity/html-resource-effects.mjs','HEAD']],['glyph',[process.execPath,'scripts/parity/inline-content-glyph.mjs']],['bundle',[process.execPath,'benchmarks/bundle-budget.mjs','--enforce']],['heap',[process.execPath,'tests/browser/heap-gate.mjs']],['docs',npm('test:docs')],['package',npm('test:package')],['site',npm('docs:check')]]
delete process.env.EDITOR_HTML_LAYER_KIND
delete process.env.EDITOR_RESOURCE_REF
for(const name of ['EDITOR_BROWSER_PAGE','EDITOR_BROWSER_ROOT','EDITOR_NATIVE_PAGE','EDITOR_NATIVE_FILTER','EDITOR_BASIC_TOOLS_FILTER','EDITOR_SCRIPT_TOOLS_FILTER','EDITOR_OPTIONAL_INLINE_GROUP','EDITOR_PRESENTATION_GROUP'])delete process.env[name]
const initialized=run(['init',...gates.map(([name])=>name)]);if(initialized.status!==0)throw Error(initialized.stdout+initialized.stderr)
process.env.EDITOR_RESULTS_DIR=initialized.stdout.trim();console.log(process.env.EDITOR_RESULTS_DIR)
for(const [name,command,page]of gates){if(page)process.env.EDITOR_NATIVE_PAGE=page;else delete process.env.EDITOR_NATIVE_PAGE;const result=run(['run',name,'--',...command]);console.log(name+': '+result.status);if(result.status!==0)console.error(result.stdout.slice(-3500)+result.stderr.slice(-3500))}
delete process.env.EDITOR_NATIVE_PAGE
const result=run(['finish']);console.log('finish: '+result.status);if(result.status!==0)console.error(result.stdout.slice(-3500)+result.stderr.slice(-3500));process.exitCode=result.status
