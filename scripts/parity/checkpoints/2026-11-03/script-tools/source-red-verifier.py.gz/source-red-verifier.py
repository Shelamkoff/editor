from pathlib import Path
import gzip
import hashlib
import json
import runpy
import subprocess

root = Path('test-results/audit-closeout-2026-11-01')
source = 'bf2ad7a52118bbff059d70c8c5841cebf038e2d7'
raw_path = root / 'script-tools-bf2ad7a5-red.json'
raw_bytes = raw_path.read_bytes(); raw = json.loads(raw_bytes)
assert raw['headBefore'] == raw['headAfter'] == source
assert raw['group'] == 'script' and raw['filter'] == 'script/sup/sup' and raw['candidatePass'] is False
assert raw['serverErrors'] == [] and (root / 'script-tools-bf2ad7a5-red.stderr').read_bytes() == b''
assert subprocess.check_output(['git', 'diff', '--name-only', 'HEAD']) == b''
model = runpy.run_path(str(root / 'review-script-tools-probe.py'))
batch = runpy.run_path('scripts/parity/checkpoints/2026-11-03/presentation-authority/review.py')['git_blobs']
queries = [source + ':' + path for path in ['scripts/parity/script-tools.mjs', 'tests/browser/basic-mark-tools-parity-fixture.js']]
queries += [entry['sha'] + ':' + path for entry in raw['sources'] for path in entry['loaded']]
blobs = batch(queries)
digest = lambda value: hashlib.sha256(value).hexdigest()
assert digest(blobs[source + ':scripts/parity/script-tools.mjs']) == raw['runnerSha256']
assert digest(blobs[source + ':tests/browser/basic-mark-tools-parity-fixture.js']) == raw['fixtureSha256']
for entry in raw['sources']:
    for path, expected in entry['loaded'].items(): assert digest(blobs[entry['sha'] + ':' + path]) == expected
specs = [spec for spec in model['cases']() if raw['filter'] in spec['id']]
candidate = raw['results'][2]
assert [case['spec'] for case in candidate['cases']] == specs and len(specs) == 32
failures = []
for case in candidate['cases']:
    assert case['error'] is None and case['planned'] == case['completedPhases'] and case['unsupported'] == case['diagnostics'] == []
    failed = [item for item in case['observations'] if item['status'] == 'FAIL']
    if not failed:
        model['verify_candidate'](case)
        continue
    assert case['spec']['variant'] == 'mixed' and case['spec']['boundary'] == 'Element'
    assert [(item['phase'], item['property']) for item in failed] == [
        ('apply', 'intendedTextAndMarks'), ('apply', 'visibleTextAndMarks'),
        ('redo-action', 'intendedTextAndMarks'), ('redo-action', 'visibleTextAndMarks')]
    for item in failed:
        expected = model['authored'](case['spec'], changed=True, typed=True)
        assert model['exact'](item['expected'], expected)
        assert not model['exact'](item['actual'], expected)
    failures.append(case['id'])
assert len(failures) == 6
report = dict(status='CONFIRMED_RED', candidate=source, rawSha256=digest(raw_bytes), cases=32,
              candidateObservations=sum(len(case['observations']) for case in candidate['cases']),
              completeCandidateCases=32, failedCandidateCases=failures, failedCandidateObservations=24,
              productionModulesVerified=sum(len(entry['loaded']) for entry in raw['sources']),
              note='Mixed Element-boundary Script chooses none from an outer wrapper and reapplies sup; the independent character model requires selected sup removal. Existing Text controls pass. No runtime/test mutation or historical relabelling.')
out = Path('scripts/parity/checkpoints/2026-11-03/script-tools')
artifacts = {}
for name, value in [('source-red.json.gz', raw_bytes), ('source-red.stderr.gz', b''),
                    ('source-red-review.json.gz', (json.dumps(report, indent=2) + '\n').encode()),
                    ('source-red-verifier.py.gz', Path(__file__).read_bytes())]:
    stored = gzip.compress(value, compresslevel=9, mtime=0); (out / name).write_bytes(stored)
    artifacts[name] = dict(sha256=digest(stored), decodedSha256=digest(value))
(out / 'source-red-hashes.json').write_text(json.dumps(artifacts, indent=2) + '\n', encoding='utf8', newline='\n')
print(json.dumps(report))
