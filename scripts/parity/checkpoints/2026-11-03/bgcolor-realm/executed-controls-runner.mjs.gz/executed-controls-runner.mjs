import assert from 'node:assert/strict'
import { execFileSync,spawnSync } from 'node:child_process'
import { join } from 'node:path'
const directory=process.env.EDITOR_RESULTS_DIR,candidate=execFileSync('git',['rev-parse','HEAD']).toString().trim()
const r=spawnSync(process.execPath,['scripts/parity/checkpoints/2026-11-03/bgcolor-realm/controls.mjs',join(directory,'bgcolor-realm-full.json'),candidate,join(directory,'bgcolor-realm-controls')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024})
assert.equal(r.error,undefined);assert.equal(r.status,0,r.stdout+r.stderr);console.log(r.stdout)
