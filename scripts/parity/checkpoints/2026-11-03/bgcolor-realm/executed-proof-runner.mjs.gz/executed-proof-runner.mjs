import assert from 'node:assert/strict'
import { execFileSync,spawnSync } from 'node:child_process'
import { writeFileSync,readFileSync } from 'node:fs'
import { join } from 'node:path'
const directory=process.env.EDITOR_RESULTS_DIR,raw=join(directory,'bgcolor-realm-full.json'),root='scripts/parity/checkpoints/2026-11-03/bgcolor-realm',env={...process.env};delete env.EDITOR_BGCOLOR_REALM_FILTER
const r=spawnSync(process.execPath,['scripts/parity/bgcolor-realm.mjs'],{env,encoding:'utf8',windowsHide:true,maxBuffer:32*1024*1024});assert.equal(r.error,undefined);writeFileSync(raw,r.stdout);writeFileSync(join(directory,'bgcolor-realm-full.stderr'),r.stderr)
writeFileSync(join(directory,'bgcolor-realm-process.json'),JSON.stringify({exitCode:r.status,signal:r.signal,expectedExitCode:0},null,2));assert.equal(r.status,0,r.stdout.slice(-1000)+r.stderr);assert.equal(r.stderr,'')
const candidate=execFileSync('git',['rev-parse','HEAD']).toString().trim(),review=spawnSync(process.env.EDITOR_PYTHON_PATH,[join(root,'review.py'),'--raw',raw,'--candidate',candidate,'--mode','green','--output',join(directory,'bgcolor-realm-review.json')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024})
assert.equal(review.error,undefined);assert.equal(review.status,0,review.stderr);console.log(JSON.stringify({rawComparisonExit:r.status,review:JSON.parse(readFileSync(join(directory,'bgcolor-realm-review.json')))}))
