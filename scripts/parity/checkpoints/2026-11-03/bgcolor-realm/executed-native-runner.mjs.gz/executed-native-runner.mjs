import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
const page=process.argv[2];assert.ok(['native-tools.html','native-bgcolor-boundary.html','native-bgcolor-boundary-trusted.html','native-bgcolor-realm.html','native-color-popup.html','native-color-popup-trusted.html'].includes(page))
const env={...process.env,EDITOR_NATIVE_PAGE:page};delete env.EDITOR_NATIVE_FILTER
const r=spawnSync(process.execPath,['tests/browser/physical-history.mjs'],{env,windowsHide:true,stdio:'inherit'});assert.equal(r.error,undefined);process.exitCode=r.status
