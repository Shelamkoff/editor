import assert from 'node:assert/strict'
import { execFileSync,spawnSync } from 'node:child_process'
import { readFileSync,writeFileSync } from 'node:fs'
import { join } from 'node:path'
const directory=process.env.EDITOR_RESULTS_DIR,root='scripts/parity/checkpoints/2026-11-03/public-readonly',env={...process.env,PYTHONDONTWRITEBYTECODE:'1'}
for(const name of ['EDITOR_PUBLIC_READONLY_FILTER','EDITOR_PUBLIC_STRUCTURE_FILTER'])delete env[name]
for(const family of ['public-readonly','public-structure']){
 const r=spawnSync(process.execPath,['scripts/parity/'+family+'.mjs'],{env,encoding:'utf8',windowsHide:true,maxBuffer:96*1024*1024});assert.equal(r.error,undefined);writeFileSync(join(directory,family+'-full.json'),r.stdout);writeFileSync(join(directory,family+'-full.stderr'),r.stderr);writeFileSync(join(directory,family+'-process.json'),JSON.stringify({exitCode:r.status,signal:r.signal,expectedExitCode:1,reason:family==='public-readonly'?'Legacy boolean rejection remains visible as a current API representation difference.':'Historical structural differences and unavailable observation ports remain explicit.'},null,2));assert.equal(r.status,1);assert.equal(r.stderr,'')
}
const source=execFileSync('git',['rev-parse','HEAD']).toString().trim(),r=spawnSync(process.env.EDITOR_PYTHON_PATH,[join(root,'review.py'),'--raw',join(directory,'public-readonly-full.json'),'--structure',join(directory,'public-structure-full.json'),'--candidate',source,'--output',join(directory,'public-readonly-review.json')],{env,encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});assert.equal(r.error,undefined);assert.equal(r.status,0,r.stderr);console.log(JSON.stringify({rawComparisonExits:[1,1],review:JSON.parse(readFileSync(join(directory,'public-readonly-review.json')))}))
