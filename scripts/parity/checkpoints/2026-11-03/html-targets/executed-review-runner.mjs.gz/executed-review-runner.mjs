import assert from 'node:assert/strict'
import { execFileSync,spawnSync } from 'node:child_process'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'
const basis=process.env.EDITOR_TARGETS_SOURCE_RESULTS_DIR,directory=process.env.EDITOR_RESULTS_DIR,source=execFileSync('git',['rev-parse','HEAD']).toString().trim();assert.ok(basis)
const r=spawnSync(process.env.EDITOR_PYTHON_PATH,['scripts/parity/checkpoints/2026-11-03/html-targets/review.py','--navigation',join(basis,'targets-primary.json'),'--comparison',join(basis,'targets-comparison.json'),'--native',join(basis,'native-html.log'),'--candidate',source,'--output',join(directory,'targets-review.json')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});assert.equal(r.error,undefined);assert.equal(r.status,0,r.stderr);console.log(readFileSync(join(directory,'targets-review.json'),'utf8'))
