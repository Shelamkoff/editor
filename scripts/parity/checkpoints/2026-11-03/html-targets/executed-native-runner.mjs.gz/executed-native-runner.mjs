import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
const env={...process.env,EDITOR_NATIVE_PAGE:'native-html-content.html'};delete env.EDITOR_NATIVE_FILTER
const r=spawnSync(process.execPath,['tests/browser/physical-history.mjs'],{env,windowsHide:true,stdio:'inherit'});assert.equal(r.error,undefined);process.exitCode=r.status
