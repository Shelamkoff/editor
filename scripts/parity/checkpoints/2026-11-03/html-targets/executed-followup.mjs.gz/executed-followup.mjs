import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
const temp='test-results/audit-closeout-2026-11-01/',run=args=>spawnSync(process.execPath,['scripts/verification-results.mjs',...args],{encoding:'utf8',windowsHide:true,maxBuffer:96*1024*1024})
process.env.EDITOR_TARGETS_SOURCE_RESULTS_DIR=process.argv[2];assert.ok(process.env.EDITOR_TARGETS_SOURCE_RESULTS_DIR)
const gates=[['targets-proof',[process.execPath,temp+'run-html-targets-proof-followup.mjs']],['targets-controls',[process.execPath,temp+'run-html-targets-controls-followup.mjs']]],init=run(['init',...gates.map(([name])=>name)]);assert.equal(init.status,0,init.stdout+init.stderr);process.env.EDITOR_RESULTS_DIR=init.stdout.trim();console.log(process.env.EDITOR_RESULTS_DIR)
for(const[name,command]of gates){const r=run(['run',name,...(name==='targets-controls'?['--require','targets-proof']:[]),'--',...command]);console.log(name+': '+r.status);if(r.status!==0)console.error(r.stdout.slice(-3200)+r.stderr.slice(-3200))}
const end=run(['finish']);console.log('finish: '+end.status);process.exitCode=end.status
