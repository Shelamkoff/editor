import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { writeFileSync } from 'node:fs'
import { join } from 'node:path'
const family=process.argv[2];assert.ok(['primary','comparison'].includes(family))
const r=spawnSync(process.execPath,['scripts/parity/'+(family==='primary'?'html-content-navigation':'html-targets')+'.mjs'],{encoding:'utf8',windowsHide:true,maxBuffer:64*1024*1024});assert.equal(r.error,undefined);const directory=process.env.EDITOR_RESULTS_DIR
writeFileSync(join(directory,'targets-'+family+'.json'),r.stdout);writeFileSync(join(directory,'targets-'+family+'.stderr'),r.stderr);writeFileSync(join(directory,'targets-'+family+'-process.json'),JSON.stringify({exitCode:r.status,signal:r.signal,expectedExitCode:0,reason:'All current/native and three-source target actions match their independently observed native control.'},null,2));assert.equal(r.status,0,r.stderr);assert.equal(r.stderr,'');console.log(JSON.stringify({family,rawComparisonExit:r.status,bytes:Buffer.byteLength(r.stdout)}))
