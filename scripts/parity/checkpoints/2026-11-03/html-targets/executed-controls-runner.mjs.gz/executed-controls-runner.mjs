import assert from 'node:assert/strict'
import { execFileSync,spawnSync } from 'node:child_process'
import { join } from 'node:path'
const basis=process.env.EDITOR_TARGETS_SOURCE_RESULTS_DIR,directory=process.env.EDITOR_RESULTS_DIR,source=execFileSync('git',['rev-parse','HEAD']).toString().trim();assert.ok(basis)
const r=spawnSync(process.execPath,['scripts/parity/checkpoints/2026-11-03/html-targets/controls.mjs',join(basis,'targets-primary.json'),join(basis,'targets-comparison.json'),join(basis,'native-html.log'),source,join(directory,'targets-controls')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});assert.equal(r.error,undefined);assert.equal(r.status,0,r.stdout+r.stderr);console.log(r.stdout)
