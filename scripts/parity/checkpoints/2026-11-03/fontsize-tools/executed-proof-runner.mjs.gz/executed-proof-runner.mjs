import assert from 'node:assert/strict'
import { execFileSync,spawnSync } from 'node:child_process'
import { writeFileSync,readFileSync } from 'node:fs'
import { join } from 'node:path'
const family=process.argv[2];assert.ok(['fontsize-boundary','fontsize-reset-boundary','fontsize-tools'].includes(family))
const directory=process.env.EDITOR_RESULTS_DIR,raw=join(directory,family+'-full.json'),root='scripts/parity/checkpoints/2026-11-03/'+family,env={...process.env}
for(const name of ['EDITOR_FONTSIZE_BOUNDARY_FILTER','EDITOR_FONTSIZE_RESET_BOUNDARY_FILTER','EDITOR_FONTSIZE_TOOLS_FILTER'])delete env[name]
const r=spawnSync(process.execPath,['scripts/parity/'+family+'.mjs'],{env,encoding:'utf8',windowsHide:true,maxBuffer:256*1024*1024});assert.equal(r.error,undefined);writeFileSync(raw,r.stdout);writeFileSync(join(directory,family+'-full.stderr'),r.stderr)
writeFileSync(join(directory,family+'-process.json'),JSON.stringify({exitCode:r.status,signal:r.signal,expectedExitCode:1,reason:'Historical failures, incomplete actions and known baseline exceptions remain visible. Current output is independently verified.'},null,2));assert.equal(r.status,1);assert.equal(r.stderr,'')
const candidate=execFileSync('git',['rev-parse','HEAD']).toString().trim(),args=[join(root,'review.py'),'--raw',raw,'--candidate',candidate,...(family==='fontsize-tools'?[]:['--mode','green']),'--output',join(directory,family+'-review.json')]
const review=spawnSync(process.env.EDITOR_PYTHON_PATH,args,{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});assert.equal(review.error,undefined);assert.equal(review.status,0,review.stderr)
const report=JSON.parse(readFileSync(join(directory,family+'-review.json')));delete report.historical;console.log(JSON.stringify({rawComparisonExit:r.status,review:report}))
