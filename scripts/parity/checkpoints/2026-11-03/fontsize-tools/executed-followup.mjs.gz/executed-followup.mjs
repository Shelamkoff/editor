import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
const run=args=>spawnSync(process.execPath,['scripts/verification-results.mjs',...args],{encoding:'utf8',windowsHide:true,maxBuffer:128*1024*1024}),temp='test-results/audit-closeout-2026-11-01/'
const gates=[['native-font-reset',[process.execPath,temp+'run-font-native.mjs','native-fontsize-reset-boundary.html']],['native-font-reset-trusted',[process.execPath,temp+'run-font-native.mjs','native-fontsize-reset-boundary-trusted.html']],['font-reset-proof',[process.execPath,temp+'run-font-proof.mjs','fontsize-reset-boundary']],['font-reset-controls',[process.execPath,temp+'run-font-controls.mjs','fontsize-reset-boundary']]]
for(const name of ['EDITOR_BROWSER_PAGE','EDITOR_BROWSER_ROOT','EDITOR_NATIVE_PAGE','EDITOR_NATIVE_FILTER','EDITOR_FONTSIZE_BOUNDARY_FILTER','EDITOR_FONTSIZE_RESET_BOUNDARY_FILTER','EDITOR_FONTSIZE_TOOLS_FILTER'])delete process.env[name]
const init=run(['init',...gates.map(([name])=>name)]);assert.equal(init.status,0,init.stdout+init.stderr);process.env.EDITOR_RESULTS_DIR=init.stdout.trim();console.log(process.env.EDITOR_RESULTS_DIR)
for(const[name,command]of gates){const r=run(['run',name,...(name==='font-reset-controls'?['--require','font-reset-proof']:[]),'--',...command]);console.log(name+': '+r.status);if(r.status!==0)console.error(r.stdout.slice(-3000)+r.stderr.slice(-3000))}
const end=run(['finish']);console.log('finish: '+end.status);process.exitCode=end.status
