import assert from 'node:assert/strict'
import { execFileSync,spawnSync } from 'node:child_process'
import { join } from 'node:path'
const family=process.argv[2];assert.ok(['fontsize-boundary','fontsize-reset-boundary','fontsize-tools'].includes(family))
const directory=process.env.EDITOR_RESULTS_DIR,candidate=execFileSync('git',['rev-parse','HEAD']).toString().trim()
const r=spawnSync(process.execPath,['scripts/parity/checkpoints/2026-11-03/'+family+'/controls.mjs',join(directory,family+'-full.json'),candidate,join(directory,family+'-controls')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});assert.equal(r.error,undefined);assert.equal(r.status,0,r.stdout+r.stderr);console.log(r.stdout)
