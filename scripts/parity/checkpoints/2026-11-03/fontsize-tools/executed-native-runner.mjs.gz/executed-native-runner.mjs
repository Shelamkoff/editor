import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
const page=process.argv[2];assert.ok(['native-tools.html','native-fontsize-boundary.html','native-fontsize-boundary-trusted.html','native-fontsize-reset-boundary.html','native-fontsize-reset-boundary-trusted.html','native-fontsize-tools.html','native-fontsize-tools-trusted.html','native-fontsize-imported.html','native-fontsize-imported-trusted.html','native-font-cancel.html','native-bgcolor-tools.html','native-bgcolor-tools-trusted.html'].includes(page))
const env={...process.env,EDITOR_NATIVE_PAGE:page};delete env.EDITOR_NATIVE_FILTER
const r=spawnSync(process.execPath,['tests/browser/physical-history.mjs'],{env,windowsHide:true,stdio:'inherit'});assert.equal(r.error,undefined);process.exitCode=r.status
