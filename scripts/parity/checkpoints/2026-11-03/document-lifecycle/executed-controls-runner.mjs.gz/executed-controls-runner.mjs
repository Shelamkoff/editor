import assert from 'node:assert/strict'
import { execFileSync,spawnSync } from 'node:child_process'
import { join } from 'node:path'
const directory=process.env.EDITOR_RESULTS_DIR,source=execFileSync('git',['rev-parse','HEAD']).toString().trim()
const r=spawnSync(process.execPath,['scripts/parity/checkpoints/2026-11-03/document-lifecycle/controls.mjs',join(directory,'document-lifecycle-full.json'),source,directory,join(directory,'document-lifecycle-controls')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024})
assert.equal(r.error,undefined);assert.equal(r.status,0,r.stdout+r.stderr);console.log(r.stdout)
