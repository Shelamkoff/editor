import assert from 'node:assert/strict'
import { execFileSync,spawnSync } from 'node:child_process'
import { join } from 'node:path'
const directory=process.env.EDITOR_RESULTS_DIR,source=execFileSync('git',['rev-parse','HEAD']).toString().trim()
const r=spawnSync(process.execPath,['scripts/parity/checkpoints/2026-11-03/disclosure-state/controls.mjs',join(directory,'disclosure-state-full.json'),source,join(directory,'disclosure-state-controls')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});assert.equal(r.error,undefined);assert.equal(r.status,0,r.stdout+r.stderr);console.log(r.stdout)
