import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {writeFileSync} from 'node:fs'
const root='test-results/audit-closeout-2026-11-01',env={...process.env,PYTHONDONTWRITEBYTECODE:'1'},directory=execFileSync(process.execPath,['scripts/verification-results.mjs','init','node','package'],{env,encoding:'utf8'}).trim();env.EDITOR_RESULTS_DIR=directory;writeFileSync(root+'/node-discovery-run-path.txt',directory)
for(const[name,script]of [['node','test'],['package','test:package']]){const r=spawnSync(process.execPath,['scripts/verification-results.mjs','run',name,'--','cmd.exe','/d','/s','/c','npm run '+script],{env,stdio:'inherit',windowsHide:true});assert.equal(r.error,undefined);console.log(JSON.stringify({gate:name,exitCode:r.status}))}
const r=spawnSync(process.execPath,['scripts/verification-results.mjs','finish'],{env,stdio:'inherit',windowsHide:true});assert.equal(r.status,0)
