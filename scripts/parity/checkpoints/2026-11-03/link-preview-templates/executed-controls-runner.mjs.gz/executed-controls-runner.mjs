import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {join} from 'node:path'
const d=process.env.EDITOR_RESULTS_DIR,source=execFileSync('git',['rev-parse','HEAD']).toString().trim(),r=spawnSync(process.execPath,['scripts/parity/checkpoints/2026-11-03/link-preview-templates/controls.mjs',join(d,'link-preview-templates-full.json'),join(d,'link-preview-templates-red.json'),join(d,'native-templates.log'),join(d,'native-templates-trusted.log'),source,join(d,'link-preview-templates-controls')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});assert.equal(r.error,undefined);assert.equal(r.status,0,r.stdout+r.stderr);console.log(r.stdout)
