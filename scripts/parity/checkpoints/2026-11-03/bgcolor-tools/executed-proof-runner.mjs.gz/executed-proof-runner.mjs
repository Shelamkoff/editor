import assert from 'node:assert/strict'
import { execFileSync,spawnSync } from 'node:child_process'
import { writeFileSync,readFileSync } from 'node:fs'
import { join } from 'node:path'
const directory=process.env.EDITOR_RESULTS_DIR,raw=join(directory,'bgcolor-tools-full.json'),root='scripts/parity/checkpoints/2026-11-03/bgcolor-tools',env={...process.env};delete env.EDITOR_BGCOLOR_TOOLS_FILTER
const r=spawnSync(process.execPath,['scripts/parity/bgcolor-tools.mjs'],{env,encoding:'utf8',windowsHide:true,maxBuffer:128*1024*1024});assert.equal(r.error,undefined);writeFileSync(raw,r.stdout);writeFileSync(join(directory,'bgcolor-tools-full.stderr'),r.stderr)
writeFileSync(join(directory,'bgcolor-tools-process.json'),JSON.stringify({exitCode:r.status,signal:r.signal,expectedExitCode:1,reason:'Historical failures/incomplete actions remain visible; current runtime is independently verified.'},null,2));assert.equal(r.status,1);assert.equal(r.stderr,'')
const candidate=execFileSync('git',['rev-parse','HEAD']).toString().trim(),review=spawnSync(process.env.EDITOR_PYTHON_PATH,[join(root,'review.py'),'--raw',raw,'--candidate',candidate,'--output',join(directory,'bgcolor-tools-review.json')],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024})
assert.equal(review.error,undefined);assert.equal(review.status,0,review.stderr);const report=JSON.parse(readFileSync(join(directory,'bgcolor-tools-review.json')));delete report.historical;console.log(JSON.stringify({rawComparisonExit:r.status,review:report}))
