import { spawnSync } from 'node:child_process'
const run=args=>spawnSync(process.execPath,['scripts/verification-results.mjs',...args],{encoding:'utf8',windowsHide:true,maxBuffer:96*1024*1024}),npm=s=>['cmd.exe','/d','/s','/c','npm run '+s]
const temp='test-results/audit-closeout-2026-11-01/',native=page=>[process.execPath,temp+'run-bgcolor-tools-native.mjs',page],script=name=>[process.execPath,temp+name+'.mjs']
const gates=[['types',npm('typecheck')],['browser',[process.execPath,'tests/browser/run.mjs']],['native-common',native('native-bgcolor-tools.html')],['native-common-trusted',native('native-bgcolor-tools-trusted.html')],['common-proof',script('run-bgcolor-tools-proof')],['common-controls',script('run-bgcolor-tools-controls')],['docs',npm('test:docs')]]
for(const name of ['EDITOR_BROWSER_PAGE','EDITOR_BROWSER_ROOT','EDITOR_NATIVE_PAGE','EDITOR_NATIVE_FILTER','EDITOR_BGCOLOR_TOOLS_FILTER'])delete process.env[name]
const init=run(['init',...gates.map(([name])=>name)]);if(init.status!==0)throw Error(init.stdout+init.stderr);process.env.EDITOR_RESULTS_DIR=init.stdout.trim();console.log(process.env.EDITOR_RESULTS_DIR)
for(const[name,command]of gates){const r=run(['run',name,...(name==='common-controls'?['--require','common-proof']:[]),'--',...command]);console.log(name+': '+r.status);if(r.status!==0)console.error(r.stdout.slice(-2000)+r.stderr.slice(-2000))}
const end=run(['finish']);console.log('finish: '+end.status);process.exitCode=end.status
