import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
const run=args=>spawnSync(process.execPath,['scripts/verification-results.mjs',...args],{encoding:'utf8',windowsHide:true,maxBuffer:96*1024*1024})
for(const name of ['EDITOR_BROWSER_PAGE','EDITOR_BROWSER_ROOT'])delete process.env[name]
const init=run(['init','browser']);assert.equal(init.status,0,init.stdout+init.stderr);process.env.EDITOR_RESULTS_DIR=init.stdout.trim();console.log(process.env.EDITOR_RESULTS_DIR)
const gate=run(['run','browser','--',process.execPath,'tests/browser/run.mjs']);console.log('browser: '+gate.status);if(gate.status!==0)console.error(gate.stdout.slice(-3000)+gate.stderr.slice(-3000))
const end=run(['finish']);console.log('finish: '+end.status);process.exitCode=end.status
