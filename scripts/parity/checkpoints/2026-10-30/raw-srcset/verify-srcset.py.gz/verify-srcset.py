import collections
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/workspace/scratch/40cb45010ec4/rector-html-style-completion')
evidence = Path('/workspace/scratch/40cb45010ec4/rector-html-style-evidence')
data = json.loads((evidence / 'final/differential.log').read_text())
sha256 = lambda value: hashlib.sha256(value).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=root)
summary = {'source': data['headBefore'], 'tree': data['tree'], 'sources': {}, 'observationsRecomputed': 0, 'sourceFilesVerified': 0, 'dependencyFilesVerified': 0}
assert data['headBefore'] == data['headAfter']
assert not data['serverErrors']
names = {
    'comma-url', 'comma-url-without-descriptor', 'exponent-density',
    'leading-dot-density', 'positive-exponent-density', 'width-height-descriptors',
    'trailing-comma', 'ascii-whitespace', 'unsafe-neighbors', 'unsafe-leading-candidate',
    'parenthesized-invalid-descriptor', 'unterminated-invalid-descriptor',
    'non-ascii-descriptor-whitespace', 'blob-url', 'raster-data',
}
for source in data['sources']:
    rows = [row for row in data['results'] if row['source'] == source['label']]
    assert {row['name'] for row in rows} == names and len(rows) == len(names)
    failures = []
    for row in rows:
        assert row['complete'] and not row.get('error') and not row['errors']
        assert len(row['observations']) == 11
        recomputed = []
        for observation in row['observations']:
            actual = json.dumps(observation['actual'], sort_keys=True, separators=(',', ':'))
            expected = json.dumps(observation['expected'], sort_keys=True, separators=(',', ':'))
            verdict = 'PASS' if actual == expected else 'FAIL'
            assert verdict == observation['status']
            summary['observationsRecomputed'] += 1
            if verdict == 'FAIL': recomputed.append(observation)
        assert recomputed == row['failures']
        failures.extend(recomputed)
        by_property = {entry['property']: entry for entry in row['observations']}
        assert by_property['browser.currentSrc']['status'] == 'PASS'
        assert by_property['network.foreignRequests']['actual'] == []
        if source['label'] == 'candidate':
            assert not recomputed
            assert by_property['image.currentSrc']['actual'] == by_property['browser.currentSrc']['actual']
    for path, expected in source['loaded'].items():
        assert sha256(git('show', source['sha'] + ':' + path)) == expected
        summary['sourceFilesVerified'] += 1
    summary['sources'][source['label']] = {
        'sha': source['sha'], 'cases': len(rows), 'observations': sum(len(row['observations']) for row in rows),
        'failures': len(failures), 'failureProperties': dict(collections.Counter(entry['property'] for entry in failures)),
        'incomplete': 0, 'errors': 0,
    }
for path, expected in data['dependencyFiles'].items():
    assert sha256((root / 'node_modules' / path).read_bytes()) == expected
    summary['dependencyFilesVerified'] += 1
for field, path in [
    ('runnerSha256', 'scripts/parity/raw-srcset.mjs'),
    ('fixtureSha256', 'tests/browser/raw-srcset-fixture.js'),
    ('imageSha256', 'tests/browser/fixtures/srcset-pixel.svg'),
]:
    assert sha256(git('show', data['headBefore'] + ':' + path)) == data[field]
summary['artifactsVerified'] = 3
summary['candidatePass'] = data['candidatePass'] is True
assert summary['candidatePass']
print(json.dumps(summary, indent=2))
