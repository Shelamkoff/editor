import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

repo = Path('/workspace/scratch/40cb45010ec4/rector-html-style-completion')
output = Path('/workspace/scratch/40cb45010ec4/rector-html-style-evidence/final')
output.mkdir(exist_ok=True)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo).decode().strip()

def source():
    return {
        'head': git('rev-parse', 'HEAD'),
        'tree': git('rev-parse', 'HEAD^{tree}'),
        'status': git('status', '--porcelain=v1'),
        'diffSha256': hashlib.sha256(subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=repo)).hexdigest(),
        'lockSha256': hashlib.sha256((repo / 'package-lock.json').read_bytes()).hexdigest(),
    }

env = os.environ.copy()
env.update({
    'EDITOR_CHROME_PATH': '/tmp/rector-chrome/opt/google/chrome/chrome',
    'EDITOR_PLAYWRIGHT_PATH': '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs',
    'EDITOR_RESULTS_DIR': str(output),
})
checks = [
    ('ordinary', ['node', 'tests/browser/run.mjs'], {'EDITOR_BROWSER_PAGE': 'raw-srcset.html'}),
    ('trusted-types', ['node', 'tests/browser/run.mjs'], {'EDITOR_BROWSER_PAGE': 'raw-srcset-trusted-types.html'}),
    ('security-existing', ['node', 'tests/browser/run.mjs'], {'EDITOR_BROWSER_PAGE': 'security.html'}),
    ('trusted-types-existing', ['node', 'tests/browser/run.mjs'], {'EDITOR_BROWSER_PAGE': 'trusted-types.htm'}),
    ('native-raw', ['node', 'tests/browser/physical-history.mjs'], {'EDITOR_NATIVE_PAGE': 'native-plugin-parity.html', 'EDITOR_NATIVE_FILTER': 'Raw'}),
    ('url-policy', ['node', '--test', 'shared/sanitize/sanitizeUrl.test.js'], {}),
    ('typecheck', ['npm', 'run', 'typecheck'], {}),
    ('differential', ['node', 'scripts/parity/raw-srcset.mjs'], {}),
]
selected = os.environ.get('EDITOR_SRCSET_GATE_NAMES')
if selected:
    names = set(selected.split(','))
    checks = [check for check in checks if check[0] in names]
manifest = {'startedAt': now(), 'before': source(), 'checks': []}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
for name, command, extra in checks:
    record = {'name': name, 'command': command, 'env': extra, 'startedAt': now(), 'before': source()}
    with (output / (name + '.log')).open('wb') as stdout, (output / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(command, cwd=repo, env={**env, **extra}, stdout=stdout, stderr=stderr)
    record.update({'completedAt': now(), 'exitCode': result.returncode, 'after': source()})
    record['sourceUnchanged'] = record['before'] == record['after'] and not record['before']['status']
    if name == 'differential':
        try:
            data = json.loads((output / (name + '.log')).read_text())
            record['candidatePass'] = data['candidatePass']
            record['rawHistoricalFailuresRetained'] = result.returncode == 1
        except Exception as error:
            record['parseError'] = str(error)
    manifest['checks'].append(record)
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
manifest.update({'completedAt': now(), 'after': source()})
manifest['sourceUnchanged'] = manifest['before'] == manifest['after'] and not manifest['before']['status']
manifest['passed'] = all(record['sourceUnchanged'] and (record.get('candidatePass') is True if record['name'] == 'differential' else record['exitCode'] == 0) for record in manifest['checks'])
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
