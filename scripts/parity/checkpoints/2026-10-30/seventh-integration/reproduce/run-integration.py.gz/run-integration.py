import json
import os
from pathlib import Path
import signal
import subprocess
import sys

repo = Path('/workspace/scratch/2231de9d6b0d/editor')
env = dict(os.environ)
env.update({
    'EDITOR_CHROME_PATH': '/tmp/rector-chrome/opt/google/chrome/chrome',
    'EDITOR_PLAYWRIGHT_PATH': '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs',
    'EDITOR_V1_ROOT': '/workspace/scratch/2231de9d6b0d/reference-v1',
    'EDITOR_SPEC_BASELINE_ROOT': '/workspace/scratch/2231de9d6b0d/reference-spec',
})
for key in ('EDITOR_BROWSER_PAGE', 'EDITOR_BROWSER_ROOT', 'EDITOR_NATIVE_PAGE', 'EDITOR_NATIVE_FILTER', 'EDITOR_CANDIDATE_SHA'):
    env.pop(key, None)
gates = [
    ('unit', None, ['npm', 'test']),
    ('typecheck', None, ['npm', 'run', 'typecheck']),
    ('build', None, ['npm', 'run', 'build']),
    ('docs-contracts', None, ['npm', 'run', 'test:docs']),
    ('types', 'build', ['npm', 'run', 'test:types']),
    ('package', 'build', ['npm', 'run', 'test:package']),
    ('ordinary-browser', 'build', ['node', 'tests/browser/run.mjs']),
    ('native-browser', 'build', ['node', 'tests/browser/physical-history.mjs']),
    ('heap', 'build', ['node', 'tests/browser/heap-gate.mjs']),
    ('common-parity', None, ['node', 'scripts/parity/block-roundtrip.mjs']),
    ('gallery-parity', None, ['node', 'scripts/parity/gallery-caption-order.mjs']),
    ('docs-site', 'build', ['npm', 'run', 'docs:check']),
]
helper = ['node', 'scripts/verification-results.mjs']
directory = Path(subprocess.check_output(helper + ['init'] + [name for name, _, _ in gates], cwd=repo, env=env, text=True).strip())
env['EDITOR_RESULTS_DIR'] = str(directory)
Path('/tmp/rector-seventh-integration-path').write_text(str(directory) + '\n')
print(json.dumps({'directory': str(directory), 'head': json.loads((directory / 'manifest.json').read_text())['source']['head']}), flush=True)
child = None
interrupted = False

def interrupt(number, _frame):
    global interrupted
    interrupted = True
    if child is not None and child.poll() is None:
        child.send_signal(number)

signal.signal(signal.SIGINT, interrupt)
signal.signal(signal.SIGTERM, interrupt)
for name, prerequisite, command in gates:
    if interrupted:
        break
    args = helper + ['run', name]
    if prerequisite:
        args += ['--require', prerequisite]
    args += ['--'] + command
    print(json.dumps({'starting': name}), flush=True)
    with (directory / (name + '-console.log')).open('w') as output:
        child = subprocess.Popen(args, cwd=repo, env=env, stdout=output, stderr=subprocess.STDOUT)
        code = child.wait()
    state = json.loads((directory / 'manifest.json').read_text())['gates'][name]
    print(json.dumps({'gate': name, 'exitCode': code, 'outcome': state['outcome'], 'elapsedMs': state.get('elapsedMs')}), flush=True)
    if code:
        print((directory / (name + '-console.log')).read_text()[-4000:], flush=True)
    child = None
finished = subprocess.run(helper + ['finish'], cwd=repo, env=env)
manifest = json.loads((directory / 'manifest.json').read_text())
print(json.dumps({'directory': str(directory), 'outcome': manifest['outcome'], 'sourceUnchanged': manifest['sourceUnchanged']}), flush=True)
sys.exit(finished.returncode)
