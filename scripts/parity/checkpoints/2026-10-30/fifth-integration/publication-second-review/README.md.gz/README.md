# Independent review of the second publication batch and docs repair

## Result and scope

PASS. This review covers the 10-commit second batch and the following one-line documentation-build ignore repair. The original source chain ends at `369cf74e33f982eed78d5a8171e98b46e13f9fbb`; its published counterpart is `ae79a89c66c9b4b467e149dcaf45db2c99b0f617`, with tree `dccd6e5ca1d77ea087c1ec5ac5dc1589b6240c22`. Both chains begin at `132b59923de9bc6b1f3b3f73ba48c6d1f040826a`.

The parent published the prepared objects while this independent review was in progress. Independent GitHub GET responses observed the branch at the base before publication and at `ae79a89c` afterward. This is a historical observation of that update; subsequent documentation commits may advance the branch. This reviewer performed no remote mutation, main ref update, main source edit, or runtime test rerun.

## Verified publication properties

- All 11 original and published raw commit SHA-1 values, trees, messages and ordered parents match their mappings and fetched Git objects. Every original-to-published tree diff is empty. The changed commit metadata consists of author, committer and mapped parent headers; runtime, tests and evidence bytes are identical.
- All 11 published commit API responses match the fetched objects. All 11 non-recursive root-tree API responses were serialized to Git tree bytes and independently hashed; the bytes and SHA-1 IDs match local fetched trees.
- All 87 planned change records, covering 84 distinct paths, match exact Git path/mode/type/blob differences. There are no omitted or added paths in the plans.
- All 43 explicitly uploaded base64 blobs have the stated size and Git blob ID, contain the expected fetched bytes, and are used by the plans. All 30 inline UTF-8 content records match their Git blob IDs. Every referenced object is covered by the published base, an explicit upload or inline creation.
- Applying the plans in a temporary Git index and object directory reconstructs every one of the 11 expected trees. Main objects are a read-only alternate during this step.
- The complete published chain is a descendant of the observed base. This verifies compatibility with a non-force update; the reviewer did not perform the update.
- A separate fresh bare repository, with no refs and no alternate object directories, imported only the published tip's reachable object closure. All 11 original commit IDs were absent before recovery. Restoring their preserved raw commit bytes recovered exactly those IDs, trees and ordered chain. Only those 11 objects were added; Git connectivity verification exited 0. The imported closure contained 25,702 objects.
- Main HEAD, refs and tracked status were unchanged during both local verification scripts. Parent report work outside those measurement windows is outside this audit's scope.

## Validation provenance

The original full run `run-k1J3Tr` was **failed**, not 12/12 passed. Its first 11 gates passed on source `a7dc4172198dea9c641f5de41d4331e5a94a17b4`: unit, typecheck, build, docs-contracts, types, package, ordinary-browser, native-browser, heap, common-parity and gallery-parity. The docs-site command exited 0, but its gate failed because the source-state check detected three untracked generated VitePress temporary assets.

The repair changes only `.gitignore`, adding `docs/.vitepress/.temp/`. The separate run `run-0ehV77` passed build, docs-contracts and docs-site on source `369cf74e33f982eed78d5a8171e98b46e13f9fbb`, with `sourceUnchanged: true`. The archived manifests and `plan-review.json` preserve both outcomes. Neither this mapping audit nor the repaired documentation run constitutes a new full runtime test execution or a full functional-parity claim.

## Files and reproduction

`plan-review.json` contains each checked commit, changed path, uploaded blob, root tree, input hash and gate outcome. `remote-reads.json` retains the independent GET responses. `combined-source-map.json` retains exact raw original commit bytes. The six gzip snapshots retain the four publication plan/progress inputs and the two gate manifests. `recovery-review.json` records the isolated object recovery. `artifact-hashes.json` covers all other files in this directory, including decoded hashes for gzip snapshots.

The commands below reproduce the checks using the existing workspace. They write only their specified scratch output and temporary Git repositories; they do not update the reviewed repository. For replay elsewhere, unpack the four plan/progress snapshots into the inputs directory, provide a repository containing the published object closure and the original commits recoverable from `combined-source-map.json`, and place the two decoded manifests at the corresponding `test-results/<run>/manifest.json` paths in that replay repository. The GET snapshot is an immutable input; a new GET is needed to establish later remote-ref freshness.

```sh
python /workspace/scratch/2231de9d6b0d/publication-second-batch-review/verify_second_publication.py \
  --repo /workspace/scratch/2231de9d6b0d/editor \
  --inputs /workspace/scratch/2231de9d6b0d \
  --remote /workspace/scratch/2231de9d6b0d/publication-second-batch-review/remote-reads.json \
  --output /tmp/rector-second-publication-replay

python /workspace/scratch/2231de9d6b0d/publication-second-batch-review/review_recovery.py \
  --repo /workspace/scratch/2231de9d6b0d/editor \
  --map /workspace/scratch/2231de9d6b0d/publication-second-batch-review/combined-source-map.json \
  --output /tmp/rector-second-publication-recovery.json
```
