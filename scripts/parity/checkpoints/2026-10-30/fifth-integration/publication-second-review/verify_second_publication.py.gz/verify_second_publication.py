#!/usr/bin/env python3
"""Verify planned Git Data publication, uploaded blob coverage and fetched objects."""
import argparse
import base64
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def object_id(kind, data):
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def commit_parts(raw):
    headers, body = raw.split(b'\n\n', 1)
    parsed = {}
    for line in headers.splitlines():
        if line.startswith(b' '):
            continue
        key, value = line.split(b' ', 1)
        parsed.setdefault(key.decode(), []).append(value.decode())
    return parsed, body


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--remote', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo, output = args.repo.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    for key in ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY',
                'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_COMMON_DIR', 'GIT_NAMESPACE']:
        env.pop(key, None)
    env.update(GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1')
    started = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

    def git(*parts, input=None, environment=None, check=True):
        return subprocess.run(['git', '-C', str(repo), *parts], input=input, env=environment or env,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=check)

    def read(*parts):
        return git(*parts).stdout

    def state():
        return {'head': read('rev-parse', 'HEAD').decode().strip(),
                'refsSha256': sha256(read('for-each-ref', '--format=%(refname) %(objectname)')),
                'trackedStatus': read('status', '--porcelain=v1', '--untracked-files=no').decode()}

    before = state()
    input_names = ['publish-rector-second.json', 'rector-second-publication-progress.json',
                   'publish-rector-docs-repair.json', 'rector-docs-repair-publication-progress.json']
    raw_inputs = {name: (args.inputs / name).read_bytes() for name in input_names}
    decoded = {name: json.loads(data) for name, data in raw_inputs.items()}
    plans = [(decoded[input_names[0]], decoded[input_names[1]]),
             (decoded[input_names[2]], decoded[input_names[3]])]
    remote_bytes = args.remote.read_bytes()
    remote = json.loads(remote_bytes)
    assert remote['failed'] == []
    remote_commits = {entry['sha']: entry['response'] for entry in remote['objects'] if entry['kind'] == 'commit'}
    remote_trees = {entry['sha']: entry['response'] for entry in remote['objects'] if entry['kind'] == 'tree'}
    assert len(remote_commits) == len(remote_trees) == 11
    base = '132b59923de9bc6b1f3b3f73ba48c6d1f040826a'
    original_head = '369cf74e33f982eed78d5a8171e98b46e13f9fbb'
    published_head = 'ae79a89c66c9b4b467e149dcaf45db2c99b0f617'
    assert remote['initialRef']['response']['object']['sha'] == base
    assert remote['finalRef']['response']['object']['sha'] == published_head
    assert remote['finalRef']['response']['ref'] == 'refs/heads/refactor/rector-v2-architecture'
    known_remote = set(read('rev-list', '--objects', '--no-object-names', base).decode().splitlines())
    original_parent = published_parent = base
    pairs, changes, blobs, tree_checks = [], [], [], []
    uploaded = set()
    used_uploaded = set()
    inline_content_count = 0

    with tempfile.TemporaryDirectory(prefix='publication-plan-index-') as temporary:
        temporary = Path(temporary)
        objects = temporary / 'objects'; objects.mkdir()
        staging_env = dict(env, GIT_INDEX_FILE=str(temporary / 'index'), GIT_OBJECT_DIRECTORY=str(objects),
                           GIT_ALTERNATE_OBJECT_DIRECTORIES=read('rev-parse', '--path-format=absolute', '--git-path', 'objects').decode().strip())
        git('read-tree', base, environment=staging_env)
        for batch_index, (plan, progress) in enumerate(plans):
            assert plan['repository'] == 'Shelamkoff/editor'
            assert plan['branch'] == 'refactor/rector-v2-architecture'
            assert plan['base'] == progress['base'] == original_parent
            assert plan['baseTree'] == progress['baseTree'] == read('rev-parse', original_parent + '^{tree}').decode().strip()
            assert git('write-tree', environment=staging_env).stdout.decode().strip() == plan['baseTree']
            assert progress.get('publishedBase', progress['base']) == published_parent
            assert len(plan['commits']) == len(progress['commits']) == (10 if batch_index == 0 else 1)
            assert len(plan['blobs']) == (43 if batch_index == 0 else 0)
            batch_blob_ids = set()
            for blob in plan['blobs']:
                assert blob['encoding'] == 'base64'
                content = base64.b64decode(blob['content'], validate=True)
                assert len(content) == blob['size']
                assert object_id('blob', content) == blob['sha']
                assert read('cat-file', 'blob', blob['sha']) == content
                assert blob['sha'] not in batch_blob_ids
                batch_blob_ids.add(blob['sha'])
                blobs.append({'sha': blob['sha'], 'size': len(content), 'sha256': sha256(content)})
            assert set(progress.get('uploadedBlobs', [])) == batch_blob_ids
            uploaded.update(batch_blob_ids)
            known_remote.update(batch_blob_ids)

            for local, published in zip(plan['commits'], progress['commits']):
                raw = local['rawCommit'].encode()
                headers, body = commit_parts(raw)
                published_raw = read('cat-file', 'commit', published['published'])
                published_headers, published_body = commit_parts(published_raw)
                assert local['sha'] == published['local'] == object_id('commit', raw)
                assert raw == read('cat-file', 'commit', local['sha'])
                assert published.get('rawCommit', local['rawCommit']) == local['rawCommit']
                assert headers['parent'] == [original_parent] and published_headers['parent'] == [published_parent]
                assert local['parent'] == published['parentLocal'] == original_parent
                assert published['parentPublished'] == published_parent
                assert object_id('commit', published_raw) == published['published']
                assert headers['tree'] == published_headers['tree'] == [local['tree']]
                assert local['tree'] == published['tree']
                assert body == published_body == local['message'].encode() == published['message'].encode()
                metadata_changes = [key for key in sorted(set(headers) | set(published_headers)) if headers.get(key) != published_headers.get(key)]
                assert set(metadata_changes) <= {'author', 'committer', 'parent'}
                assert read('diff', '--name-only', '-z', local['sha'], published['published']) == b''

                fetched = remote_commits[published['published']]
                assert fetched['sha'] == published['published']
                assert fetched['tree']['sha'] == local['tree']
                assert [entry['sha'] for entry in fetched['parents']] == [published_parent]
                assert fetched['message'] == body.decode().rstrip('\n')
                tree_response = remote_trees[local['tree']]
                assert tree_response['sha'] == local['tree'] and not tree_response.get('truncated', False)
                tree_items = tree_response['tree']
                assert all('/' not in entry['path'] for entry in tree_items)
                tree_items = sorted(tree_items, key=lambda entry: entry['path'].encode() + (b'/' if entry['type'] == 'tree' else b''))
                tree_raw = b''.join((entry['mode'].lstrip('0') + ' ' + entry['path']).encode() + b'\0' + bytes.fromhex(entry['sha']) for entry in tree_items)
                assert object_id('tree', tree_raw) == local['tree']
                assert tree_raw == read('cat-file', 'tree', local['tree'])
                tree_checks.append({'tree': local['tree'], 'rootEntries': len(tree_items), 'rootRawSha256': sha256(tree_raw),
                                    'remoteTreeHashRecomputed': True, 'remoteAndLocalRawTreeBytesIdentical': True})

                expected_paths = [entry.decode() for entry in read('diff-tree', '--no-commit-id', '--name-only', '--no-renames', '-r', '-z', original_parent, local['sha']).split(b'\0') if entry]
                planned_paths = [entry['path'] for entry in local['changes']]
                assert len(planned_paths) == len(set(planned_paths))
                assert sorted(planned_paths) == sorted(expected_paths)
                inline_ids = set()
                for entry in local['changes']:
                    assert entry['type'] == 'blob' and entry['mode'] == '100644'
                    assert not entry['path'].startswith('/') and '..' not in entry['path'].split('/')
                    listing = read('ls-tree', '-z', local['sha'], '--', entry['path']).rstrip(b'\0')
                    info, path = listing.split(b'\t', 1)
                    mode, kind, oid = info.decode().split(' ')
                    assert path.decode() == entry['path'] and (mode, kind, oid) == (entry['mode'], entry['type'], entry['sha'])
                    if 'content' in entry:
                        content = entry['content'].encode('utf-8')
                        assert object_id('blob', content) == entry['sha']
                        assert read('cat-file', 'blob', entry['sha']) == content
                        inline_ids.add(entry['sha'])
                        inline_content_count += 1
                known_remote.update(inline_ids)
                updates = b''
                for entry in local['changes']:
                    assert entry['sha'] in known_remote, ('Uncovered tree blob reference', entry['path'], entry['sha'])
                    if entry['sha'] in uploaded:
                        used_uploaded.add(entry['sha'])
                    updates += f"{entry['mode']} {entry['sha']}\t{entry['path']}\0".encode()
                    changes.append({'commit': local['sha'], 'path': entry['path'], 'mode': entry['mode'],
                                    'sha': entry['sha'], 'inlineContent': 'content' in entry,
                                    'explicitlyUploaded': entry['sha'] in uploaded})
                git('update-index', '-z', '--index-info', input=updates, environment=staging_env)
                reconstructed_tree = git('write-tree', environment=staging_env).stdout.decode().strip()
                assert reconstructed_tree == local['tree']
                pairs.append({'local': local['sha'], 'published': published['published'], 'tree': local['tree'],
                              'parentLocal': original_parent, 'parentPublished': published_parent,
                              'message': local['message'], 'rawCommit': local['rawCommit'],
                              'plannedPaths': planned_paths, 'reconstructedTree': reconstructed_tree,
                              'sourceRawSha256': sha256(raw), 'publishedRawSha256': sha256(published_raw),
                              'metadataFieldsChanged': metadata_changes, 'allChecksPassed': True})
                original_parent, published_parent = local['sha'], published['published']
            assert original_parent == plan['head'] == progress['head']
            assert published_parent == progress['publishedHead']
            assert progress['branchUpdated'] is True and progress['verifiedAfterFetch'] is True
            assert progress['remoteTipAtPublication'] == published_head
    assert original_parent == original_head and published_parent == published_head
    assert uploaded == used_uploaded and len(uploaded) == 43
    assert read('rev-list', '--reverse', base + '..' + published_head).decode().splitlines() == [entry['published'] for entry in pairs]
    assert read('rev-list', '--reverse', base + '..' + original_head).decode().splitlines() == [entry['local'] for entry in pairs]
    git('merge-base', '--is-ancestor', base, published_head)
    repair_diff = read('diff', '--name-only', '-z', 'a7dc4172198dea9c641f5de41d4331e5a94a17b4', original_head)
    assert repair_diff == b'.gitignore\0'
    old_ignore = read('show', 'a7dc4172198dea9c641f5de41d4331e5a94a17b4:.gitignore')
    new_ignore = read('show', original_head + ':.gitignore')
    assert new_ignore == old_ignore.replace(b'docs/.vitepress/dist/\n', b'docs/.vitepress/dist/\ndocs/.vitepress/.temp/\n', 1)

    gate_manifests = {}
    for run in ['run-k1J3Tr', 'run-0ehV77']:
        raw = (repo / 'test-results' / run / 'manifest.json').read_bytes()
        gate_manifests[run] = (raw, json.loads(raw))
    full = gate_manifests['run-k1J3Tr'][1]
    docs = gate_manifests['run-0ehV77'][1]
    assert full['source']['head'] == 'a7dc4172198dea9c641f5de41d4331e5a94a17b4'
    assert full['outcome'] == 'failed' and full['sourceUnchanged'] is False
    assert len(full['gates']) == 12
    passed_before_docs = {key: gate for key, gate in full['gates'].items() if key != 'docs-site'}
    assert len(passed_before_docs) == 11
    assert all(gate['outcome'] == 'passed' and gate['exitCode'] == 0 and gate['sourceUnchanged'] is True for gate in passed_before_docs.values())
    failed_docs = full['gates']['docs-site']
    assert failed_docs['outcome'] == 'failed' and failed_docs['exitCode'] == 0 and failed_docs['sourceUnchanged'] is False
    assert failed_docs['sourceBefore']['head'] == failed_docs['sourceAfter']['head'] == full['source']['head']
    assert failed_docs['sourceBefore']['tree'] == failed_docs['sourceAfter']['tree']
    untracked = failed_docs['sourceAfter']['untracked']
    assert untracked and all((entry['path'] if isinstance(entry, dict) else entry).startswith('docs/.vitepress/.temp/') for entry in untracked)
    assert docs['source']['head'] == original_head and docs['outcome'] == 'passed' and docs['sourceUnchanged'] is True
    assert set(docs['gates']) == {'build', 'docs-contracts', 'docs-site'}
    assert all(gate['outcome'] == 'passed' and gate['exitCode'] == 0 and gate['sourceUnchanged'] is True for gate in docs['gates'].values())
    assert docs['source']['tree'] == pairs[-1]['tree']

    combined = {'repository': plans[0][0]['repository'], 'branch': plans[0][0]['branch'],
                'originalBase': base, 'originalHead': original_head, 'publishedHead': published_head,
                'commits': [{key: entry[key] for key in ['local', 'published', 'tree', 'parentLocal', 'parentPublished', 'message', 'rawCommit']} for entry in pairs]}
    (output / 'combined-source-map.json').write_text(json.dumps(combined, indent=2) + '\n')
    snapshots = []
    for name, raw in raw_inputs.items():
        assert (args.inputs / name).read_bytes() == raw
        packed = gzip.compress(raw, mtime=0); (output / (name + '.gz')).write_bytes(packed)
        snapshots.append({'path': name + '.gz', 'sha256': sha256(packed), 'decodedSha256': sha256(raw), 'decodedSize': len(raw)})
    for run, (raw, data) in gate_manifests.items():
        packed = gzip.compress(raw, mtime=0); name = run + '-manifest.json.gz'
        (output / name).write_bytes(packed)
        snapshots.append({'path': name, 'sha256': sha256(packed), 'decodedSha256': sha256(raw), 'decodedSize': len(raw)})
    assert args.remote.read_bytes() == remote_bytes
    after = state()
    result = {
        'status': 'PASS', 'startedAt': started, 'finishedAt': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'scriptSha256': sha256(Path(__file__).read_bytes()), 'remoteReadsSha256': sha256(remote_bytes),
        'reviewedBase': base, 'originalHead': original_head, 'publishedHead': published_head,
        'commitPairs': len(pairs), 'pairs': pairs, 'rootTreeChecks': tree_checks,
        'explicitUploadedBlobCount': len(blobs), 'explicitUploadedBlobs': blobs,
        'allUploadedBlobsUsed': uploaded == used_uploaded, 'inlineContentRecords': inline_content_count,
        'plannedChangeRecords': len(changes), 'uniqueChangedPaths': len({entry['path'] for entry in changes}),
        'changes': changes, 'allPlannedTreesReconstructed': True, 'allChangedPathsCovered': True,
        'allSourcePublishedDiffsEmpty': True, 'fastForwardFromReviewedBase': True,
        'publicationState': 'The parent published the reviewed chain during this read-only review. Final independent GitHub ref read confirms the full tip; no ref mutation was performed by this reviewer.',
        'validation': {'originalRun': 'run-k1J3Tr', 'originalOutcome': 'failed', 'passedGates': list(passed_before_docs),
                       'originalDocsSite': {'outcome': 'failed', 'commandExitCode': 0, 'sourceUnchanged': False,
                                            'untrackedGeneratedEntries': len(untracked)},
                       'repairOnlyChangedPath': '.gitignore', 'repairRun': 'run-0ehV77', 'repairOutcome': 'passed',
                       'repairGates': ['build', 'docs-contracts', 'docs-site'], 'repairSource': original_head,
                       'repairSourceUnchanged': True, 'all12OriginalGatesPassed': False},
        'inputSnapshots': snapshots, 'mainBefore': before, 'mainAfter': after,
        'mainStateUnchangedDuringScript': before == after, 'mainWritesByReviewer': 0,
        'limits': 'Source publication and existing gate manifests are verified. This does not rerun all browser tests or claim that the original failed documentation gate passed. Parent report edits in the main worktree are independent of this immutable-object review.',
    }
    (output / 'plan-review.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ['status', 'commitPairs', 'explicitUploadedBlobCount', 'inlineContentRecords',
                                                 'plannedChangeRecords', 'uniqueChangedPaths', 'allPlannedTreesReconstructed',
                                                 'fastForwardFromReviewedBase', 'mainStateUnchangedDuringScript']}))


if __name__ == '__main__':
    main()
