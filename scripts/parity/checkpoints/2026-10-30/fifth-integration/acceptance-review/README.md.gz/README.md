# Independent acceptance review and publication drafts

This directory is scratch staging only. No main-branch file was edited, and no extra browser, native, unit or performance run was started.

- `acceptance-review.json`: register audit plus independent public-focus evidence verification on frozen main source `a7dc4172198dea9c641f5de41d4331e5a94a17b4`.
- `review_acceptance.py`: original audit script; reads immutable Git objects and the already completed scoped comparison output.
- `table-integrated-review.json`: independent reconstruction of the fresh integrated Table comparison, including fixed grids, IDs, sidecars, headings, action counts and rendered structure.
- `review_table_integrated.py`: its original audit script.
- `publication-appendix-en.md` and `publication-appendix-ru.md`: matching publication appendices with actual frozen source and scoped counts. They must not be published until the combined validation finishes and the placeholders are filled.

The nine proposed rows are all presently open and unique. Current register: 209 unique rows, 37 accepted / 172 open. With these nine accepted after integration: 46 accepted / 163 open. No other row changes acceptance.

Replace `{{INTEGRATION_CHECKPOINT_URL}}`, `{{FOCUS_CHECKPOINT_URL}}`, and the language-specific `{{EN_INTEGRATION_RESULT}}` / `{{RU_INTEGRATION_RESULT}}`. The combined result sentence must use completed command results only and state the source/run identity. It may be concise because the linked integration record carries the full table. Remove the draft comment only after those replacements.

The fresh focus comparison has 147 candidate observations, 147 specification-baseline observations with eight historical failures in first focus, and 20 separate v1 public-focus/native-navigation observations with one historical Undo-caret failure. The seven newer keyed/numeric v1 operations are explicitly unsupported, not passed or fabricated by an adapter. The independent audit checks all 314 expected values against fixed Alpha/Bravo records and coordinates.

The fresh Table comparison has 1346 candidate and 1346 baseline observations, both all passing, plus 1210 v1 observations with 38 historical focus/caret failures. Its independent audit verifies all 3902 verdicts and reconstructs 282 phase states. Overall raw-verdict audit: 4216. Counts describe observations, not additional acceptance rows or independent integration test totals.
