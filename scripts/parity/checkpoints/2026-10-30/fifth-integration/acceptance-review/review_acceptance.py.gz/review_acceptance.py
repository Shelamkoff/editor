from pathlib import Path
import json,re,hashlib,gzip,subprocess
repo=Path('/workspace/scratch/2231de9d6b0d/editor')
out=Path('/workspace/scratch/2231de9d6b0d/acceptance-review-next')
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def sha(x):return hashlib.sha256(x).hexdigest()
head=git('rev-parse','HEAD').decode().strip()
register_bytes=git('show',head+':docs/architecture/rector-v2/PRESERVATION.md');register=register_bytes.decode()
rows={}
for line in register.splitlines():
 match=re.match(r'\| ([A-Z][A-Z0-9_]+) \|',line)
 if match and match[1] != "ID":
  assert match[1] not in rows
  rows[match[1]]=line
accepted={id for id,line in rows.items() if '**Accepted' in line}
focus_ids=[f'FOCUS_VALUES_OFFSET_{i}' for i in range(1,7)]+['DEFECT_FIRST_FOCUS']
new_ids=['BLOCK_TABLE_ROWS_COLUMNS','BLOCK_TABLE_HEADINGS']+focus_ids
assert len(rows)==209 and len(accepted)==37
assert len(new_ids)==len(set(new_ids))==9
assert all(id in rows and id not in accepted for id in new_ids)
raw_path=repo/'test-results/scoped-fifth-lz2cd717/focus.json'
raw_bytes=raw_path.read_bytes();data=json.loads(raw_bytes)
expected_map=dict(zip(focus_ids,[2,2,0,5,0,5,2]))
assert not data['serverErrors']
verdicts=0;oracle_checks=0;summary=[]
for result in data['results']:
 legacy=result['source']=='v1'
 assert not result['pageErrors']
 assert len(result['cases'])==(1 if legacy else 7)
 if legacy:
  assert {item['id'] for item in result['unsupported']}==set(focus_ids)
  assert all(item['status']=='UNSUPPORTED' for item in result['unsupported'])
 else:assert {item['id'] for item in result['cases']}==set(focus_ids)
 failures=[]
 for case in result['cases']:
  assert case['complete'] and not case['errors'] and case['phases']==['focus','edit','undo','redo','destroy']
  dest='b' if legacy or case['id']=='DEFECT_FIRST_FOCUS' else 'a'
  offset=2 if legacy else expected_map[case['id']]
  before=[{'id':id,'type':'paragraph',**({} if legacy else {'dataVersion':2}),'data':{'text':text}} for id,text in [('a','Alpha'),('b','Bravo')]]
  after=json.loads(json.dumps(before));target=after[1 if dest=='b' else 0]['data'];target['text']=target['text'][:offset]+'X'+target['text'][offset:]
  envelope={'version':'1.0.5' if legacy else '2.0.0','blocks':before}
  def point(n):return {'active':True,'anchor':n,'focus':n,'collapsed':True}
  expected={'initialRecords':before,'initialHistory':[False,False], 'focusKeepsRecords':before,'focusKeepsHistory':[False,False],'focusKeepsCallerInput':envelope}
  if legacy:expected.update({'keyedFocusApiAbsent':'undefined','nativeNavigationSelection':point(offset),'nativeNavigationHistory':[False,False]})
  else:expected.update({'accepted':True,'currentId':dest,'selection':point(offset),'settledCurrentEvents':[] if dest=='a' else [{'id':'b','selection':point(2)}]})
  for phase in ['edit','undo','redo']:
   edited=phase!='undo';expected.update({phase+'.records':after if edited else before,phase+'.history':[True,False] if edited else [False,True],phase+'.selection':point(offset+1 if edited else offset),phase+'.callerInput':envelope})
  assert len(case['observations'])==len(expected)
  for observation in case['observations']:
   prop=observation['property'];assert prop in expected
   assert observation.get('expected')==expected[prop],(result['source'],case['id'],prop,'oracle mismatch')
   actual=observation.get('actual',{'__undefined__':True})
   assert observation['status']==('PASS' if actual==expected[prop] else 'FAIL')
   verdicts+=1;oracle_checks+=1
   if observation['status']!='PASS':failures.append({'id':case['id'],'property':prop,'actual':actual,'expected':expected[prop]})
 summary.append({'source':result['source'],'executedCases':len(result['cases']),'observations':sum(len(c['observations']) for c in result['cases']),'rawFailures':len(failures),'failures':failures,'unsupportedRows':len(result['unsupported'])})
source_hashes=0
for source in data['sources']:
 assert git('rev-parse',source['sha']+'^{tree}').decode().strip()==source['tree']
 for path,digest in source['loaded'].items():
  assert sha(git('show',source['sha']+':'+path))==digest
  source_hashes+=1
for path,digest in data['dependencyFiles'].items():assert sha((repo/'node_modules'/path).read_bytes())==digest
runner_current=sha(git('show',head+':scripts/parity/public-focus.mjs'))
assert runner_current==data['runnerSha256']
table_dir=repo/'scripts/parity/checkpoints/2026-10-30/table-settings'
table_review_bytes=(out/'table-integrated-review.json').read_bytes()
table_review=json.loads(table_review_bytes)
table_raw_bytes=(repo/'test-results/scoped-fifth-lz2cd717/table.json').read_bytes()
assert table_review['decodedRawSha256']==sha(table_raw_bytes)
assert table_review['allPass'] and table_review['reviewedSource']==head
result={'reviewedMainSource':head,'registerSha256':sha(register_bytes),'register':{'uniqueRows':len(rows),'acceptedBefore':len(accepted),'openBefore':len(rows)-len(accepted),'proposedRows':new_ids,'duplicates':0,'alreadyAcceptedProposedRows':0,'acceptedAfterIntegration':len(accepted)+len(new_ids),'openAfterIntegration':len(rows)-len(accepted)-len(new_ids)},'focus':{'rawPath':str(raw_path),'rawSha256':sha(raw_bytes),'candidateSource':next(s['sha'] for s in data['sources'] if s['label']=='candidate'),'runnerSha256':data['runnerSha256'],'currentCommittedRunnerMatches':True,'independentlyRecomputedVerdicts':verdicts,'independentlyVerifiedOracleValues':oracle_checks,'verifiedModuleHashRecords':source_hashes,'verifiedDependencyFiles':len(data['dependencyFiles']),'summary':summary},'table':{'independentReviewSha256':sha(table_review_bytes),'rawSha256':sha(table_raw_bytes),'summary':table_review['summary'],'independentlyRecomputedVerdicts':table_review['independentlyRecomputedVerdicts'],'independentlyReconstructedPhaseStates':table_review['independentlyReconstructedPhaseStates'],'limitations':table_review['limitations']},'recommendation':'Accept exactly these nine register rows after the final integrated source and required gates are recorded. Existing modern improvements remain; absent v1 APIs stay unsupported instead of being fabricated by an adapter.','integration':{'source':head,'result':'PENDING_ACTUAL_GATES','counts':'PENDING_ACTUAL_COUNTS'},'noNewExecution':'No browser, native, unit, performance or integration gate was rerun for this review; only immutable evidence and source bytes were audited.'}
(out/'acceptance-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':head,'register':result['register'],'focusAudit':{'verdicts':verdicts,'sourceHashes':source_hashes,'dependencyHashes':len(data['dependencyFiles'])}},indent=2))
