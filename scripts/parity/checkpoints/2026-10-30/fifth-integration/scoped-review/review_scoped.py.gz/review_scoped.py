#!/usr/bin/env python3
"""Independently audit five scoped parity outputs without editing the repository."""

import argparse
from collections import defaultdict
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def digest(data):
    return hashlib.sha256(data).hexdigest()


def equivalent(left, right, *, sorted_keys=False):
    """JSON comparison with strict scalar types and the fixture's key ordering."""
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        left_keys, right_keys = list(left), list(right)
        if sorted_keys:
            left_keys, right_keys = sorted(left_keys), sorted(right_keys)
        return left_keys == right_keys and all(equivalent(left[key], right[key], sorted_keys=sorted_keys) for key in left_keys)
    if isinstance(left, list):
        return len(left) == len(right) and all(equivalent(a, b, sorted_keys=sorted_keys) for a, b in zip(left, right))
    return left == right


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--results', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo, directory = args.repo.resolve(), args.results.resolve()
    env = os.environ.copy()
    env.update(GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1')
    started = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

    def git(*parts):
        return subprocess.check_output(['git', '-C', str(repo), *parts], env=env)

    before = {'head': git('rev-parse', 'HEAD').decode().strip(),
              'refsSha256': digest(git('for-each-ref', '--format=%(refname) %(objectname)')),
              'trackedStatus': git('status', '--porcelain=v1', '--untracked-files=no').decode()}
    manifest_path = directory / 'manifest.json'
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes)
    source = manifest['source']['head']
    assert source == 'a7dc4172198dea9c641f5de41d4331e5a94a17b4'
    assert manifest['source']['tree'] == git('rev-parse', source + '^{tree}').decode().strip()
    assert manifest['source']['status'] == ''
    assert manifest['sourceUnchanged'] is True
    commands = {command['name']: command for command in manifest['commands']}
    assert set(commands) == {'focus', 'table', 'code', 'formatting', 'link'}
    fixtures = {'table': 'tests/browser/table-settings-parity-fixture.js',
                'code': 'tests/browser/code-language-parity-fixture.js'}
    hash_cache = {}
    all_module_records = []
    all_dependency_records = []
    all_version_records = []
    all_error_channels = []
    reports = []

    def source_hash(sha, path):
        key = (sha, path)
        if key not in hash_cache:
            hash_cache[key] = digest(git('show', sha + ':' + path))
        return hash_cache[key]

    def errors_at(value, path):
        count = 0
        for key in ['error', 'errors', 'pageErrors', 'serverErrors']:
            if key not in value:
                continue
            channel = value[key]
            if isinstance(channel, list):
                count += len(channel)
            elif channel is not None:
                count += 1
            all_error_channels.append({'path': path + '/' + key, 'value': channel})
        return count

    def complete_case(name, case):
        if name == 'focus':
            return case.get('complete') is True and case.get('phases') == ['focus', 'edit', 'undo', 'redo', 'destroy']
        if name == 'table':
            phases = ['load', 'input', 'settings']
            if '/minimum/' not in case['id']:
                phases += ['undo-setting']
            phases += ['undo-input', 'redo-input']
            if '/minimum/' not in case['id']:
                phases += ['redo-setting']
            phases += ['retired-control']
            return case.get('error') is None and case.get('completedPhases') == phases
        if name == 'code':
            return (case.get('error') is None and case.get('incomplete') is False
                    and case.get('incompletePhases') == [] and case.get('completedPhases') ==
                    ['load', 'read-only', 'editable-again', 'edit', 'undo', 'redo', 'dispose'])
        return case.get('complete') is True

    expected_ids = {
        'table': [f'TABLE_SETTINGS/{shape}/{action}' for shape in ['body', 'headed']
                  for action in ['header', 'row-add', 'row-del', 'col-add', 'col-del']]
                 + [f'TABLE_SETTINGS/{shape}/{action}' for shape in ['minimum', 'removed-widgets']
                    for action in ['row-del', 'col-del']],
        'code': ['custom-unknown-language', 'auto', 'javascript'],
        'focus': [f'FOCUS_VALUES_OFFSET_{index}' for index in range(1, 7)] + ['DEFECT_FIRST_FOCUS'],
    }
    for name in ['focus', 'table', 'code', 'formatting', 'link']:
        command = commands[name]
        path = directory / (name + '.json')
        raw = path.read_bytes()
        data = json.loads(raw)
        stderr = (directory / (name + '.stderr')).read_bytes()
        assert command['outputSha256'] == digest(raw)
        assert command['stderrSha256'] == digest(stderr)
        assert stderr == b''
        assert data['headBefore'] == source
        if 'headAfter' in data:
            assert data['headAfter'] == source
        runner = command['command'][1]
        runner_hash = source_hash(source, runner)
        assert digest((repo / runner).read_bytes()) == runner_hash
        assert command['runnerSha256'] == data['runnerSha256'] == runner_hash
        if name in fixtures:
            fixture_hash = source_hash(source, fixtures[name])
            assert digest((repo / fixtures[name]).read_bytes()) == data['fixtureSha256'] == fixture_hash
        labels = [entry['label'] for entry in data['sources']]
        assert len(labels) == len(set(labels))
        for entry in data['sources']:
            assert entry['sha'] == git('rev-parse', entry['sha']).decode().strip()
            if entry['label'] == 'candidate':
                assert entry['sha'] == source
            if entry['label'] == 'v1':
                assert entry['sha'] == '5e5c7f8d2d9e9a6cf2f95cfb7fd67aba227fa340'
            if entry['label'] == 'spec-baseline':
                assert entry['sha'] == 'e981ff308000c1d92d7e820df95113c1e19bcee8'
            if 'tree' in entry:
                assert entry['tree'] == git('rev-parse', entry['sha'] + '^{tree}').decode().strip()
            for filename, expected_hash in entry['loaded'].items():
                assert source_hash(entry['sha'], filename) == expected_hash
                all_module_records.append({'suite': name, 'source': entry['sha'], 'path': filename, 'sha256': expected_hash})
        for filename, expected_hash in data['dependencyFiles'].items():
            assert digest((repo / 'node_modules' / filename).read_bytes()) == expected_hash
            all_dependency_records.append({'suite': name, 'path': filename, 'sha256': expected_hash})
        for package, expected_version in data.get('dependencyVersions', {}).items():
            package_bytes = (repo / 'node_modules' / package / 'package.json').read_bytes()
            assert json.loads(package_bytes)['version'] == expected_version
            all_version_records.append({'suite': name, 'package': package, 'version': expected_version,
                                        'packageJsonSha256': digest(package_bytes)})

        totals = defaultdict(lambda: {'cases': 0, 'observations': 0, 'failures': 0, 'errors': 0,
                                      'incomplete': 0, 'unsupported': 0, 'caseIds': []})
        top_errors = errors_at(data, name)
        for row_index, row in enumerate(data['results']):
            label = row['source']
            assert label in labels
            total = totals[label]
            # Row-level page errors belong to the source even when cases exist.
            total['errors'] += errors_at(row, f'{name}/results/{row_index}')
            unsupported = row.get('unsupported', [])
            assert all(value.get('status') == 'UNSUPPORTED' and value.get('reason') for value in unsupported)
            total['unsupported'] += len(unsupported)
            cases = row['cases'] if 'cases' in row else [row]
            expected_failures = []
            expected_incomplete = []
            for case_index, case in enumerate(cases):
                identity = case.get('id', case.get('language'))
                assert identity is not None
                total['cases'] += 1
                total['caseIds'].append(identity)
                if case is not row:
                    total['errors'] += errors_at(case, f'{name}/results/{row_index}/cases/{case_index}')
                incomplete = not complete_case(name, case)
                total['incomplete'] += int(incomplete)
                if incomplete:
                    expected_incomplete.append(case)
                seen = set()
                for observation in case['observations']:
                    key = (observation.get('phase'), observation['property'])
                    assert key not in seen, (name, label, identity, 'duplicate observation', key)
                    seen.add(key)
                    assert 'actual' in observation and 'expected' in observation
                    matched = equivalent(observation['actual'], observation['expected'], sorted_keys=name == 'table')
                    verdict = 'PASS' if matched else 'FAIL'
                    assert observation['status'] == verdict, (name, label, identity, key, 'incorrect verdict')
                    total['observations'] += 1
                    if not matched:
                        total['failures'] += 1
                        expected_failures.append({'id': identity, **observation} if name == 'table' else observation)
            if 'failures' in row:
                assert equivalent(row['failures'], expected_failures)
            if 'incompleteCases' in row:
                assert equivalent(row['incompleteCases'], expected_incomplete)

        for label, total in totals.items():
            assert len(total['caseIds']) == len(set(total['caseIds'])), (name, label, 'duplicate case')
            if name in expected_ids:
                expected = ['V1_PUBLIC_FOCUS_NATIVE_NAVIGATION'] if name == 'focus' and label == 'v1' else expected_ids[name]
                assert total['caseIds'] == expected
            if name == 'focus':
                assert total['unsupported'] == (7 if label == 'v1' else 0)
            else:
                assert total['unsupported'] == 0
            wrapper_summary = command['sources'][label]
            for key in ['cases', 'observations', 'failures', 'errors', 'incomplete', 'unsupported']:
                assert wrapper_summary[key] == total[key], (name, label, key, wrapper_summary[key], total[key])
        assert set(totals) == set(labels)
        candidate = totals['candidate']
        candidate_pass = (top_errors == 0 and candidate['cases'] > 0 and candidate['observations'] > 0
                          and not any(candidate[key] for key in ['failures', 'errors', 'incomplete', 'unsupported']))
        assert command['candidatePass'] is candidate_pass
        if 'candidatePass' in data:
            assert data['candidatePass'] is candidate_pass
        raw_failed = top_errors > 0 or any(total[key] for total in totals.values() for key in ['failures', 'errors', 'incomplete'])
        assert command['exitCode'] == (1 if raw_failed else 0)
        assert top_errors == 0
        assert all(total['errors'] == total['incomplete'] == 0 for total in totals.values())
        reports.append({'suite': name, 'outputSha256': digest(raw), 'outputSize': len(raw),
                        'stderrSha256': digest(stderr), 'runner': runner, 'runnerSha256': runner_hash,
                        **({'fixture': fixtures[name], 'fixtureSha256': data['fixtureSha256']} if name in fixtures else {}),
                        'rawExitCode': command['exitCode'], 'candidatePass': candidate_pass,
                        'topLevelErrors': top_errors, 'sourceSummaries': dict(totals),
                        'moduleHashRecords': sum(len(entry['loaded']) for entry in data['sources']),
                        'dependencyHashRecords': len(data['dependencyFiles']),
                        'versionRecords': len(data.get('dependencyVersions', {}))})
        assert path.read_bytes() == raw
    assert manifest['candidatePass'] is all(report['candidatePass'] for report in reports)
    assert manifest_path.read_bytes() == manifest_bytes
    assert git('rev-parse', 'b09c0079c5f2ebbbc68264b4892ce5f8bb8ae63c^{tree}') == git('rev-parse', 'b856d85e13848d7129fb3f2ad96fd8cb9e2b7d13^{tree}')
    after = {'head': git('rev-parse', 'HEAD').decode().strip(),
             'refsSha256': digest(git('for-each-ref', '--format=%(refname) %(objectname)')),
             'trackedStatus': git('status', '--porcelain=v1', '--untracked-files=no').decode()}
    result = {
        'status': 'PASS', 'startedAt': started, 'finishedAt': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'source': source, 'tree': manifest['source']['tree'], 'resultsDirectory': str(directory),
        'manifestSha256': digest(manifest_bytes), 'scriptSha256': digest(Path(__file__).read_bytes()),
        'suites': reports, 'verdictsRecomputed': sum(total['observations'] for report in reports for total in report['sourceSummaries'].values()),
        'candidateCases': sum(report['sourceSummaries']['candidate']['cases'] for report in reports),
        'candidateObservations': sum(report['sourceSummaries']['candidate']['observations'] for report in reports),
        'candidateFailures': sum(report['sourceSummaries']['candidate']['failures'] for report in reports),
        'historicalRawFailures': sum(total['failures'] for report in reports for label, total in report['sourceSummaries'].items() if label != 'candidate'),
        'sourceModuleHashRecords': len(all_module_records),
        'uniqueSourceModuleKeys': len({(record['source'], record['path']) for record in all_module_records}),
        'dependencyHashRecords': len(all_dependency_records),
        'uniqueDependencyFiles': len({record['path'] for record in all_dependency_records}),
        'versionRecords': len(all_version_records), 'uniqueVersionPackages': len({record['package'] for record in all_version_records}),
        'moduleRecords': all_module_records, 'dependencyRecords': all_dependency_records, 'dependencyVersionRecords': all_version_records,
        'errorChannelsChecked': all_error_channels, 'allErrorChannelsEmpty': True,
        'codePreFixPublishedTreeMatchesOriginal': True, 'mainBefore': before, 'mainAfter': after,
        'mainUnchangedDuringReview': before == after, 'writesToRepository': 0,
        'scope': 'Independent artifact, hash, verdict, count and completion audit. It does not independently re-execute browser behavior or certify every expected value as the complete product specification. Unsupported v1 focus API rows are kept separate from executed cases.',
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ['status', 'verdictsRecomputed', 'candidateCases', 'candidateObservations',
                                                 'candidateFailures', 'historicalRawFailures', 'sourceModuleHashRecords',
                                                 'uniqueSourceModuleKeys', 'dependencyHashRecords', 'uniqueDependencyFiles',
                                                 'versionRecords', 'mainUnchangedDuringReview']}))


if __name__ == '__main__':
    main()
