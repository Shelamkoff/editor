# Independent fifth scoped-comparison audit

Result: **PASS**, 2026-10-30. Reviewed source `a7dc4172198dea9c641f5de41d4331e5a94a17b4`, tree `500d124440261953986dac14afa51d444f35ac5c`.

The five raw comparisons in `test-results/scoped-fifth-lz2cd717` were checked independently of their supervisor summaries. All 5,509 observation verdicts agree with recomparison of the retained actual and expected values. Table uses its declared stable object-key comparison; the other fixtures use the recorded JSON ordering. Duplicate case IDs and phase/property observations are rejected.

| Comparison | Candidate cases | Candidate observations | Candidate failures | Historical raw failures |
| --- | ---: | ---: | ---: | --- |
| Public focus | 7 | 147 | 0 | v1 1; specification baseline 8 |
| Table settings | 14 | 1,346 | 0 | v1 38; specification baseline 0 |
| Code language/highlighting | 3 | 186 | 0 | v1 8; specification baseline 12; pre-fix 12 |
| Formatting host ownership | 10 | 70 | 0 | v1 30; specification baseline 5 |
| Link ownership | 13 | 113 | 0 | v1 33; specification baseline 27 |

The scoped candidate total is 47 cases and 1,862 observations, with zero failures. The 174 historical failures retain their raw status and the five raw exit codes remain 1. These totals do not add to or replace overlapping integration-suite counts.

The v1 focus comparison executes one supported navigation control with 20 observations. Seven unavailable keyed/numeric focus API scenarios remain explicitly `UNSUPPORTED`; they are not counted as executed passes or incomplete executed cases.

## Completion, errors and identities

All executed cases complete their required phases. Focus completes five named phases; Code completes seven. Table completes eight phases for ordinary changes and the six expected phases for minimum-size no-op controls. The two direct-tool suites report completion explicitly.

Every top-level, result-level and case-level error channel is checked, including Table result-level `errors` beside `cases`. All are empty. The raw `candidatePass` values where present and all supervisor candidate summaries agree with the independent result. Table's known supervisor omission of result-level errors does not alter this run's outcome, because the raw arrays are empty and the independent audit includes them.

The audit checks 1,208 production-module hash records covering 602 unique source/path pairs, 84 dependency hash records covering 72 files, 24 dependency version records, five runner hashes and two fixture hashes. It verifies source tree identities where recorded, common candidate HEAD before/after, wrapper output/stderr hashes, and the published pre-fix Code tree's equivalence to original `b856d85e`.

The main HEAD, refs digest and tracked status remain unchanged during review. No source file or raw result is edited. `review.json` retains each source summary, every checked hash record and all checked error-channel values.

## Audit guard checks

`check_audit_guards.py` creates temporary copies and injects two inconsistencies after updating only the copied output hash: a Table source-level error beside a populated `cases` array, and a false raw Code `candidatePass` while observations remain green. The independent reviewer must reject both copies at the relevant error/count or candidate-result assertion. The original evidence is untouched; outcomes are stored in `audit-guards.json`.

## Reproduction

```sh
python review_scoped.py --repo /path/to/editor --results /path/to/editor/test-results/scoped-fifth-lz2cd717 --output /tmp/scoped-review.json
python check_audit_guards.py --repo /path/to/editor --results /path/to/editor/test-results/scoped-fifth-lz2cd717 --output /tmp/scoped-review-guards.json
```

Use the frozen source and its dependency installation. This is an independent artifact, hash, verdict, count and completion audit. It does not independently rerun the browser interactions or certify every fixture expectation as complete product parity.
