#!/usr/bin/env python3
"""Check the known summary blind spot on isolated copies, never on raw evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--results', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
reviewer = Path(__file__).with_name('review_scoped.py')
cases = []
for name, suite in [('source_row_error_with_cases', 'table'), ('raw_candidate_pass_disagreement', 'code')]:
    with tempfile.TemporaryDirectory(prefix='scoped-review-guard-') as temporary:
        temporary = Path(temporary)
        for source in args.results.iterdir():
            if source.suffix in ['.json', '.stderr']:
                shutil.copyfile(source, temporary / source.name)
        path = temporary / (suite + '.json')
        data = json.loads(path.read_text())
        if name == 'source_row_error_with_cases':
            next(row for row in data['results'] if row['source'] == 'candidate')['errors'].append('Synthetic review guard: source-level error beside cases')
        else:
            data['candidatePass'] = False
        changed = (json.dumps(data, indent=2) + '\n').encode('utf-8')
        path.write_bytes(changed)
        manifest_path = temporary / 'manifest.json'
        manifest = json.loads(manifest_path.read_text())
        next(command for command in manifest['commands'] if command['name'] == suite)['outputSha256'] = hashlib.sha256(changed).hexdigest()
        manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
        result = subprocess.run([sys.executable, str(reviewer), '--repo', str(args.repo), '--results', str(temporary),
                                 '--output', str(temporary / 'unexpected-pass.json')], capture_output=True, text=True)
        assert result.returncode != 0, name + ' was incorrectly accepted'
        expected = "('table', 'candidate', 'errors', 0, 1)" if suite == 'table' else "assert data['candidatePass'] is candidate_pass"
        assert expected in result.stderr, (name, result.stderr)
        assert not (temporary / 'unexpected-pass.json').exists()
        cases.append({'name': name, 'status': 'PASS', 'auditRejectedCopy': True,
                      'auditExitCode': result.returncode, 'stderr': result.stderr,
                      'changedCopySha256': hashlib.sha256(changed).hexdigest()})
output = {'status': 'PASS', 'cases': cases, 'rawEvidenceChanged': False,
          'scriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'reviewerSha256': hashlib.sha256(reviewer.read_bytes()).hexdigest()}
args.output.write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'rejectedInjectedErrors': len(cases)}))
