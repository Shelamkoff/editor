# Independent first-batch publication review

Result: **PASS**, 2026-10-30. The review reads the committed map and fetched local Git objects. It makes no network request and writes neither the main worktree nor its refs.

Reviewed map: `scripts/parity/checkpoints/2026-10-30/publication/source-map-first-batch.json`.

- Base: `355577fce341e77bead7d69705744db724f1b79f`.
- Original tip: `eb82cb8d5d2842f8260d1f2934df45ce0676b9b6`.
- Published tip: `132b59923de9bc6b1f3b3f73ba48c6d1f040826a`.
- Review checkout: `a7dc4172198dea9c641f5de41d4331e5a94a17b4`.

All 17 mappings have identical source/published trees and empty file diffs, so runtime files, tests and documents retain the same bytes. Every parent was checked against both the preceding mapping and the actual commit header. The 17-element original and published history ranges exactly match the map order. Commit messages are unchanged; author/committer metadata and the mapped parent identities differ as recorded.

The reviewer independently calculates Git commit SHA-1 from the object header and raw bytes. All original raw objects reproduce their stated source IDs and match the existing source objects byte for byte; all published raw objects independently reproduce their published IDs.

## Recovery from a fresh object directory

The reviewer exports only the object closure reachable from the published tip into a newly initialized temporary bare repository. Its imported pack contains 25,562 objects and 38,737,648 bytes. The original preservation branch is excluded, no alternate object directory is configured, and there are no refs before or after recovery.

All 17 original commit IDs are confirmed absent before restoration. Writing only the map's raw commit objects restores those 17 IDs and adds exactly those objects. Their raw bytes, trees and ordered parent chain match the originals. The recovered commits have empty file diffs against their published counterparts. `git fsck --connectivity-only --no-reflogs --no-dangling` exits 0; its only notices explain the intentionally unborn HEAD and absence of refs.

The main HEAD, complete refs digest and tracked worktree status are identical before and after review. The temporary repository and pack are removed after verification. Detailed per-commit checks and hashes are in `review.json`.

## Reproduction

Use a repository containing the fetched published objects and the map. Set the paths for the local checkout and review script:

```sh
python review_publication.py --repo /path/to/editor --map /path/to/editor/scripts/parity/checkpoints/2026-10-30/publication/source-map-first-batch.json --output /tmp/publication-review.json
```

This verifies source equivalence and reconstruction. It does not recheck current remote-ref freshness, add a browser/test gate or accept any preservation scenario.
