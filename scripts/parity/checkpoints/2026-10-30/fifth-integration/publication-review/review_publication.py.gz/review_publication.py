#!/usr/bin/env python3
"""Read-only review of a publication map and isolated original-commit recovery."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time


def digest(data):
    return hashlib.sha256(data).hexdigest()


def commit_id(data):
    return hashlib.sha1(b'commit ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()


def parse_commit(data):
    headers, message = data.split(b'\n\n', 1)
    result = {}
    for line in headers.split(b'\n'):
        if line.startswith(b' '):
            continue
        key, value = line.split(b' ', 1)
        result.setdefault(key.decode('ascii'), []).append(value.decode('utf-8'))
    return result, message


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--map', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    map_path = args.map.resolve()
    map_bytes = map_path.read_bytes()
    mapping = json.loads(map_bytes)
    started = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

    env = os.environ.copy()
    for name in ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY',
                 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_COMMON_DIR', 'GIT_NAMESPACE']:
        env.pop(name, None)
    env.update(GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1')

    def git(*parts, input=None, check=True):
        return subprocess.run(['git', '-C', str(repo), *parts], input=input,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, check=check)

    def read(*parts):
        return git(*parts).stdout

    before = {
        'head': read('rev-parse', 'HEAD').decode().strip(),
        'refsSha256': digest(read('for-each-ref', '--format=%(refname) %(objectname)')),
        'trackedStatus': read('status', '--porcelain=v1', '--untracked-files=no').decode(),
    }
    entries = mapping['commits']
    assert len(entries) == 17, 'Expected the stated first batch of 17 commits'
    assert len({entry['local'] for entry in entries}) == len(entries)
    assert len({entry['published'] for entry in entries}) == len(entries)
    local_parent = published_parent = mapping['originalBase']
    checks = []
    for index, entry in enumerate(entries):
        raw = entry['rawCommit'].encode('utf-8')
        headers, message = parse_commit(raw)
        local_raw = read('cat-file', 'commit', entry['local'])
        published_raw = read('cat-file', 'commit', entry['published'])
        published_headers, published_message = parse_commit(published_raw)
        assert commit_id(raw) == entry['local'], f'Raw source SHA mismatch at {index}'
        assert raw == local_raw, f'Raw source bytes differ from local Git at {index}'
        assert commit_id(published_raw) == entry['published'], f'Published SHA mismatch at {index}'
        assert entry['parentLocal'] == local_parent
        assert entry['parentPublished'] == published_parent
        assert headers['parent'] == [local_parent]
        assert published_headers['parent'] == [published_parent]
        assert headers['tree'] == published_headers['tree'] == [entry['tree']]
        assert message == published_message == entry['message'].encode('utf-8')
        changed_paths = read('diff', '--name-only', '-z', entry['local'], entry['published']).split(b'\0')
        changed_paths = [path.decode('utf-8') for path in changed_paths if path]
        assert changed_paths == [], f'Publication changed tree contents at {index}'
        checks.append({
            'index': index + 1, 'source': entry['local'], 'published': entry['published'],
            'tree': entry['tree'], 'sourceParent': local_parent, 'publishedParent': published_parent,
            'sourceRawSha256': digest(raw), 'publishedRawSha256': digest(published_raw),
            'sourceGitSha1Matches': True, 'sourceRawMatchesExistingObject': True,
            'publishedGitSha1Matches': True, 'treesIdentical': True, 'parentsOrdered': True,
            'messagesIdentical': True, 'changedPaths': changed_paths,
            'metadataFieldsChanged': [name for name in sorted(set(headers) | set(published_headers))
                                      if headers.get(name) != published_headers.get(name)],
        })
        local_parent, published_parent = entry['local'], entry['published']
    assert local_parent == mapping['originalHead']
    assert published_parent == mapping['publishedHead']
    published_chain = read('rev-list', '--reverse', mapping['originalBase'] + '..' + mapping['publishedHead']).decode().splitlines()
    assert published_chain == [entry['published'] for entry in entries]
    local_chain = read('rev-list', '--reverse', mapping['originalBase'] + '..' + mapping['originalHead']).decode().splitlines()
    assert local_chain == [entry['local'] for entry in entries]

    # Export only the object closure reachable from the fetched published tip.
    # The original preservation branch and its original commit objects must not
    # participate in this isolated recovery test.
    published_objects = set(read('rev-list', '--objects', '--no-object-names', mapping['publishedHead']).decode().splitlines())
    assert not ({entry['local'] for entry in entries} & published_objects)
    assert all(entry['tree'] in published_objects for entry in entries)
    with tempfile.TemporaryDirectory(prefix='publication-object-recovery-') as temporary:
        temporary = Path(temporary)
        fresh = temporary / 'fresh.git'
        subprocess.run(['git', 'init', '--bare', '--quiet', str(fresh)], env=env, check=True)
        fresh_env = env.copy()
        fresh_env.update(GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL=os.devnull)

        def fresh_git(*parts, input=None, check=True):
            return subprocess.run(['git', '--git-dir=' + str(fresh), *parts], input=input,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  env=fresh_env, check=check)

        archive = temporary / 'published.pack'
        with archive.open('wb') as target:
            packed = subprocess.run(['git', '-C', str(repo), 'pack-objects', '--stdout', '--revs'],
                                    input=(mapping['publishedHead'] + '\n').encode('ascii'),
                                    stdout=target, stderr=subprocess.PIPE, env=env, check=True)
        with archive.open('rb') as packed_input:
            imported = subprocess.run(['git', '--git-dir=' + str(fresh), 'index-pack', '--strict', '--stdin'],
                                      stdin=packed_input, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                      env=fresh_env, check=True)
        assert not (fresh / 'objects/info/alternates').exists()
        assert fresh_git('for-each-ref').stdout == b''
        before_objects = set(fresh_git('cat-file', '--batch-all-objects', '--batch-check=%(objectname)').stdout.decode().splitlines())
        assert before_objects == published_objects
        absent = []
        for entry in entries:
            exists = fresh_git('cat-file', '-e', entry['local'] + '^{commit}', check=False)
            assert exists.returncode != 0, 'Original commit unexpectedly present before recovery'
            absent.append(entry['local'])
        for entry in entries:
            raw = entry['rawCommit'].encode('utf-8')
            restored = fresh_git('hash-object', '-t', 'commit', '-w', '--stdin', input=raw).stdout.decode().strip()
            assert restored == entry['local']
            assert fresh_git('cat-file', 'commit', restored).stdout == raw
            assert fresh_git('rev-parse', restored + '^{tree}').stdout.decode().strip() == entry['tree']
            assert fresh_git('diff', '--name-only', '-z', restored, entry['published']).stdout == b''
        after_objects = set(fresh_git('cat-file', '--batch-all-objects', '--batch-check=%(objectname)').stdout.decode().splitlines())
        assert after_objects - before_objects == {entry['local'] for entry in entries}
        assert before_objects - after_objects == set()
        assert fresh_git('for-each-ref').stdout == b''
        recovered_chain = fresh_git('rev-list', '--reverse', mapping['originalBase'] + '..' + mapping['originalHead']).stdout.decode().splitlines()
        assert recovered_chain == local_chain
        fsck = fresh_git('fsck', '--connectivity-only', '--no-reflogs', '--no-dangling')
        recovery = {
            'publishedObjectsImported': len(published_objects), 'publishedPackBytes': archive.stat().st_size,
            'publishedPackSha256': digest(archive.read_bytes()), 'noAlternateObjectDirectories': True,
            'refsBeforeAndAfter': [], 'originalObjectsAbsentBefore': absent,
            'originalObjectsRestored': len(entries), 'onlyExpectedObjectsAdded': True,
            'restoredRawBytesIdentical': True, 'restoredTreesIdentical': True,
            'restoredChainMatches': True, 'connectivityFsckExit': fsck.returncode,
            'connectivityFsckStdout': fsck.stdout.decode(), 'connectivityFsckStderr': fsck.stderr.decode(),
        }
    after = {
        'head': read('rev-parse', 'HEAD').decode().strip(),
        'refsSha256': digest(read('for-each-ref', '--format=%(refname) %(objectname)')),
        'trackedStatus': read('status', '--porcelain=v1', '--untracked-files=no').decode(),
    }
    assert map_path.read_bytes() == map_bytes
    result = {
        'status': 'PASS', 'startedAt': started,
        'finishedAt': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'mapPath': str(map_path), 'mapSha256': digest(map_bytes),
        'scriptSha256': digest(Path(__file__).read_bytes()), 'repository': mapping['repository'],
        'branch': mapping['branch'], 'base': mapping['originalBase'],
        'originalHead': mapping['originalHead'], 'publishedHead': mapping['publishedHead'],
        'checkedPairs': len(checks), 'checks': checks, 'isolatedRecovery': recovery,
        'mainBefore': before, 'mainAfter': after, 'mainUnchangedDuringReview': before == after,
        'networkRequests': 0, 'sourceFileChanges': 0, 'mainRefWrites': 0,
        'scope': 'Local fetched Git objects and map only. Remote-ref freshness and caller authorization are not re-verified. All mapped trees, including runtime and tests, are byte-identical; this adds no runtime execution gate.',
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ['status', 'checkedPairs', 'mainUnchangedDuringReview', 'publishedHead']}))
    print(json.dumps({'isolatedObjects': recovery['publishedObjectsImported'],
                      'recovered': recovery['originalObjectsRestored'], 'fsck': recovery['connectivityFsckExit']}))


if __name__ == '__main__':
    main()
