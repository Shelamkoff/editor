from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time

repo=Path('/workspace/scratch/2231de9d6b0d/work-table-keyboard-seventh')
output=repo/'test-results/table-keyboard-seventh-final'
output.mkdir(parents=True,exist_ok=True)
jobs={
 'native':(['node','tests/browser/physical-history.mjs'],{'EDITOR_NATIVE_PAGE':'native-plugin-parity.html','EDITOR_NATIVE_FILTER':'Table keyboard parity'}),
 'terminal':(['node','tests/browser/physical-history.mjs'],{'EDITOR_NATIVE_PAGE':'native-plugin-parity.html','EDITOR_NATIVE_FILTER':'Table Enter retains the active mark'}),
 'unit':(['node','--test','core/NativeInputController.authoredBreak.test.js'],{}),
 'typecheck':(['npm','run','typecheck'],{}),
 'comparison':(['node','scripts/parity/table-keyboard-parity.mjs'],{}),
}
name=sys.argv[1];command,extra=jobs[name]
env=os.environ.copy()
for key in ['EDITOR_NATIVE_PAGE','EDITOR_NATIVE_FILTER','EDITOR_BROWSER_PAGE','EDITOR_BROWSER_ROOT','EDITOR_TABLE_KEYBOARD_FILTER','EDITOR_CANDIDATE_SHA']:
 env.pop(key,None)
env.update(EDITOR_CHROME_PATH='/tmp/rector-chrome/opt/google/chrome/chrome',EDITOR_PLAYWRIGHT_PATH='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs',**extra)
def git(*parts):return subprocess.check_output(['git',*parts],cwd=repo)
def head():return git('rev-parse','HEAD').decode().strip()
def clean():return not git('diff','--name-only','HEAD').strip()
def sha(payload):return hashlib.sha256(payload).hexdigest()
before=head();assert before=='3a16cf9fe64046780d4573464387dd2eb864b80e';assert clean()
source_paths=['core/LogicalSelection.js','core/NativeInputController.js','core/NativeInputController.authoredBreak.test.js','tests/browser/table-keyboard-parity-fixture.js','tests/browser/regressions/table-keyboard-native.js','scripts/parity/table-keyboard-parity.mjs']
hashes={path:sha((repo/path).read_bytes()) for path in source_paths}
stdout=output/(name+('.json' if name=='comparison' else '.log'));stderr=output/(name+'.stderr')
record={'name':name,'headBefore':before,'trackedCleanBefore':True,'command':command,'environment':extra,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':hashes,'status':'running'}
meta=output/(name+'.meta.json');meta.write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic()
with stdout.open('w') as out,stderr.open('w') as err:
 result=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=err)
after=head();unchanged=before==after and clean() and hashes=={path:sha((repo/path).read_bytes()) for path in source_paths}
record.update(status='complete',actualExitCode=result.returncode,elapsedSeconds=round(time.monotonic()-start,3),completedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),headAfter=after,trackedCleanAfter=clean(),sourceUnchanged=unchanged,stdoutFile=stdout.name,stderrFile=stderr.name,stdoutSha256=sha(stdout.read_bytes()),stderrSha256=sha(stderr.read_bytes()))
meta.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'job':name,'exitCode':result.returncode,'sourceUnchanged':unchanged,'metadata':str(meta)}),flush=True)
sys.exit(0 if unchanged else 2)
