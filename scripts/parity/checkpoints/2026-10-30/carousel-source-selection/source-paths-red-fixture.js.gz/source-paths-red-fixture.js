import { createCarouselPlugin } from '../../../plugins/carousel/index.js'
import { createParagraphPlugin } from '../../../plugins/paragraph/index.js'
import { test, make, para, blockElement, editorHolder, pause, equal, assert } from './harness.js'
import { clickNative, dispatchKey, printable } from '../native-input-helpers.js'

const pixel = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAAFklEQVR4nGO4ZmVPEmIY1TCqYfhqAACwH08Q21f11gAAAABJRU5ErkJggg=='
const video = new URL('../carousel-roundtrip-16x16.webm', import.meta.url).href
const options = { loop: false, autoplay: false, autoplayDelay: 3000, navigation: true,
  pagination: true, thumbnails: false, aspectRatio: '16 / 9' }

// A completed source batch selects its first new slide in the pinned v1.
// The caption edit and append remain two distinct keyboard history actions.
for (const source of ['source batch', 'URL source', 'HTML source']) {
  test(`Carousel ${source} selects its first added mixed-media slide and retains native history`, async () => {
  const initial = [
    { id: 'alpha', type: 'image', src: pixel, alt: 'Alpha image', caption: 'Alpha' },
    { id: 'bravo', type: 'video', src: video, poster: pixel, alt: 'Bravo video', caption: 'Bravo' },
    { id: 'charlie', type: 'html', html: '<p>Charlie HTML</p>', caption: 'Charlie' },
  ]
  const batch = [
    { id: 'delta', type: 'video', src: video, poster: pixel, alt: 'Delta video', caption: 'Delta' },
    { id: 'echo', type: 'html', html: '<p>Echo HTML</p>', caption: 'Echo' },
  ]
  let calls = 0
  const definition = createCarouselPlugin({ actions: [{ label: 'Append proof slides', handler: async () => {
    calls++; return structuredClone(batch)
  } }] })
  const before = [para('before', 'Before'), { id: 'carousel', type: 'carousel', dataVersion: 1,
    data: { slides: structuredClone(initial), options } }, para('after', 'After')]
  const original = structuredClone(before)
  const editor = make(original, { plugins: [createParagraphPlugin(), definition], injectStyles: true })
  editorHolder(editor).style.width = '640px'
  const root = () => blockElement(editor, 'carousel')
  const field = () => root().querySelector('.oe-carousel-block__caption')
  const button = text => [...root().querySelectorAll('button')].find(element => element.textContent.trim() === text)
  const inputEvents = [], clicks = [], shortcuts = []
  root().addEventListener('input', event => inputEvents.push({ trusted: event.isTrusted, inputType: event.inputType, data: event.data }))
  root().addEventListener('click', event => clicks.push({ trusted: event.isTrusted, text: event.target.closest('button')?.textContent.trim() }))
  root().addEventListener('keydown', event => { if (event.key.toLowerCase() === 'z') shortcuts.push(event.isTrusted) })
  await clickNative(field())
  await dispatchKey('End', 'End', 35)
  await printable('X')
  const edited = structuredClone(before); edited[1].data.slides[0].caption = 'AlphaX'
  equal(editor.save().blocks, edited)
  equal(inputEvents, [{ trusted: true, inputType: 'insertText', data: 'X' }])
  await clickNative(button('Add'))
  let added = batch
  if (source === 'source batch') await clickNative(button('Append proof slides'))
  else {
    await clickNative(button(source === 'URL source' ? 'URL' : 'HTML'))
    const surface = root().querySelector('.oe-source-editor:not([aria-hidden="true"])')
    const value = source === 'URL source' ? video : '<p>Added HTML</p>'
    await clickNative(surface.querySelector('.oe-source-editor__field'))
    await window.__testInput('Input.insertText', { text: value })
    await clickNative(surface.querySelector('button[type="submit"]'))
    const id = editor.save().blocks[1].data.slides[3]?.id
    assert(typeof id === 'string' && id && !initial.some(slide => slide.id === id), 'The source must allocate a new stable slide ID')
    added = [source === 'URL source'
      ? { id, type: 'video', src: video, poster: '', alt: '', caption: '' }
      : { id, type: 'html', html: value, caption: '' }]
    equal(inputEvents.slice(1), [{ trusted: true, inputType: 'insertText', data: value }])
  }
  await pause(50)
  const appended = structuredClone(edited); appended[1].data.slides.push(...structuredClone(added))
  equal(editor.save().blocks, appended, 'A source batch must append all accepted media without changing existing slides')
  equal(calls, source === 'source batch' ? 1 : 0)
  equal(field().dataset.slideId, added[0].id, 'A source left the previous slide active instead of its first appended slide')
  equal(field().textContent, added[0].caption)
  equal(root().querySelector('.oe-carousel-block__counter').textContent, `4 / ${3 + added.length}`)
  assert(root().contains(document.activeElement), 'Appending slides lost keyboard history ownership')
  if (source === 'source batch') equal(clicks.filter(event => event.text === 'Append proof slides'), [{ trusted: true, text: 'Append proof slides' }])
  await dispatchKey('z', 'KeyZ', 90, 2)
  equal(editor.save().blocks, edited)
  await dispatchKey('z', 'KeyZ', 90, 2)
  equal(editor.save().blocks, before)
  equal([editor.canUndo, editor.canRedo], [false, true])
  await dispatchKey('z', 'KeyZ', 90, 10)
  equal(editor.save().blocks, edited)
  await dispatchKey('z', 'KeyZ', 90, 10)
  equal(editor.save().blocks, appended)
  equal([editor.canUndo, editor.canRedo], [true, false])
  equal(shortcuts, [true, true, true, true])
  equal(calls, source === 'source batch' ? 1 : 0, 'History replay must not repeat the source action')
  equal(original, before, 'Source actions and history must not change caller input')
  })
}
