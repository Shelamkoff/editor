from pathlib import Path
import subprocess, json, datetime, hashlib, os

root = Path('/workspace/scratch/40cb45010ec4/rector-performance-completion')
base = Path('/workspace/scratch/40cb45010ec4/rector-performance-baseline')
out = Path('/workspace/scratch/40cb45010ec4/rector-performance-evidence')

def source(path):
    return {
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=path, text=True).strip(),
        'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=path, text=True).strip(),
        'status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=path, text=True),
        'patchSha256': hashlib.sha256(subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=path)).hexdigest(),
    }

command = ['node', 'benchmarks/structural-authoring.mjs', str(base), str(root), str(out/'structural-final')]
overrides = {
    'EDITOR_CHROME_PATH': '/tmp/rector-chrome/opt/google/chrome/chrome',
    'EDITOR_PLAYWRIGHT_PATH': '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs',
    'EDITOR_DEPENDENCIES_ROOT': '/workspace/scratch/40cb45010ec4/editor/node_modules',
}
before = {'baseline': source(base), 'candidate': source(root)}
assert before['baseline']['head'] == '69c8425e0081fde69cf5176ccb73d032720c15fc'
assert before['candidate']['head'] == '11d5b5d0d5a900b5a4f2e7ae0fd0ff5cd4128995'
assert all(not record['status'] for record in before.values())
manifest = {'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'state': 'running',
    'command': command, 'environmentOverrides': overrides, 'sourceBefore': before,
    'quietWindow': 'Root and both sibling agents confirmed browser/test runners stopped before this run.'}
(out/'structural-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
env = dict(os.environ); env.update(overrides)
with (out/'structural.log').open('wb') as log:
    result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
manifest.update({'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'completed', 'exitCode': result.returncode,
    'sourceAfter': {'baseline': source(base), 'candidate': source(root)}})
manifest['sourceUnchanged'] = manifest['sourceAfter'] == manifest['sourceBefore']
(out/'structural-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
