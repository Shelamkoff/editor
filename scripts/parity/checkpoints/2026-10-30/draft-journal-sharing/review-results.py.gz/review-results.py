from pathlib import Path
import hashlib, json, math, subprocess, datetime

root = Path('/workspace/scratch/40cb45010ec4/rector-performance-completion')
out = Path('/workspace/scratch/40cb45010ec4/rector-performance-evidence')
raw = out/'structural-final/results.json'
data = json.loads(raw.read_text())
digest = lambda value: hashlib.sha256(value).hexdigest()
def percentile(values, fraction): return sorted(values)[min(len(values)-1, math.floor(len(values)*fraction))]
def stats(values):
    return {'count': len(values), 'p50': percentile(values, .5), 'p95': percentile(values, .95),
        'min': min(values), 'max': max(values)} if values else None

assert data['outcome'] == 'passed' and data['sourceUnchanged']
assert not data['pageErrors'] and not data['serverErrors']
timings = {(r['variant'], r['shape'], r['kind']): r for r in data['timings']}
attribution = {(r['variant'], r['shape'], r['kind']): r for r in data['attribution']}
timing_rows, counters, allocation = [], [], []
stored_stat_checks = 0
for (variant, shape, kind), before in timings.items():
    if variant != 'baseline': continue
    after = timings[('candidate', shape, kind)]
    assert before['metadata'] == after['metadata']
    assert len(before['rawSamples']) == len(after['rawSamples']) == 21
    for phase_index, phase in enumerate(before['rawSamples'][0]):
        phase_name = phase['kind']
        metrics = {}
        for metric in ['synchronousMs', 'notificationMs', 'settledRenderOpportunityMs', 'driverRoundTripMs']:
            a = [s[phase_index][metric] for s in before['rawSamples']]
            b = [s[phase_index][metric] for s in after['rawSamples']]
            assert all(s[phase_index]['kind'] == phase_name for s in before['rawSamples']+after['rawSamples'])
            if all(value is None for value in a+b): metrics[metric] = None; continue
            assert all(isinstance(value, (int, float)) and math.isfinite(value) for value in a+b)
            deltas = [y-x for x,y in zip(a,b)]
            computed_a, computed_b = stats(a), stats(b)
            if metric != 'driverRoundTripMs':
                for source, computed in [(before, computed_a), (after, computed_b)]:
                    saved = source['summaries'][phase_index]['metrics'][metric]
                    assert all(saved[key] == computed[key] for key in ['p50', 'p95', 'min', 'max'])
                    stored_stat_checks += 4
            metrics[metric] = {'baseline': computed_a, 'candidate': computed_b,
                'pairedDelta': stats(deltas), 'candidateFasterPairs': sum(value < 0 for value in deltas),
                'candidateSlowerPairs': sum(value > 0 for value in deltas), 'exactPairedDeltas': deltas}
        timing_rows.append({'shape': shape, 'command': kind, 'phase': phase_name, 'metrics': metrics})
    a = attribution[('baseline',shape,kind)]; b = attribution[('candidate',shape,kind)]
    for first, second in zip(a['counted'], b['counted']):
        assert first['kind'] == second['kind']
        delta = {name: first['counters'][name] - second['counters'][name] for name in first['counters']}
        if kind.startswith('noop') or first['kind'] in ['undo','redo']:
            assert all(value == 0 for value in delta.values()), (shape,kind,first['kind'],delta)
        else:
            assert delta['jsonRecordVisits'] > 0
            assert all(delta[name] == 0 for name in ['childListsRead','nodeClones','elementsCreated'])
        counters.append({'shape':shape,'command':kind,'phase':first['kind'],
            'baseline':first['counters'],'candidate':second['counters'],'avoided':delta})
    allocation.append({'shape':shape,'command':kind,
        'baselineSampledBytes':a['allocation']['sampledBytes'],
        'candidateSampledBytes':b['allocation']['sampledBytes'],
        'changePercent':(b['allocation']['sampledBytes']/a['allocation']['sampledBytes']-1)*100})

source_checks = 0
for source in data['sources']:
    for path, expected in source['files'].items():
        content = subprocess.check_output(['git','show',source['sha']+':'+path],cwd=root)
        assert digest(content) == expected, (source['label'], path)
        source_checks += 1
dependency_checks = 0
for path, expected in data['dependencies']['files'].items():
    assert digest((Path(data['dependencies']['root'])/path).read_bytes()) == expected, path
    dependency_checks += 1
assert digest((root/'benchmarks/structural-authoring.mjs').read_bytes()) == data['runnerSha256']
assert digest((root/'tests/browser/structural-authoring-fixture.js').read_bytes()) == data['fixtureSha256']
for entry in data['memory']:
    assert entry['observation']['retainedReleasedObjects'] == 0
    assert entry['observation']['livePositiveControl']
inventory = {str(path.relative_to(out/'structural-final')):{'bytes':path.stat().st_size,'sha256':digest(path.read_bytes())}
    for path in sorted((out/'structural-final').iterdir()) if path.is_file()}
summary = {'reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewerSha256':digest(Path(__file__).read_bytes()), 'sourceRecordHashesVerified':source_checks,
    'dependencyHashesVerified':dependency_checks,'storedPercentileFieldsVerified':stored_stat_checks,
    'sourceUnchanged':data['sourceUnchanged'],'outcome':data['outcome'],
    'startedAt':data['startedAt'],'finishedAt':data['finishedAt'],
    'sources':[{k:v for k,v in source.items() if k!='files'} for source in data['sources']],
    'environment':data['environment'],'boundaries':data['boundaries'],
    'warmup':data['warmup'],'repeats':data['repeats'],
    'controls':{'total':len(data['controls']),'ordinary':sum(c['outcome']=='passed' for c in data['controls']),
        'sensitivity':sum(c['outcome']=='deliberate-failure-detected' for c in data['controls'])},
    'timings':timing_rows,'counters':counters,'allocation':allocation,'memory':data['memory'],
    'artifacts':inventory}
(out/'performance-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for row in timing_rows:
    if row['phase'] not in ['public','native']: continue
    metric=row['metrics']['synchronousMs']; settled=row['metrics']['settledRenderOpportunityMs']
    work=next(c for c in counters if (c['shape'],c['command'],c['phase'])==(row['shape'],row['command'],row['phase']))
    print(json.dumps({'shape':row['shape'],'path':row['phase'],
        'sync_p50':[metric['baseline']['p50'],metric['candidate']['p50']],
        'sync_p95':[metric['baseline']['p95'],metric['candidate']['p95']],
        'pairedMedianDelta':metric['pairedDelta']['p50'],'fasterPairs':metric['candidateFasterPairs'],
        'settled_p50':[settled['baseline']['p50'],settled['candidate']['p50']],
        'avoidedJsonVisits':work['avoided']['jsonRecordVisits']}))
print(json.dumps({'sourceHashesVerified':source_checks,'dependencyHashesVerified':dependency_checks,
    'storedPercentilesVerified':stored_stat_checks,'controls':summary['controls'],
    'rawArtifactCount':len(inventory),'rawArtifactBytes':sum(a['bytes'] for a in inventory.values())}))
