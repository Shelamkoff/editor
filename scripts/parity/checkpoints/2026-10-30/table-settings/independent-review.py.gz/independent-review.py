from pathlib import Path
import gzip,json,hashlib,subprocess,copy
from html.parser import HTMLParser
repo=Path('/workspace/scratch/2231de9d6b0d/work-tables-next')
path=repo/'scripts/parity/checkpoints/2026-10-30/table-settings/settings-final-differential.json.gz'
payload=gzip.decompress(path.read_bytes()); data=json.loads(payload)
def digest(value):return hashlib.sha256(value).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
class Markup(HTMLParser):
 def __init__(self,value):
  super().__init__(convert_charrefs=True);self.nodes=[];self.stack=[self.nodes];self.feed(value)
 def handle_starttag(self,tag,attrs):
  node={'tag':tag,'attributes':dict(attrs),'children':[]};self.stack[-1].append(node);self.stack.append(node['children'])
 def handle_endtag(self,tag):self.stack.pop()
 def handle_data(self,value):self.stack[-1].append(value)
def markup(s):return Markup(s).nodes
assert data['headBefore']==data['headAfter']=='5e3bdd7cd5b73c8652a819d07c6b51cf2335f8df'
expected_ids={f'TABLE_SETTINGS/{state}/{action}' for state in ['body','headed'] for action in ['header','row-add','row-del','col-add','col-del']}|{f'TABLE_SETTINGS/{state}/{action}' for state in ['minimum','removed-widgets'] for action in ['row-del','col-del']}
verdicts=0;independent_checks=0;source_hashes=0;summary=[]
for result in data['results']:
 legacy=result['source']=='v1'
 assert len(result['cases'])==14 and {c['id'] for c in result['cases']}==expected_ids
 assert not result['errors'] and not result['incompleteCases']
 for case in result['cases']:
  _,state,action=case['id'].split('/');minimum=state=='minimum';removed=state=='removed-widgets'
  headings=state in ['headed','minimum'] or removed and action=='col-del'
  base=[['<b>Alpha</b> {{mention}} {{swatch}} tail']] if minimum else [['<b>Alpha</b> {{mention}} {{swatch}} tail','<i>Bravo</i> tail'],['Charlie &amp; tail','<s>Delta</s> tail']]
  if removed:base[1][1]='<s>Delta</s> {{removedMention}} {{removedSwatch}} tail'
  typed=copy.deepcopy(base);typed[0][0]+='X';changed=copy.deepcopy(typed)
  if action=='row-add':changed.append(['']*len(changed[0]))
  if action=='col-add':
   for row in changed:row.append('')
  if action=='row-del' and not minimum:changed=changed[:-1]
  if action=='col-del' and not minimum:changed=[row[:-1] for row in changed]
  changed_headings=not headings if action=='header' else headings
  phases={'load':(base,headings,False,False,0),'input':(typed,headings,True,False,1),'settings':(changed,changed_headings,True,False,1 if minimum else 2),'undo-input':(base,headings,False,True,2 if minimum else 4),'redo-input':(typed,headings,True,not minimum,3 if minimum else 5)}
  if not minimum:phases.update({'undo-setting':(typed,headings,True,True,3),'redo-setting':(changed,changed_headings,True,False,6)})
  assert set(p['phase'] for p in case['phases'])==set(phases)
  for snap in case['phases']:
   name=snap['phase'];grid,heads,canUndo,canRedo,count=phases[name];block,=snap['blocks'];assert block['id']=='table' and block['type']=='table'
   actual_grid=block['data']['content'] if legacy else [[cell['text'] for cell in row['cells']] for row in block['data']['rows']]
   assert actual_grid==grid,(result['source'],case['id'],name,'grid')
   assert block['data']['withHeadings']==heads
   known={'mention':{'type':'mention','data':{'id':'ada','name':'Ada'}},'swatch':{'type':'color','data':{'value':'#123456'}}}
   if removed:known.update({'removedMention':{'type':'mention','data':{'id':'grace','name':'Grace'}},'removedSwatch':{'type':'color','data':{'value':'#654321'}}})
   expected_inline={key:{**value,**({} if legacy else {'dataVersion':1})} for key,value in known.items() if any('{{'+key+'}}' in text for row in grid for text in row)}
   assert block.get('inline')==expected_inline
   if not legacy:
    assert block['dataVersion']==2
    rows=block['data']['rows'];row_ids=[r['id'] for r in rows];cell_ids=[c['id'] for r in rows for c in r['cells']]
    assert all(isinstance(x,str) and x for x in row_ids+cell_ids)
    assert len(set(row_ids))==len(row_ids) and len(set(cell_ids))==len(cell_ids)
    for ri,row in enumerate(rows):
     if ri<len(base):assert row['id']==f'row-{ri}'
     for ci,cell in enumerate(row['cells']):
      if ri<len(base) and ci<len(base[ri]):assert cell['id']==f'cell-{ri}-{ci}'
   props={o['property']:o for o in case['observations'] if o['phase']==name}
   assert props['history']['expected']=={'canUndo':canUndo,'canRedo':canRedo}
   if not legacy:assert props['completedActions']['actual']==props['completedActions']['expected']==count
   expected_cells=[[{'tag':'TH' if heads and ri==0 else 'TD','markup':markup(text)} for text in row] for ri,row in enumerate(grid)]
   for property in ['editorCells','rendererCells']:assert props[property]['actual']==props[property]['expected']==expected_cells
   expected_sections=(['THEAD'] if heads else [])+(['TBODY'] if len(grid)>(1 if heads else 0) else [])
   assert props['rendererSections']['actual']==props['rendererSections']['expected']==expected_sections
   independent_checks+=1
  for o in case['observations']:
   actual=o.get('actual',{'__undefined__':True});expected=o.get('expected',{'__undefined__':True})
   assert o['status']==('PASS' if actual==expected else 'FAIL')
   verdicts+=1
  lookup={s['phase']:s['blocks'] for s in case['phases']}
  assert lookup['undo-input']==lookup['load']
  assert lookup['redo-input']==lookup['input']
  if not minimum:
   assert lookup['undo-setting']==lookup['input'] and lookup['redo-setting']==lookup['settings']
 summary.append({'source':result['source'],'cases':len(result['cases']),'observations':sum(len(c['observations']) for c in result['cases']),'failures':len(result['failures'])})
for source in data['sources']:
 for path,sha in source['loaded'].items():assert digest(git('show',source['sha']+':'+path))==sha;source_hashes+=1
for path,sha in data['dependencyFiles'].items():assert digest((repo/'node_modules'/path).read_bytes())==sha
assert digest(git('show',data['headBefore']+':tests/browser/table-settings-parity-fixture.js'))==data['fixtureSha256']
assert digest(git('show',data['headBefore']+':scripts/parity/table-settings-parity.mjs'))==data['runnerSha256']
print(json.dumps({'reviewedSource':data['headBefore'],'decodedRawSha256':digest(payload),'summary':summary,'independentlyRecomputedVerdicts':verdicts,'independentlyReconstructedPhaseStates':independent_checks,'verifiedModuleHashRecords':source_hashes,'verifiedDependencyFiles':len(data['dependencyFiles']),'allPass':True,'limitations':['Minimum 1x1 native disabled controls exercised with headings=true; width/height enablement is independent of headings in reviewed source.','Fixture deliberately restores first-field focus before native Undo. It proves exact history/action count and input caret replay, not exact post-menu or structural-setting caret placement.','Browser coverage Chrome156 Linux only; unrelated Table cells/keyboard/paste obligations remain separate.'],'acceptanceRecommendation':'The complete recorded existing row/column settings and heading-toggle scope supports BLOCK_TABLE_ROWS_COLUMNS and BLOCK_TABLE_HEADINGS after integrated validation. Do not claim general Table or platform completion.'},indent=2))
