import json
import os
from pathlib import Path
import signal
import subprocess
import sys

repo = Path('/workspace/scratch/2231de9d6b0d/editor')
env = dict(os.environ)
env.update({
    'EDITOR_CHROME_PATH': '/tmp/rector-chrome/opt/google/chrome/chrome',
    'EDITOR_PLAYWRIGHT_PATH': '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs',
})
for key in ('EDITOR_BROWSER_PAGE', 'EDITOR_BROWSER_ROOT', 'EDITOR_NATIVE_PAGE', 'EDITOR_NATIVE_FILTER', 'EDITOR_CANDIDATE_SHA'):
    env.pop(key, None)
gates = [
    ('typecheck', None, None, ['npm', 'run', 'typecheck']),
    ('heading-list-native', 'native-plugin-parity.html', 'Text block settings parity', ['node', 'tests/browser/physical-history.mjs']),
    ('columns-native', 'native-plugin-parity.html', 'Columns', ['node', 'tests/browser/physical-history.mjs']),
    ('tool-actions-native', 'native-tools.html', 'tool action ', ['node', 'tests/browser/physical-history.mjs']),
    ('source-indentation-native', 'native-source-indentation.html', None, ['node', 'tests/browser/physical-history.mjs']),
    ('source-modes-native', 'native-source-modes.html', None, ['node', 'tests/browser/physical-history.mjs']),
]
helper = ['node', 'scripts/verification-results.mjs']
directory = Path(subprocess.check_output(helper + ['init'] + [name for name, *_ in gates], cwd=repo, env=env, text=True).strip())
env['EDITOR_RESULTS_DIR'] = str(directory)
Path('/tmp/rector-sixth-native-path').write_text(str(directory) + '\n')
print(json.dumps({'directory': str(directory), 'head': json.loads((directory / 'manifest.json').read_text())['source']['head']}), flush=True)
child = None
interrupted = False

def interrupt(number, _frame):
    global interrupted
    interrupted = True
    if child is not None and child.poll() is None:
        child.send_signal(number)

signal.signal(signal.SIGINT, interrupt)
signal.signal(signal.SIGTERM, interrupt)
for name, page, filter_text, command in gates:
    if interrupted:
        break
    gate_env = dict(env)
    if page:
        gate_env['EDITOR_NATIVE_PAGE'] = page
    if filter_text:
        gate_env['EDITOR_NATIVE_FILTER'] = filter_text
    print(json.dumps({'starting': name}), flush=True)
    with (directory / (name + '-console.log')).open('w') as output:
        child = subprocess.Popen(helper + ['run', name, '--'] + command, cwd=repo, env=gate_env, stdout=output, stderr=subprocess.STDOUT)
        code = child.wait()
    state = json.loads((directory / 'manifest.json').read_text())['gates'][name]
    print(json.dumps({'gate': name, 'exitCode': code, 'outcome': state['outcome'], 'elapsedMs': state.get('elapsedMs')}), flush=True)
    if code:
        print((directory / (name + '-console.log')).read_text()[-4000:], flush=True)
    child = None
finished = subprocess.run(helper + ['finish'], cwd=repo, env=env)
manifest = json.loads((directory / 'manifest.json').read_text())
print(json.dumps({'directory': str(directory), 'outcome': manifest['outcome'], 'sourceUnchanged': manifest['sourceUnchanged']}), flush=True)
sys.exit(finished.returncode)
