import { spawn } from 'node:child_process'
import { createServer } from 'node:net'
import { createHash } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import { chromium } from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs'
const root='/workspace/scratch/2231de9d6b0d/work-tools-next'
const files=['inline-tools/utils.js','inline-tools/inlineContent.js','inline-tools/caseTransform.js','inline-tools/link.js']
const hashes=async()=>Object.fromEntries(await Promise.all(files.map(async path=>[path,createHash('sha256').update(await readFile(root+'/'+path)).digest('hex')])))
const before=await hashes()
const port=await new Promise((resolve,reject)=>{const s=createServer();s.on('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p))})})
const vite=spawn(process.execPath,[root+'/node_modules/vite/bin/vite.js','--host','127.0.0.1','--port',String(port),'--strictPort'],{cwd:root,stdio:'pipe'})
let browser
try{
const base='http://127.0.0.1:'+port
for(let i=0;i<200;i++){try{if((await fetch(base+'/package.json')).ok)break}catch{};await new Promise(r=>setTimeout(r,50))}
browser=await chromium.launch({executablePath:'/tmp/rector-chrome/opt/google/chrome/chrome',headless:true,args:['--no-sandbox']})
const page=await browser.newPage();const errors=[];page.on('pageerror',error=>errors.push(String(error)))
await page.goto(base+'/package.json')
const results=await page.evaluate(async base=>{
 const {collectTextTargets}=await import(base+'/inline-tools/utils.js')
 const {createCaseTransformTool}=await import(base+'/inline-tools/caseTransform.js')
 const {createClearFormattingTool}=await import(base+'/inline-tools/clearFormatting.js')
 const results=[]
 const verify=(name,actual,expected)=>results.push({name,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)})
 const make=()=>{const root=document.createElement('div');root.innerHTML='<div class="oe-block" contenteditable="false"><div contenteditable="true"><b>Alpha</b><span contenteditable="true"><b>Nested</b></span><span contenteditable="false">Locked</span><button>Native</button><span data-inline-plugin="color" contenteditable="false">Widget</span><i>Beta</i></div></div><div class="oe-block" contenteditable="false"><div contenteditable="true"><b>Bravo</b></div></div>';document.body.append(root);return root}
 const root=make(),first=root.firstElementChild.firstElementChild,last=root.lastElementChild.firstElementChild,nested=first.querySelector('[contenteditable="true"]')
 const range=document.createRange();range.setStart(first.firstChild.firstChild,2);range.setEnd(last.firstChild.firstChild,4)
 verify('cross-block keeps selected outer text only',collectTextTargets(root,range).map(({node,startOffset,endOffset})=>node.data.slice(startOffset,endOffset)),['pha','Beta','Brav'])
 const local=document.createRange();local.selectNodeContents(first.lastChild)
 verify('subtree clipping does not include sibling text',collectTextTargets(first.lastChild,local).map(({node,startOffset,endOffset})=>node.data.slice(startOffset,endOffset)),['Beta'])
 const own=document.createRange();own.setStart(nested.firstChild.firstChild,1);own.setEnd(nested.firstChild.firstChild,4)
 verify('independently selected nested host keeps own authority',collectTextTargets(nested,own).map(({node,startOffset,endOffset})=>node.data.slice(startOffset,endOffset)),['est'])
 root.remove()
 for(const [label,create] of [['case',createCaseTransformTool],['clear',createClearFormattingTool]]){
  const root=make(),first=root.firstElementChild.firstElementChild,nested=first.querySelector('[contenteditable="true"]'),r=document.createRange();r.selectNodeContents(nested)
  const originalOuter=[first.firstChild.outerHTML,first.lastChild.outerHTML],tool=create(label);tool.bindSelectionPort({range:r,capture:()=>({}),restore:()=>true})
  try{tool.toggle({range:r});verify(label+' independently selected nested host result',nested.innerHTML,label==='case'?'<b>NESTED</b>':'Nested');verify(label+' leaves surrounding host unchanged',[first.firstChild.outerHTML,first.lastChild.outerHTML],originalOuter)}finally{tool.bindSelectionPort(null);root.remove()}
 }
 return results
},base)
const after=await hashes();console.log(JSON.stringify({before,after,sourceUnchanged:JSON.stringify(before)===JSON.stringify(after),errors,results},null,2));if(errors.length||results.some(r=>!r.pass))process.exitCode=1
}finally{await browser?.close();vite.kill()}
