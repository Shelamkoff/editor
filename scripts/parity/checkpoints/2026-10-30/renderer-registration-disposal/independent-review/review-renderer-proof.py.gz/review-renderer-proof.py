from pathlib import Path
import json, gzip, hashlib, subprocess, tempfile, os, datetime

root = Path('/workspace/scratch/40cb45010ec4/editor')
object_repo = Path('/workspace/scratch/40cb45010ec4/rector-performance-completion')
checkpoint = root/'scripts/parity/checkpoints/2026-10-30/renderer-registration-disposal'
out = Path('/workspace/scratch/40cb45010ec4/rector-performance-evidence')
digest = lambda content: hashlib.sha256(content).hexdigest()
git = lambda *args: subprocess.check_output(['git',*args],cwd=root)
raw_path = checkpoint/'renderer-differential/output.log.gz'
raw = gzip.decompress(raw_path.read_bytes())
data = json.loads(raw)
assert raw == (root.parent/'rector-active-20261030/renderer-differential/output.log').read_bytes()
summary = json.loads((checkpoint/'summary.json').read_text())
assert not data['serverErrors']
assert data['candidatePass'] is True

sources = []
source_hashes = 0
for source in data['sources']:
    assert git('rev-parse',source['sha']+'^{tree}').decode().strip() == source['tree']
    for path, expected in source['loaded'].items():
        assert digest(git('show',source['sha']+':'+path)) == expected, (source['label'],path)
        source_hashes += 1
    sources.append({key:source[key] for key in ['label','sha','tree']})
candidate = next(source for source in sources if source['label']=='candidate')
for field,path in [('runnerSha256','scripts/parity/renderer-lifetimes.mjs'),
    ('fixtureSha256','tests/browser/renderer-lifetime-parity-fixture.js')]:
    assert digest(git('show',candidate['sha']+':'+path)) == data[field]
dependency_hashes = 0
for path, expected in data['dependencyFiles'].items():
    assert digest((root/'node_modules'/path).read_bytes()) == expected, path
    dependency_hashes += 1
artifact_hashes = 0
for path, expected in json.loads((checkpoint/'artifact-hashes.json').read_text()).items():
    content = (checkpoint/path).read_bytes()
    assert digest(content) == expected['sha256'] and len(content) == expected['bytes'], path
    artifact_hashes += 1

verdicts = 0
results = []
expected_ids = {f'registration/{method}/{signature}/{unknown}'
    for method in ['renderBlock','render','renderTo'] for signature in ['data','revision']
    for unknown in ['throw','placeholder']}
for result in data['results']:
    assert not result['pageErrors']
    assert len(result['cases']) == 21
    registration = [case for case in result['cases'] if case['id'].startswith('registration/')]
    assert {case['id'] for case in registration} == expected_ids
    failures = []; registration_observations = 0
    for case in result['cases']:
        assert case['complete'] and not case['errors']
        if case['id'].startswith('registration/'): registration_observations += len(case['observations'])
        for observation in case['observations']:
            same = json.dumps(observation['actual'],ensure_ascii=False,separators=(',',':')) == json.dumps(observation['expected'],ensure_ascii=False,separators=(',',':'))
            assert observation['status'] == ('PASS' if same else 'FAIL'), (result['source'],case['id'],observation['property'])
            verdicts += 1
            if not same: failures.append({'case':case['id'],'property':observation['property']})
    assert not any(failure['case'].startswith('registration/') for failure in failures)
    if result['source']=='candidate': assert not failures
    results.append({'source':result['source'],'cases':len(result['cases']),
        'observations':sum(len(case['observations']) for case in result['cases']),
        'registrationCases':len(registration),'registrationObservations':registration_observations,
        'registrationFailures':0,'failures':len(failures),'failedObservations':failures})

patches = []
with tempfile.TemporaryDirectory(prefix='renderer-proof-',dir=out) as temporary:
    tmp=Path(temporary)
    for name in ['candidate.patch.gz','red-tests.patch.gz']:
        patch=gzip.decompress((checkpoint/name).read_bytes())
        path=tmp/(name.removesuffix('.gz'));path.write_bytes(patch)
        index=tmp/(name+'.index')
        env=dict(os.environ);env['GIT_INDEX_FILE']=str(index)
        def index_git(*args): return subprocess.check_output(['git',*args],cwd=object_repo,env=env)
        index_git('read-tree',summary['base'])
        index_git('apply','--cached',str(path))
        tree=index_git('write-tree').decode().strip()
        changed=index_git('diff','--cached','--name-only',summary['base']).decode().splitlines()
        if name=='candidate.patch.gz': assert tree == summary['tree']
        else:
            assert changed == ['renderer/reentrancy.test.js']
            assert index_git('show',':renderer/EditorRenderer.js') == git('show',summary['base']+':renderer/EditorRenderer.js')
            assert index_git('show',':renderer/reentrancy.test.js') == git('show',summary['candidate']+':renderer/reentrancy.test.js')
        patches.append({'artifact':name,'uncompressedSha256':digest(patch),'reconstructedTree':tree,'changedFiles':changed})

report={'reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer':'Independent performance agent; read-only fixture/code review plus source/verdict/patch reconstruction',
    'reviewScriptSha256':digest(Path(__file__).read_bytes()),'rawResultSha256':digest(raw),
    'sources':sources,'sourceModuleHashesVerified':source_hashes,'dependencyHashesVerified':dependency_hashes,
    'archiveHashesVerified':artifact_hashes,'verdictsRecomputed':verdicts,'verdictMismatches':0,
    'results':results,'patchReconstruction':patches,
    'decision':'RENDERER_REGISTRATION supports scoped acceptance after combined integration on the published candidate. All 12 independently specified registration cases pass on all four immutable sources.',
    'limits':'Custom renderers with injectStyles:false, one Chromium environment and shared recorded dependencies. Nine diagnostic-failure cases repair narrower behavior and do not close RENDERER_ERRORS or broader renderer/realm/style obligations.'}
(out/'renderer-proof-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:value for key,value in report.items() if key not in ['results','sources']},indent=2))
